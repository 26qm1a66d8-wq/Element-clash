/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { ElementInfo, ElementType, ComboSynergy, DailyMission, UserAccount } from '../types/game';

export const ELEMENTS: Record<ElementType, ElementInfo> = {
  fire: {
    id: 'fire',
    name: 'Fire',
    icon: '🔥',
    color: 'from-orange-500 via-red-600 to-amber-500',
    glowColor: 'rgba(239, 68, 68, 0.7)',
    hexColor: 0xef4444,
    description: 'Blazing destruction. Melts solid Earth and overloads volatile Lightning.',
    beats: ['earth', 'lightning'],
    beatenBy: ['water'],
    specialRule: '🔥 Burns Earth & Lightning (+75% DMG). Applies "Burn" DoT ticking damage for 3.5s.',
    baseDamage: 28,
    cooldown: 1.1,
    ultimateName: 'Hellfire Supernova',
    ultimateDesc: 'Summons a colossal falling meteor that scorches the entire arena.',
    ultimateCooldown: 12,
  },
  earth: {
    id: 'earth',
    name: 'Earth',
    icon: '🌍',
    color: 'from-emerald-500 via-teal-600 to-amber-700',
    glowColor: 'rgba(16, 185, 129, 0.7)',
    hexColor: 0x10b981,
    description: 'Primordial bedrock. Absorbs and buries water torrents effortlessly.',
    beats: ['water'],
    beatenBy: ['fire', 'lightning'],
    specialRule: '🌍 Absorbs Water (+75% DMG). Can construct destructible stone barriers for cover.',
    baseDamage: 26,
    cooldown: 1.3,
    ultimateName: 'Tectonic Cataclysm',
    ultimateDesc: 'Rips the arena floor apart, thrusting jagged obsidian monoliths through enemy defenses.',
    ultimateCooldown: 12,
  },
  water: {
    id: 'water',
    name: 'Water',
    icon: '💧',
    color: 'from-cyan-400 via-blue-600 to-indigo-600',
    glowColor: 'rgba(59, 130, 246, 0.7)',
    hexColor: 0x3b82f6,
    description: 'Crushing tidal current. Extinguishes flame barriers effortlessly.',
    beats: ['fire'],
    beatenBy: ['earth', 'lightning'],
    specialRule: '💧 Extinguishes Fire (+75% DMG). Applies "Slow" soaking target (-45% speed & delayed cooldowns).',
    baseDamage: 24,
    cooldown: 1.0,
    ultimateName: 'Abyssal Maelstrom',
    ultimateDesc: 'Conjures a vortex of pressurized whirlpools, trapping and crushing opponents.',
    ultimateCooldown: 12,
  },
  lightning: {
    id: 'lightning',
    name: 'Lightning',
    icon: '⚡',
    color: 'from-purple-400 via-fuchsia-500 to-amber-400',
    glowColor: 'rgba(168, 85, 247, 0.8)',
    hexColor: 0xa855f7,
    description: 'Rare 4th Element. Slashes through Water and Earth with high-voltage ionized fury.',
    beats: ['water', 'earth'],
    beatenBy: ['fire'],
    specialRule: '⚡ Rare element! Defeats Water AND Earth (+80% DMG). Stuns target on consecutive hits! Defeated by Fire.',
    baseDamage: 34,
    cooldown: 1.6,
    ultimateName: "Raijin's Judgement",
    ultimateDesc: 'Rains down continuous divine thunderbolts that pierce shields and paralyze foes.',
    ultimateCooldown: 14,
  },
};

export const COMBOS: ComboSynergy[] = [
  {
    id: 'magma',
    name: 'Magma Eruption',
    elementA: 'fire',
    elementB: 'earth',
    description: 'Fire + Earth: Launches an explosive molten boulder.',
    effect: 'Deals 58 damage and inflicts intensified Burn DoT.',
    damageMultiplier: 1.85,
    color: '#f97316',
  },
  {
    id: 'chain_storm',
    name: 'Thunder Surge',
    elementA: 'water',
    elementB: 'lightning',
    description: 'Water + Lightning: High-voltage hydro-conduction.',
    effect: 'Deals 64 damage and instantly triggers a 2.0s Ionized Stun!',
    damageMultiplier: 2.1,
    color: '#818cf8',
  },
  {
    id: 'nature_aegis',
    name: 'Verdant Bloom',
    elementA: 'water',
    elementB: 'earth',
    description: 'Water + Earth: Spawns life-infused botanical roots.',
    effect: 'Deals 38 damage and recovers +30 HP to caster.',
    damageMultiplier: 1.4,
    color: '#34d399',
  },
  {
    id: 'plasma',
    name: 'Solar Plasma',
    elementA: 'fire',
    elementB: 'lightning',
    description: 'Fire + Lightning: Ionized solar laser beam.',
    effect: 'Deals 68 critical piercing damage and burns shields.',
    damageMultiplier: 2.25,
    color: '#ec4899',
  },
];

export interface RankTier {
  name: string;
  minLP: number;
  badge: string;
  color: string;
  borderGlow: string;
}

export const RANK_TIERS: RankTier[] = [
  { name: 'Bronze III', minLP: 0, badge: '🥉', color: '#cd7f32', borderGlow: 'rgba(205,127,50,0.4)' },
  { name: 'Bronze II', minLP: 100, badge: '🥉', color: '#cd7f32', borderGlow: 'rgba(205,127,50,0.4)' },
  { name: 'Bronze I', minLP: 200, badge: '🥉', color: '#cd7f32', borderGlow: 'rgba(205,127,50,0.4)' },
  { name: 'Silver III', minLP: 300, badge: '🥈', color: '#94a3b8', borderGlow: 'rgba(148,163,184,0.4)' },
  { name: 'Silver II', minLP: 450, badge: '🥈', color: '#94a3b8', borderGlow: 'rgba(148,163,184,0.4)' },
  { name: 'Silver I', minLP: 600, badge: '🥈', color: '#94a3b8', borderGlow: 'rgba(148,163,184,0.4)' },
  { name: 'Gold III', minLP: 800, badge: '🥇', color: '#eab308', borderGlow: 'rgba(234,179,8,0.5)' },
  { name: 'Gold II', minLP: 1000, badge: '🥇', color: '#eab308', borderGlow: 'rgba(234,179,8,0.5)' },
  { name: 'Gold I', minLP: 1250, badge: '🥇', color: '#eab308', borderGlow: 'rgba(234,179,8,0.5)' },
  { name: 'Platinum', minLP: 1500, badge: '💠', color: '#06b6d4', borderGlow: 'rgba(6,182,212,0.6)' },
  { name: 'Diamond', minLP: 1900, badge: '💎', color: '#a855f7', borderGlow: 'rgba(168,85,247,0.6)' },
  { name: 'Grandmaster Archon', minLP: 2400, badge: '👑', color: '#f59e0b', borderGlow: 'rgba(245,158,11,0.8)' },
];

export function getRankTier(lp: number): RankTier {
  for (let i = RANK_TIERS.length - 1; i >= 0; i--) {
    if (lp >= RANK_TIERS[i].minLP) return RANK_TIERS[i];
  }
  return RANK_TIERS[0];
}

export interface Perk {
  id: string;
  name: string;
  icon: string;
  desc: string;
  unlockLevel: number;
}

export const PERKS: Perk[] = [
  { id: 'balanced', name: 'Arcane Balance', icon: '⚖️', desc: '+10 Max HP and 10% faster cooldowns.', unlockLevel: 1 },
  { id: 'pyro_fury', name: 'Infernal Spark', icon: '🔥', desc: 'Fire spells burn 50% longer and deal +15% damage.', unlockLevel: 2 },
  { id: 'ocean_grace', name: 'Tidal Ward', icon: '💧', desc: 'Recovers 12 HP whenever you slow an opponent.', unlockLevel: 3 },
  { id: 'granite_shell', name: 'Granite Skin', icon: '🛡️', desc: 'Earth walls have +60% health, take 15% less damage.', unlockLevel: 4 },
  { id: 'voltaic_surge', name: 'Superconductor', icon: '⚡', desc: 'Start battle with +1 extra Lightning Charge. Stun lasts +0.5s.', unlockLevel: 5 },
];

export interface Skin {
  id: string;
  name: string;
  robeColor: number;
  glowColor: number;
  desc: string;
  unlockWins: number;
}

export const SKINS: Skin[] = [
  { id: 'initiate', name: 'Arcane Novice', robeColor: 0x334155, glowColor: 0x38bdf8, desc: 'Classic robes of the elemental academy.', unlockWins: 0 },
  { id: 'blaze_lord', name: 'Infernal Warden', robeColor: 0x7f1d1d, glowColor: 0xf97316, desc: 'Forged in the heart of obsidian volcanoes.', unlockWins: 3 },
  { id: 'tide_caller', name: 'Abyssal Sovereign', robeColor: 0x0c4a6e, glowColor: 0x06b6d4, desc: 'Blessed by the deep marine trenches.', unlockWins: 6 },
  { id: 'terra_titan', name: 'Terra Colossus', robeColor: 0x14532d, glowColor: 0x10b981, desc: 'Carved from primordial granite.', unlockWins: 10 },
  { id: 'raijin_avatar', name: 'Raijin Thunderlord', robeColor: 0x3b0764, glowColor: 0xc084fc, desc: 'Wreathed in divine thunderclaps.', unlockWins: 15 },
];

export const AVATARS = [
  { id: 'av_1', icon: '🧙‍♂️', name: 'Arcane Elementalist', color: '#38bdf8' },
  { id: 'av_2', icon: '🔥', name: 'Infernal Pyromancer', color: '#ef4444' },
  { id: 'av_3', icon: '🌊', name: 'Abyssal Siren', color: '#06b6d4' },
  { id: 'av_4', icon: '🗿', name: 'Terra Colossus', color: '#10b981' },
  { id: 'av_5', icon: '⚡', name: 'Raijin Stormlord', color: '#c084fc' },
  { id: 'av_6', icon: '🥷', name: 'Shadow Shinobi', color: '#6366f1' },
  { id: 'av_7', icon: '👑', name: 'Elemental Sovereign', color: '#f59e0b' },
  { id: 'av_8', icon: '🐉', name: 'Draconic Archon', color: '#f43f5e' },
];

export const TITLES = [
  'Novice Elementalist',
  'Pyromaniac',
  'Tidal Surge Master',
  'Bedrock Guardian',
  'Storm Bringer',
  'Grandmaster Archon',
  'Unbroken Champion',
];

export const INITIAL_DAILY_MISSIONS: DailyMission[] = [
  {
    id: 'm_1',
    title: 'Trial of Flame',
    desc: 'Deal 150 damage using Fire spells.',
    rewardXp: 80,
    rewardLp: 20,
    progress: 0,
    target: 150,
    completed: false,
    claimed: false,
    icon: '🔥',
  },
  {
    id: 'm_2',
    title: 'Conductive Surge',
    desc: 'Inflict a Stun or Slow status effect in battle.',
    rewardXp: 100,
    rewardLp: 25,
    progress: 0,
    target: 1,
    completed: false,
    claimed: false,
    icon: '⚡',
  },
  {
    id: 'm_3',
    title: 'Arena Dominance',
    desc: 'Win 2 matches in any battle mode.',
    rewardXp: 150,
    rewardLp: 35,
    progress: 0,
    target: 2,
    completed: false,
    claimed: false,
    icon: '🏆',
  },
];

/**
 * Seed Community Players for Global Leaderboard and Friend Search
 */
export const SEED_PLAYERS: UserAccount[] = [
  {
    id: 'user_valkyrie',
    username: 'ValkyriePrime',
    email: 'valk@elementclash.gg',
    playerTag: '#EC-9901',
    avatar: '⚡',
    title: 'Storm Bringer',
    level: 18,
    xp: 240,
    rankPoints: 2680,
    wins: 142,
    losses: 28,
    draws: 4,
    streak: 11,
    bestStreak: 18,
    countersWon: 310,
    statusEffectsInflicted: 245,
    friends: [],
    pendingFriendRequests: [],
    achievements: ['first_blood', 'pyromancer', 'storm_overcharge', 'grandmaster'],
    lastLoginDate: '2026-10-30',
    dailyRewardDay: 5,
    dailyRewardClaimed: true,
    dailyMissions: [],
    battleHistory: [],
    activePerk: 'voltaic_surge',
    activeSkin: 'raijin_avatar',
    lightningCharges: 2,
    maxLightningCharges: 2,
  },
  {
    id: 'user_ignis_lord',
    username: 'IgnisImperator',
    email: 'ignis@elementclash.gg',
    playerTag: '#EC-4412',
    avatar: '🔥',
    title: 'Pyromaniac',
    level: 16,
    xp: 380,
    rankPoints: 2510,
    wins: 128,
    losses: 34,
    draws: 6,
    streak: 8,
    bestStreak: 15,
    countersWon: 275,
    statusEffectsInflicted: 198,
    friends: [],
    pendingFriendRequests: [],
    achievements: ['first_blood', 'pyromancer', 'grandmaster'],
    lastLoginDate: '2026-10-30',
    dailyRewardDay: 6,
    dailyRewardClaimed: true,
    dailyMissions: [],
    battleHistory: [],
    activePerk: 'pyro_fury',
    activeSkin: 'blaze_lord',
    lightningCharges: 2,
    maxLightningCharges: 2,
  },
  {
    id: 'user_tidal_queen',
    username: 'SirenOfAbyss',
    email: 'siren@elementclash.gg',
    playerTag: '#EC-7823',
    avatar: '🌊',
    title: 'Tidal Surge Master',
    level: 15,
    xp: 150,
    rankPoints: 2420,
    wins: 115,
    losses: 31,
    draws: 5,
    streak: 6,
    bestStreak: 12,
    countersWon: 230,
    statusEffectsInflicted: 180,
    friends: [],
    pendingFriendRequests: [],
    achievements: ['first_blood', 'tidal_wave', 'grandmaster'],
    lastLoginDate: '2026-10-30',
    dailyRewardDay: 4,
    dailyRewardClaimed: true,
    dailyMissions: [],
    battleHistory: [],
    activePerk: 'ocean_grace',
    activeSkin: 'tide_caller',
    lightningCharges: 2,
    maxLightningCharges: 2,
  },
  {
    id: 'user_terra_titan',
    username: 'GigaGolem',
    email: 'golem@elementclash.gg',
    playerTag: '#EC-1109',
    avatar: '🗿',
    title: 'Bedrock Guardian',
    level: 13,
    xp: 410,
    rankPoints: 1980,
    wins: 94,
    losses: 39,
    draws: 8,
    streak: 4,
    bestStreak: 10,
    countersWon: 185,
    statusEffectsInflicted: 95,
    friends: [],
    pendingFriendRequests: [],
    achievements: ['first_blood', 'earth_bastion'],
    lastLoginDate: '2026-10-30',
    dailyRewardDay: 3,
    dailyRewardClaimed: true,
    dailyMissions: [],
    battleHistory: [],
    activePerk: 'granite_shell',
    activeSkin: 'terra_titan',
    lightningCharges: 2,
    maxLightningCharges: 2,
  },
  {
    id: 'user_frost_nova',
    username: 'AetherKnight',
    email: 'aether@elementclash.gg',
    playerTag: '#EC-3351',
    avatar: '🧙‍♂️',
    title: 'Novice Elementalist',
    level: 11,
    xp: 120,
    rankPoints: 1650,
    wins: 76,
    losses: 32,
    draws: 3,
    streak: 5,
    bestStreak: 9,
    countersWon: 140,
    statusEffectsInflicted: 110,
    friends: [],
    pendingFriendRequests: [],
    achievements: ['first_blood'],
    lastLoginDate: '2026-10-30',
    dailyRewardDay: 2,
    dailyRewardClaimed: false,
    dailyMissions: [],
    battleHistory: [],
    activePerk: 'balanced',
    activeSkin: 'initiate',
    lightningCharges: 2,
    maxLightningCharges: 2,
  },
  {
    id: 'user_zenith',
    username: 'ZenithBlade',
    email: 'zenith@elementclash.gg',
    playerTag: '#EC-6624',
    avatar: '🥷',
    title: 'Unbroken Champion',
    level: 9,
    xp: 290,
    rankPoints: 1380,
    wins: 62,
    losses: 29,
    draws: 4,
    streak: 3,
    bestStreak: 7,
    countersWon: 112,
    statusEffectsInflicted: 88,
    friends: [],
    pendingFriendRequests: [],
    achievements: ['first_blood'],
    lastLoginDate: '2026-10-30',
    dailyRewardDay: 1,
    dailyRewardClaimed: true,
    dailyMissions: [],
    battleHistory: [],
    activePerk: 'balanced',
    activeSkin: 'initiate',
    lightningCharges: 2,
    maxLightningCharges: 2,
  },
];

/**
 * Evaluates the Clash relationship based on the user's specific rules:
 * - FIRE defeats EARTH and LIGHTNING.
 * - EARTH defeats WATER.
 * - WATER defeats FIRE.
 * - LIGHTNING defeats WATER and EARTH.
 */
export function evaluateClash(attackElement: ElementType, defendElement: ElementType): {
  multiplier: number;
  type: 'counter_win' | 'counter_lose' | 'draw';
  statusToApply?: 'burn' | 'slow';
  message: string;
} {
  if (attackElement === defendElement) {
    return { multiplier: 1.0, type: 'draw', message: 'Element Clash! Neutral impact.' };
  }

  // 1. LIGHTNING RULES:
  // - Lightning defeats Water AND Earth!
  // - Fire defeats Lightning!
  if (attackElement === 'lightning') {
    if (defendElement === 'water') {
      return {
        multiplier: 1.85,
        type: 'counter_win',
        message: '⚡ CONDUCTIVE OVERLOAD! Lightning violently shocks Water (+85% DMG)!',
      };
    }
    if (defendElement === 'earth') {
      return {
        multiplier: 1.8,
        type: 'counter_win',
        message: '⚡ PIERCING DISCHARGE! Lightning pierces through Earth (+80% DMG)!',
      };
    }
    if (defendElement === 'fire') {
      return {
        multiplier: 0.6,
        type: 'counter_lose',
        message: 'OVERHEATED! Fire incinerates volatile Lightning (-40% DMG)!',
      };
    }
  }

  // 2. FIRE RULES:
  // - Fire defeats Earth AND Lightning.
  // - Water defeats Fire.
  if (attackElement === 'fire') {
    if (defendElement === 'earth') {
      return {
        multiplier: 1.75,
        type: 'counter_win',
        statusToApply: 'burn',
        message: '🔥 CRITICAL SCORCH! Fire incinerates Earth (+75% DMG)! Burn applied!',
      };
    }
    if (defendElement === 'lightning') {
      return {
        multiplier: 1.75,
        type: 'counter_win',
        statusToApply: 'burn',
        message: '🔥 THERMAL OVERLOAD! Fire extinguishes Lightning sparks (+75% DMG)!',
      };
    }
    if (defendElement === 'water') {
      return {
        multiplier: 0.55,
        type: 'counter_lose',
        message: 'DOUSED! Water extinguishes your Fire attack (-45% DMG)!',
      };
    }
  }

  // 3. EARTH RULES:
  // - Earth defeats Water.
  // - Fire and Lightning defeat Earth.
  if (attackElement === 'earth') {
    if (defendElement === 'water') {
      return {
        multiplier: 1.75,
        type: 'counter_win',
        message: '🌍 ABSORPTION! Earth completely absorbs Water torrents (+75% DMG)!',
      };
    }
    if (defendElement === 'fire') {
      return {
        multiplier: 0.55,
        type: 'counter_lose',
        message: 'MELTED! Fire burns your Earth barrier (-45% DMG)!',
      };
    }
    if (defendElement === 'lightning') {
      return {
        multiplier: 0.6,
        type: 'counter_lose',
        message: 'SHATTERED! Lightning strikes shatter Earth (-40% DMG)!',
      };
    }
  }

  // 4. WATER RULES:
  // - Water defeats Fire.
  // - Earth and Lightning defeat Water.
  if (attackElement === 'water') {
    if (defendElement === 'fire') {
      return {
        multiplier: 1.75,
        type: 'counter_win',
        statusToApply: 'slow',
        message: '💧 EXTINGUISHED! Water crushes Fire (+75% DMG)! Target slowed!',
      };
    }
    if (defendElement === 'earth') {
      return {
        multiplier: 0.55,
        type: 'counter_lose',
        message: 'ABSORBED! Earth absorbs your Water attack (-45% DMG)!',
      };
    }
    if (defendElement === 'lightning') {
      return {
        multiplier: 0.55,
        type: 'counter_lose',
        message: 'ELECTROCUTED! Water conducts Lightning recoil (-45% DMG)!',
      };
    }
  }

  return { multiplier: 1.0, type: 'draw', message: 'Elemental clash.' };
}
