/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import * as THREE from 'three';
import { RoomEnvironment } from 'three/addons/environments/RoomEnvironment.js';
import { ElementType, Projectile, EarthCover, StatusEffect } from '../types/game';
import { ELEMENTS } from './constants';

const _vec3A = new THREE.Vector3();
const _colorA = new THREE.Color();

export interface VisualFighter {
  group: THREE.Group;
  robeMesh: THREE.Mesh;
  coreMesh: THREE.Mesh;
  staffMesh: THREE.Mesh;
  orbs: THREE.Mesh[];
  shadowMesh: THREE.Mesh;
  targetPos: THREE.Vector3;
  element: ElementType;
  haloMesh: THREE.Mesh; // for stun effect
  frostMesh: THREE.Mesh; // for slow effect
  statusEffects: StatusEffect[];
}

export class ThreeSceneManager {
  private container: HTMLElement;
  private renderer: THREE.WebGLRenderer;
  private scene: THREE.Scene;
  private camera: THREE.PerspectiveCamera;
  private isSoftwareGl: boolean = false;
  private frameId: number = 0;
  private clock: THREE.Clock = new THREE.Clock();

  // Arena props
  private arenaGroup: THREE.Group = new THREE.Group();
  private fighters: Map<string, VisualFighter> = new Map();
  private projectileMeshes: Map<string, THREE.Group> = new Map();
  private coverMeshes: Map<string, THREE.Group> = new Map();

  // Dashboard Hero Artifact Centerpiece
  private heroArtifactGroup: THREE.Group = new THREE.Group();
  private currentHeroElement: ElementType | null = null;

  // Particle systems
  private particleGroup: THREE.Group = new THREE.Group();
  private activeParticles: {
    mesh: THREE.Mesh;
    vel: THREE.Vector3;
    rotVel: THREE.Vector3;
    life: number;
    maxLife: number;
    scaleStart: number;
    colorStart: THREE.Color;
  }[] = [];

  // Camera Shake & Cinematic state
  private cameraBasePos: THREE.Vector3 = new THREE.Vector3(0, 13, 20);
  private cameraLookTarget: THREE.Vector3 = new THREE.Vector3(0, 1.2, 0);
  private cameraShakeIntensity: number = 0;
  public isInspectMode: boolean = false;
  private inspectAngle: number = 0;

  // Geometries pool
  private orbGeo = new THREE.SphereGeometry(0.18, 12, 12);
  private particleGeo = new THREE.BoxGeometry(0.12, 0.12, 0.12);

  constructor(container: HTMLElement) {
    this.container = container;

    // Detect software WebGL
    this.isSoftwareGl = (() => {
      const gl = document.createElement('canvas').getContext('webgl2');
      if (!gl) return true;
      const ext = gl.getExtension('WEBGL_debug_renderer_info');
      const param = ext ? ext.UNMASKED_RENDERER_WEBGL : gl.RENDERER;
      const gpu = String(gl.getParameter(param));
      gl.getExtension('WEBGL_lose_context')?.loseContext();
      return /SwiftShader|llvmpipe|softpipe|Software|Basic Render/i.test(gpu);
    })();

    // Initialize Renderer
    this.renderer = new THREE.WebGLRenderer({
      antialias: !this.isSoftwareGl,
      powerPreference: 'high-performance',
      alpha: false,
    });
    this.renderer.outputColorSpace = THREE.SRGBColorSpace;
    this.renderer.toneMapping = THREE.ACESFilmicToneMapping;
    this.renderer.toneMappingExposure = 1.2;
    this.renderer.setPixelRatio(this.isSoftwareGl ? 1 : Math.min(window.devicePixelRatio, 2));
    this.renderer.shadowMap.enabled = !this.isSoftwareGl;
    this.renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    this.renderer.setSize(this.container.clientWidth, this.container.clientHeight);
    this.container.appendChild(this.renderer.domElement);

    // Initialize Scene & Fog matching midnight purple aesthetics
    this.scene = new THREE.Scene();
    this.scene.background = new THREE.Color(0x0a0518);
    this.scene.fog = new THREE.FogExp2(0x0a0518, 0.02);

    // Camera
    this.camera = new THREE.PerspectiveCamera(
      45,
      this.container.clientWidth / this.container.clientHeight,
      0.1,
      200
    );
    this.camera.position.copy(this.cameraBasePos);
    this.camera.lookAt(this.cameraLookTarget);

    // Studio Environment (RoomEnvironment)
    const pmremGenerator = new THREE.PMREMGenerator(this.renderer);
    this.scene.environment = pmremGenerator.fromScene(new RoomEnvironment(), 0.04).texture;
    pmremGenerator.dispose();

    // Lighting rig
    this.setupLighting();

    // Build Arena
    this.buildArena();

    // Add particle container & Hero Artifact container
    this.scene.add(this.particleGroup);
    this.scene.add(this.heroArtifactGroup);

    window.addEventListener('resize', this.onResize);
    this.startLoop();
  }

  private setupLighting() {
    // Warm key light
    const keyLight = new THREE.DirectionalLight(0xfff1e6, 2.2);
    keyLight.position.set(12, 22, 14);
    keyLight.castShadow = !this.isSoftwareGl;
    if (!this.isSoftwareGl) {
      keyLight.shadow.mapSize.width = 1024;
      keyLight.shadow.mapSize.height = 1024;
      keyLight.shadow.bias = -0.0005;
      keyLight.shadow.normalBias = 0.02;
    }
    this.scene.add(keyLight);

    // Cool electric purple/violet Hemisphere fill
    const hemiLight = new THREE.HemisphereLight(0x818cf8, 0x1e1145, 1.4);
    this.scene.add(hemiLight);

    // Cyan backlight
    const rimLight = new THREE.DirectionalLight(0x06b6d4, 1.6);
    rimLight.position.set(-14, 10, -14);
    this.scene.add(rimLight);
  }

  private buildArena() {
    this.arenaGroup = new THREE.Group();

    // Central Hexagonal Arena Platform (Procedural radial flagstone canvas)
    const canvas = document.createElement('canvas');
    canvas.width = 512;
    canvas.height = 512;
    const ctx = canvas.getContext('2d')!;
    ctx.fillStyle = '#110926';
    ctx.fillRect(0, 0, 512, 512);

    // Draw concentric arcane runes and glowing rings
    ctx.strokeStyle = '#2d1854';
    ctx.lineWidth = 6;
    ctx.beginPath();
    ctx.arc(256, 256, 220, 0, Math.PI * 2);
    ctx.stroke();

    ctx.strokeStyle = '#7c3aed';
    ctx.lineWidth = 4;
    ctx.beginPath();
    ctx.arc(256, 256, 170, 0, Math.PI * 2);
    ctx.stroke();

    // Elemental quadrant lines
    ctx.strokeStyle = '#4c1d95';
    ctx.lineWidth = 3;
    ctx.beginPath();
    ctx.moveTo(256, 36);
    ctx.lineTo(256, 476);
    ctx.moveTo(36, 256);
    ctx.lineTo(476, 256);
    ctx.stroke();

    // Center elemental emblem
    ctx.fillStyle = '#090314';
    ctx.beginPath();
    ctx.arc(256, 256, 75, 0, Math.PI * 2);
    ctx.fill();
    ctx.strokeStyle = '#a855f7';
    ctx.lineWidth = 4;
    ctx.stroke();

    const arenaTexture = new THREE.CanvasTexture(canvas);
    arenaTexture.colorSpace = THREE.SRGBColorSpace;
    arenaTexture.anisotropy = this.renderer.capabilities.getMaxAnisotropy();

    // Arena Floor Mesh
    const floorGeo = new THREE.CylinderGeometry(14, 15, 1.2, 32);
    const floorMat = new THREE.MeshStandardMaterial({
      map: arenaTexture,
      roughness: 0.65,
      metalness: 0.25,
    });
    const floor = new THREE.Mesh(floorGeo, floorMat);
    floor.position.y = -0.6;
    floor.receiveShadow = !this.isSoftwareGl;
    this.arenaGroup.add(floor);

    // Decorative Raised Outer Border Ring
    const borderGeo = new THREE.TorusGeometry(14.2, 0.35, 12, 48);
    const borderMat = new THREE.MeshStandardMaterial({
      color: 0x4c1d95,
      emissive: 0x2e1065,
      roughness: 0.35,
      metalness: 0.8,
    });
    const border = new THREE.Mesh(borderGeo, borderMat);
    border.rotation.x = Math.PI / 2;
    border.position.y = 0.02;
    this.arenaGroup.add(border);

    // 4 Elemental Quadrant Obelisks
    const quadrantElements: { pos: [number, number]; color: number; glow: number; element: ElementType }[] = [
      { pos: [0, -11.5], color: 0xef4444, glow: 0xf97316, element: 'fire' }, // North
      { pos: [11.5, 0], color: 0x3b82f6, glow: 0x06b6d4, element: 'water' }, // East
      { pos: [0, 11.5], color: 0x10b981, glow: 0x34d399, element: 'earth' }, // South
      { pos: [-11.5, 0], color: 0xa855f7, glow: 0xc084fc, element: 'lightning' }, // West
    ];

    quadrantElements.forEach((q) => {
      const pillarGroup = new THREE.Group();
      pillarGroup.position.set(q.pos[0], 0, q.pos[1]);

      const baseGeo = new THREE.CylinderGeometry(0.7, 0.9, 0.5, 6);
      const stoneMat = new THREE.MeshStandardMaterial({ color: 0x1e123d, roughness: 0.8, metalness: 0.2 });
      const base = new THREE.Mesh(baseGeo, stoneMat);
      base.position.y = 0.25;
      base.castShadow = !this.isSoftwareGl;
      pillarGroup.add(base);

      const spireGeo = new THREE.ConeGeometry(0.5, 2.6, 6);
      const spire = new THREE.Mesh(spireGeo, stoneMat);
      spire.position.y = 1.6;
      spire.castShadow = !this.isSoftwareGl;
      pillarGroup.add(spire);

      // Floating Elemental Orb atop pillar
      const gemGeo = new THREE.OctahedronGeometry(0.35, 0);
      const gemMat = new THREE.MeshStandardMaterial({
        color: q.color,
        emissive: q.glow,
        emissiveIntensity: 1.4,
        roughness: 0.2,
        metalness: 0.5,
      });
      const gem = new THREE.Mesh(gemGeo, gemMat);
      gem.position.y = 3.3;
      gem.userData = { isFloatingGem: true, rotSpeed: 1.5, baseHeight: 3.3 };
      pillarGroup.add(gem);

      if (!this.isSoftwareGl) {
        const pLight = new THREE.PointLight(q.color, 1.4, 8);
        pLight.position.set(0, 3.4, 0);
        pillarGroup.add(pLight);
      }

      this.arenaGroup.add(pillarGroup);
    });

    this.scene.add(this.arenaGroup);
  }

  /**
   * Sets or updates the 3D Hero Elemental Artifact displayed in the Dashboard
   */
  public setDashboardHeroElement(element: ElementType | null) {
    if (this.currentHeroElement === element) return;
    this.currentHeroElement = element;

    // Clear previous
    while (this.heroArtifactGroup.children.length > 0) {
      const obj = this.heroArtifactGroup.children[0];
      this.heroArtifactGroup.remove(obj);
    }

    if (!element) return;

    const elemData = ELEMENTS[element];
    const grp = new THREE.Group();
    grp.position.set(0, 2.4, 0);

    if (element === 'fire') {
      // Blazing multi-layer core
      const coreGeo = new THREE.DodecahedronGeometry(1.4, 1);
      const coreMat = new THREE.MeshStandardMaterial({
        color: 0xff3300,
        emissive: 0xff5500,
        emissiveIntensity: 2.2,
        roughness: 0.2,
      });
      const core = new THREE.Mesh(coreGeo, coreMat);
      grp.add(core);

      // Orbiting fire rings
      const ringGeo = new THREE.TorusGeometry(2.1, 0.08, 12, 36);
      const ringMat = new THREE.MeshBasicMaterial({ color: 0xfbbf24, wireframe: true });
      const ring = new THREE.Mesh(ringGeo, ringMat);
      ring.rotation.x = Math.PI / 3;
      grp.add(ring);
    } else if (element === 'water') {
      // Swirling fluid sphere
      const coreGeo = new THREE.IcosahedronGeometry(1.4, 2);
      const coreMat = new THREE.MeshPhysicalMaterial({
        color: 0x0284c7,
        emissive: 0x38bdf8,
        emissiveIntensity: 1.5,
        roughness: 0.1,
        metalness: 0.1,
      });
      const core = new THREE.Mesh(coreGeo, coreMat);
      grp.add(core);

      const ringGeo = new THREE.TorusGeometry(2.2, 0.1, 12, 36);
      const ringMat = new THREE.MeshBasicMaterial({ color: 0x06b6d4 });
      const ring = new THREE.Mesh(ringGeo, ringMat);
      ring.rotation.y = Math.PI / 4;
      grp.add(ring);
    } else if (element === 'earth') {
      // Faceted floating obsidian monolith with emerald crystal veins
      const coreGeo = new THREE.OctahedronGeometry(1.5, 0);
      const coreMat = new THREE.MeshStandardMaterial({
        color: 0x064e3b,
        emissive: 0x10b981,
        emissiveIntensity: 1.2,
        roughness: 0.4,
        metalness: 0.6,
      });
      const core = new THREE.Mesh(coreGeo, coreMat);
      grp.add(core);

      const ringGeo = new THREE.TorusGeometry(2.2, 0.12, 6, 24);
      const ringMat = new THREE.MeshStandardMaterial({ color: 0x1e293b, roughness: 0.9 });
      const ring = new THREE.Mesh(ringGeo, ringMat);
      ring.rotation.x = -Math.PI / 4;
      grp.add(ring);
    } else if (element === 'lightning') {
      // Ionized star-core with electric spikes
      const coreGeo = new THREE.OctahedronGeometry(1.3, 0);
      const coreMat = new THREE.MeshStandardMaterial({
        color: 0xc084fc,
        emissive: 0xa855f7,
        emissiveIntensity: 2.8,
        roughness: 0.1,
      });
      const core = new THREE.Mesh(coreGeo, coreMat);
      grp.add(core);

      const ringGeo = new THREE.TorusGeometry(2.2, 0.08, 12, 36);
      const ringMat = new THREE.MeshBasicMaterial({ color: 0xfacc15, wireframe: true });
      const ring = new THREE.Mesh(ringGeo, ringMat);
      ring.rotation.z = Math.PI / 3;
      grp.add(ring);
    }

    grp.userData = { isHeroArtifact: true, baseElem: element };
    this.heroArtifactGroup.add(grp);
  }

  /**
   * Spawns or updates a 3-12 part procedural elemental champion with status effect visuals
   */
  public updateFighter(
    id: string,
    pos: { x: number; y: number; z: number },
    element: ElementType,
    isDodging: boolean,
    statusEffects: StatusEffect[] = []
  ) {
    let vf = this.fighters.get(id);
    const elemData = ELEMENTS[element];

    if (!vf) {
      const group = new THREE.Group();

      // 1. Contact shadow disc
      const shadowGeo = new THREE.CircleGeometry(0.85, 24);
      const shadowMat = new THREE.MeshBasicMaterial({
        color: 0x000000,
        transparent: true,
        opacity: 0.45,
        depthWrite: false,
      });
      const shadowMesh = new THREE.Mesh(shadowGeo, shadowMat);
      shadowMesh.rotation.x = -Math.PI / 2;
      shadowMesh.position.y = 0.02;
      group.add(shadowMesh);

      // 2. Robe / Lower Body
      const robeGeo = new THREE.CylinderGeometry(0.4, 0.75, 1.6, 12);
      const robeMat = new THREE.MeshStandardMaterial({
        color: 0x1e1b4b,
        roughness: 0.65,
        metalness: 0.2,
      });
      const robeMesh = new THREE.Mesh(robeGeo, robeMat);
      robeMesh.position.y = 0.8;
      robeMesh.castShadow = !this.isSoftwareGl;
      group.add(robeMesh);

      // 3. Torso / Shoulder Pauldrons
      const chestGeo = new THREE.BoxGeometry(0.85, 0.7, 0.55);
      const armorMat = new THREE.MeshStandardMaterial({
        color: 0x2e1065,
        roughness: 0.35,
        metalness: 0.7,
      });
      const chestMesh = new THREE.Mesh(chestGeo, armorMat);
      chestMesh.position.y = 1.45;
      chestMesh.castShadow = !this.isSoftwareGl;
      group.add(chestMesh);

      // 4. Hood / Cowl Head
      const headGeo = new THREE.SphereGeometry(0.36, 16, 16);
      const hoodMat = new THREE.MeshStandardMaterial({
        color: 0x1e1b4b,
        roughness: 0.7,
        metalness: 0.1,
      });
      const headMesh = new THREE.Mesh(headGeo, hoodMat);
      headMesh.position.y = 2.05;
      headMesh.castShadow = !this.isSoftwareGl;
      group.add(headMesh);

      // 5. Elemental Core / Glowing Visor
      const coreGeo = new THREE.SphereGeometry(0.18, 12, 12);
      const coreMat = new THREE.MeshStandardMaterial({
        color: elemData.hexColor,
        emissive: elemData.hexColor,
        emissiveIntensity: 1.5,
        roughness: 0.1,
      });
      const coreMesh = new THREE.Mesh(coreGeo, coreMat);
      coreMesh.position.set(0, 2.0, 0.28);
      group.add(coreMesh);

      // 6. Casting Staff
      const staffGroup = new THREE.Group();
      staffGroup.position.set(0.65, 0.9, 0.2);

      const shaftGeo = new THREE.CylinderGeometry(0.04, 0.04, 2.2, 8);
      const shaftMat = new THREE.MeshStandardMaterial({ color: 0x334155, roughness: 0.4, metalness: 0.6 });
      const shaft = new THREE.Mesh(shaftGeo, shaftMat);
      shaft.position.y = 0.5;
      shaft.castShadow = !this.isSoftwareGl;
      staffGroup.add(shaft);

      const crystalGeo = new THREE.OctahedronGeometry(0.2, 0);
      const crystalMat = new THREE.MeshStandardMaterial({
        color: elemData.hexColor,
        emissive: elemData.hexColor,
        emissiveIntensity: 1.8,
      });
      const crystal = new THREE.Mesh(crystalGeo, crystalMat);
      crystal.position.y = 1.6;
      staffGroup.add(crystal);
      group.add(staffGroup);

      // 7. Orbiting Elemental Orbs
      const orbs: THREE.Mesh[] = [];
      for (let i = 0; i < 3; i++) {
        const orbMat = new THREE.MeshStandardMaterial({
          color: elemData.hexColor,
          emissive: elemData.hexColor,
          emissiveIntensity: 1.4,
          roughness: 0.2,
        });
        const orb = new THREE.Mesh(this.orbGeo, orbMat);
        group.add(orb);
        orbs.push(orb);
      }

      // 8. Stun Electric Halo Mesh
      const haloGeo = new THREE.TorusGeometry(0.5, 0.05, 8, 24);
      const haloMat = new THREE.MeshBasicMaterial({ color: 0xfacc15, wireframe: true, transparent: true, opacity: 0 });
      const haloMesh = new THREE.Mesh(haloGeo, haloMat);
      haloMesh.rotation.x = Math.PI / 2;
      haloMesh.position.y = 2.65;
      group.add(haloMesh);

      // 9. Slow Frost Aura Mesh
      const frostGeo = new THREE.CylinderGeometry(0.8, 1.0, 0.3, 16);
      const frostMat = new THREE.MeshBasicMaterial({ color: 0x38bdf8, transparent: true, opacity: 0 });
      const frostMesh = new THREE.Mesh(frostGeo, frostMat);
      frostMesh.position.y = 0.15;
      group.add(frostMesh);

      group.position.set(pos.x, pos.y, pos.z);
      this.scene.add(group);

      vf = {
        group,
        robeMesh,
        coreMesh,
        staffMesh: crystal,
        orbs,
        shadowMesh,
        haloMesh,
        frostMesh,
        targetPos: new THREE.Vector3(pos.x, pos.y, pos.z),
        element,
        statusEffects: [],
      };
      this.fighters.set(id, vf);
    }

    vf.targetPos.set(pos.x, pos.y, pos.z);
    vf.statusEffects = statusEffects;

    // Update element colors if changed
    if (vf.element !== element) {
      vf.element = element;
      (vf.coreMesh.material as THREE.MeshStandardMaterial).color.setHex(elemData.hexColor);
      (vf.coreMesh.material as THREE.MeshStandardMaterial).emissive.setHex(elemData.hexColor);
      (vf.staffMesh.material as THREE.MeshStandardMaterial).color.setHex(elemData.hexColor);
      (vf.staffMesh.material as THREE.MeshStandardMaterial).emissive.setHex(elemData.hexColor);
      vf.orbs.forEach((orb) => {
        (orb.material as THREE.MeshStandardMaterial).color.setHex(elemData.hexColor);
        (orb.material as THREE.MeshStandardMaterial).emissive.setHex(elemData.hexColor);
      });
    }

    // Status effect visuals
    const isStunned = statusEffects.some((s) => s.type === 'stun');
    const isSlowed = statusEffects.some((s) => s.type === 'slow');
    const isBurning = statusEffects.some((s) => s.type === 'burn');

    (vf.haloMesh.material as THREE.MeshBasicMaterial).opacity = isStunned ? 0.9 : 0;
    (vf.frostMesh.material as THREE.MeshBasicMaterial).opacity = isSlowed ? 0.45 : 0;

    if (isBurning) {
      (vf.robeMesh.material as THREE.MeshStandardMaterial).emissive.setHex(0xff3700);
      (vf.robeMesh.material as THREE.MeshStandardMaterial).emissiveIntensity = 0.8;
      // Spawn occasional fire ember
      if (Math.random() < 0.25) {
        this.spawnStatusParticle(pos, 'burn');
      }
    } else {
      (vf.robeMesh.material as THREE.MeshStandardMaterial).emissive.setHex(0x000000);
      (vf.robeMesh.material as THREE.MeshStandardMaterial).emissiveIntensity = 0;
    }

    if (isStunned) {
      vf.haloMesh.rotation.z += 0.15;
      if (Math.random() < 0.3) {
        this.spawnStatusParticle(pos, 'stun');
      }
    }

    // Dodge animation tilt
    if (isDodging) {
      vf.group.rotation.z = THREE.MathUtils.damp(vf.group.rotation.z, 0.45, 12, 0.016);
      vf.group.scale.set(0.85, 0.7, 0.85);
    } else {
      vf.group.rotation.z = THREE.MathUtils.damp(vf.group.rotation.z, 0, 10, 0.016);
      vf.group.scale.set(1, 1, 1);
    }
  }

  public removeFighter(id: string) {
    const vf = this.fighters.get(id);
    if (vf) {
      this.scene.remove(vf.group);
      this.fighters.delete(id);
    }
  }

  public clearAllFighters() {
    this.fighters.forEach((vf) => this.scene.remove(vf.group));
    this.fighters.clear();
  }

  private spawnStatusParticle(pos: { x: number; y: number; z: number }, type: 'burn' | 'slow' | 'stun') {
    const color = type === 'burn' ? 0xff4500 : type === 'slow' ? 0x38bdf8 : 0xfacc15;
    _colorA.setHex(color);

    const pMat = new THREE.MeshBasicMaterial({ color: _colorA, transparent: true, opacity: 0.85 });
    const pMesh = new THREE.Mesh(this.particleGeo, pMat);
    pMesh.position.set(pos.x + (Math.random() - 0.5) * 0.8, pos.y + 0.5 + Math.random() * 1.5, pos.z + (Math.random() - 0.5) * 0.8);

    const vel = new THREE.Vector3((Math.random() - 0.5) * 0.8, type === 'burn' ? 2.5 : (Math.random() - 0.5) * 0.5, (Math.random() - 0.5) * 0.8);

    this.particleGroup.add(pMesh);
    this.activeParticles.push({
      mesh: pMesh,
      vel,
      rotVel: new THREE.Vector3(Math.random() * 4, Math.random() * 4, Math.random() * 4),
      life: 0,
      maxLife: 0.35,
      scaleStart: 0.18,
      colorStart: _colorA.clone(),
    });
  }

  public triggerCastEffect(pos: { x: number; y: number; z: number }, element: ElementType) {
    const color = ELEMENTS[element].hexColor;
    _colorA.setHex(color);

    for (let i = 0; i < 14; i++) {
      const pMat = new THREE.MeshBasicMaterial({ color: _colorA, transparent: true, opacity: 0.9 });
      const pMesh = new THREE.Mesh(this.particleGeo, pMat);
      pMesh.position.set(pos.x + (Math.random() - 0.5) * 0.4, pos.y + 1.2, pos.z + (Math.random() - 0.5) * 0.4);

      const angle = Math.random() * Math.PI * 2;
      const speed = 2 + Math.random() * 4;
      const vel = new THREE.Vector3(Math.cos(angle) * speed, Math.random() * 3 + 1, Math.sin(angle) * speed);

      this.particleGroup.add(pMesh);
      this.activeParticles.push({
        mesh: pMesh,
        vel,
        rotVel: new THREE.Vector3(Math.random() * 5, Math.random() * 5, Math.random() * 5),
        life: 0,
        maxLife: 0.4 + Math.random() * 0.3,
        scaleStart: 0.25,
        colorStart: _colorA.clone(),
      });
    }
  }

  public triggerImpactEffect(
    pos: { x: number; y: number; z: number },
    element: ElementType,
    isCritical: boolean,
    isUltimate: boolean
  ) {
    const count = isUltimate ? 40 : isCritical ? 24 : 14;
    const color = ELEMENTS[element].hexColor;
    _colorA.setHex(color);

    this.cameraShakeIntensity = Math.min(this.cameraShakeIntensity + (isUltimate ? 1.2 : isCritical ? 0.7 : 0.35), 2.0);

    for (let i = 0; i < count; i++) {
      const pMat = new THREE.MeshBasicMaterial({ color: _colorA, transparent: true, opacity: 1 });
      const pMesh = new THREE.Mesh(this.particleGeo, pMat);
      pMesh.position.set(pos.x, pos.y + 1.0, pos.z);

      const phi = Math.random() * Math.PI;
      const theta = Math.random() * Math.PI * 2;
      const speed = (isUltimate ? 6 : 3) + Math.random() * (isUltimate ? 8 : 4);

      const vel = new THREE.Vector3(
        Math.sin(phi) * Math.cos(theta) * speed,
        Math.abs(Math.cos(phi)) * speed * 0.8 + 1,
        Math.sin(phi) * Math.sin(theta) * speed
      );

      this.particleGroup.add(pMesh);
      this.activeParticles.push({
        mesh: pMesh,
        vel,
        rotVel: new THREE.Vector3(Math.random() * 8, Math.random() * 8, Math.random() * 8),
        life: 0,
        maxLife: (isUltimate ? 0.8 : 0.45) + Math.random() * 0.3,
        scaleStart: isUltimate ? 0.4 : 0.22,
        colorStart: _colorA.clone(),
      });
    }
  }

  public syncEarthCovers(covers: EarthCover[]) {
    const currentIds = new Set(covers.map((c) => c.id));

    for (const [id, mesh] of this.coverMeshes.entries()) {
      if (!currentIds.has(id)) {
        this.scene.remove(mesh);
        this.coverMeshes.delete(id);
      }
    }

    covers.forEach((c) => {
      let coverGroup = this.coverMeshes.get(c.id);
      if (!coverGroup) {
        coverGroup = new THREE.Group();

        const slabGeo = new THREE.BoxGeometry(2.4, 2.0, 0.6);
        const slabMat = new THREE.MeshStandardMaterial({
          color: 0x1f143d,
          roughness: 0.85,
          metalness: 0.1,
        });
        const slab = new THREE.Mesh(slabGeo, slabMat);
        slab.position.y = 1.0;
        slab.castShadow = !this.isSoftwareGl;
        coverGroup.add(slab);

        const veinGeo = new THREE.BoxGeometry(2.45, 0.25, 0.65);
        const veinMat = new THREE.MeshStandardMaterial({
          color: 0x10b981,
          emissive: 0x10b981,
          emissiveIntensity: 0.9,
          roughness: 0.2,
        });
        const vein = new THREE.Mesh(veinGeo, veinMat);
        vein.position.y = 1.2;
        coverGroup.add(vein);

        coverGroup.position.set(c.x, 0, c.z);
        coverGroup.scale.set(0.01, 0.01, 0.01);
        this.scene.add(coverGroup);
        this.coverMeshes.set(c.id, coverGroup);
      }

      coverGroup.scale.lerp(_vec3A.set(c.scale, c.scale, c.scale), 0.15);
    });
  }

  public syncProjectiles(projectiles: Projectile[]) {
    const currentIds = new Set(projectiles.map((p) => p.id));

    for (const [id, grp] of this.projectileMeshes.entries()) {
      if (!currentIds.has(id)) {
        this.scene.remove(grp);
        this.projectileMeshes.delete(id);
      }
    }

    projectiles.forEach((p) => {
      let grp = this.projectileMeshes.get(p.id);
      const elemData = ELEMENTS[p.element];

      if (!grp) {
        grp = new THREE.Group();

        if (p.element === 'fire') {
          const coreGeo = new THREE.SphereGeometry(p.isUltimate ? 0.9 : 0.35, 12, 12);
          const coreMat = new THREE.MeshStandardMaterial({
            color: 0xff4500,
            emissive: 0xff2200,
            emissiveIntensity: 2.0,
          });
          const core = new THREE.Mesh(coreGeo, coreMat);
          grp.add(core);
        } else if (p.element === 'water') {
          const coreGeo = new THREE.SphereGeometry(p.isUltimate ? 0.85 : 0.32, 14, 14);
          const coreMat = new THREE.MeshStandardMaterial({
            color: 0x0284c7,
            emissive: 0x38bdf8,
            emissiveIntensity: 1.4,
            roughness: 0.1,
          });
          const core = new THREE.Mesh(coreGeo, coreMat);
          grp.add(core);
        } else if (p.element === 'earth') {
          const coreGeo = new THREE.DodecahedronGeometry(p.isUltimate ? 0.95 : 0.38, 0);
          const coreMat = new THREE.MeshStandardMaterial({
            color: 0x064e3b,
            emissive: 0x10b981,
            emissiveIntensity: 0.8,
            roughness: 0.8,
          });
          const core = new THREE.Mesh(coreGeo, coreMat);
          grp.add(core);
        } else if (p.element === 'lightning') {
          const coreGeo = new THREE.OctahedronGeometry(p.isUltimate ? 0.8 : 0.32, 0);
          const coreMat = new THREE.MeshStandardMaterial({
            color: 0xc084fc,
            emissive: 0xa855f7,
            emissiveIntensity: 2.5,
          });
          const core = new THREE.Mesh(coreGeo, coreMat);
          grp.add(core);
        }

        if (!this.isSoftwareGl) {
          const light = new THREE.PointLight(elemData.hexColor, 1.2, 5);
          grp.add(light);
        }

        this.scene.add(grp);
        this.projectileMeshes.set(p.id, grp);
      }

      grp.position.set(p.x, p.y, p.z);
      grp.rotation.x += 0.08;
      grp.rotation.y += 0.12;

      // Trail
      if (Math.random() < 0.4) {
        _colorA.setHex(elemData.hexColor);
        const pMat = new THREE.MeshBasicMaterial({ color: _colorA, transparent: true, opacity: 0.8 });
        const pMesh = new THREE.Mesh(this.particleGeo, pMat);
        pMesh.position.copy(grp.position);

        this.particleGroup.add(pMesh);
        this.activeParticles.push({
          mesh: pMesh,
          vel: new THREE.Vector3((Math.random() - 0.5) * 0.5, (Math.random() - 0.5) * 0.5, (Math.random() - 0.5) * 0.5),
          rotVel: new THREE.Vector3(Math.random() * 4, Math.random() * 4, Math.random() * 4),
          life: 0,
          maxLife: 0.25,
          scaleStart: 0.15,
          colorStart: _colorA.clone(),
        });
      }
    });
  }

  private startLoop() {
    const tick = () => {
      const rawDt = this.clock.getDelta();
      const dt = Math.min(rawDt, 0.05);
      const time = this.clock.getElapsedTime();

      // 1. Update Fighters
      this.fighters.forEach((vf) => {
        vf.group.position.x = THREE.MathUtils.damp(vf.group.position.x, vf.targetPos.x, 14, dt);
        vf.group.position.z = THREE.MathUtils.damp(vf.group.position.z, vf.targetPos.z, 14, dt);

        vf.robeMesh.position.y = 0.8 + Math.sin(time * 3) * 0.04;
        vf.staffMesh.rotation.y += dt * 2.0;

        vf.orbs.forEach((orb, i) => {
          const orbAngle = time * 2.4 + (i * Math.PI * 2) / 3;
          orb.position.set(
            Math.cos(orbAngle) * 1.1,
            1.4 + Math.sin(time * 3 + i) * 0.2,
            Math.sin(orbAngle) * 1.1
          );
        });
      });

      // 2. Animate Hero Artifact in Dashboard
      if (this.heroArtifactGroup.children.length > 0) {
        const heroObj = this.heroArtifactGroup.children[0];
        heroObj.rotation.y += dt * 0.8;
        heroObj.rotation.x = Math.sin(time * 1.2) * 0.2;
        heroObj.position.y = 2.4 + Math.sin(time * 1.5) * 0.25;
      }

      // 3. Animate arena pillar crystals
      this.arenaGroup.traverse((child) => {
        if (child.userData?.isFloatingGem) {
          child.rotation.y += dt * child.userData.rotSpeed;
          child.rotation.x = Math.sin(time * 2) * 0.15;
          child.position.y = child.userData.baseHeight + Math.sin(time * 2.5) * 0.15;
        }
      });

      // 4. Update Particles
      for (let i = this.activeParticles.length - 1; i >= 0; i--) {
        const p = this.activeParticles[i];
        p.life += dt;
        if (p.life >= p.maxLife) {
          this.particleGroup.remove(p.mesh);
          (p.mesh.material as THREE.Material).dispose();
          this.activeParticles.splice(i, 1);
          continue;
        }

        p.mesh.position.addScaledVector(p.vel, dt);
        p.vel.y -= 7.0 * dt;
        p.mesh.rotation.x += p.rotVel.x * dt;
        p.mesh.rotation.y += p.rotVel.y * dt;

        const progress = p.life / p.maxLife;
        const scale = p.scaleStart * (1 - progress);
        p.mesh.scale.set(scale, scale, scale);
        (p.mesh.material as THREE.MeshBasicMaterial).opacity = 1 - progress;
      }

      // 5. Update Camera
      if (this.isInspectMode) {
        this.inspectAngle += dt * 0.4;
        this.camera.position.x = Math.sin(this.inspectAngle) * 20;
        this.camera.position.z = Math.cos(this.inspectAngle) * 20;
        this.camera.position.y = 12;
        this.camera.lookAt(0, 1.5, 0);
      } else {
        let shakeX = 0;
        let shakeY = 0;
        if (this.cameraShakeIntensity > 0.01) {
          shakeX = (Math.random() - 0.5) * this.cameraShakeIntensity * 0.8;
          shakeY = (Math.random() - 0.5) * this.cameraShakeIntensity * 0.8;
          this.cameraShakeIntensity = Math.max(0, this.cameraShakeIntensity - dt * 4.5);
        }

        this.camera.position.x = THREE.MathUtils.damp(this.camera.position.x, this.cameraBasePos.x + shakeX, 8, dt);
        this.camera.position.y = THREE.MathUtils.damp(this.camera.position.y, this.cameraBasePos.y + shakeY, 8, dt);
        this.camera.position.z = THREE.MathUtils.damp(this.camera.position.z, this.cameraBasePos.z, 8, dt);
        this.camera.lookAt(this.cameraLookTarget.x + shakeX * 0.3, this.cameraLookTarget.y, this.cameraLookTarget.z);
      }

      this.renderer.render(this.scene, this.camera);

      if (this.isSoftwareGl) {
        this.afterDraw(tick);
      } else {
        this.frameId = requestAnimationFrame(tick);
      }
    };

    if (this.isSoftwareGl) {
      this.afterDraw(tick);
    } else {
      this.frameId = requestAnimationFrame(tick);
    }
  }

  private afterDraw(cb: () => void) {
    const gl = this.renderer.getContext() as WebGL2RenderingContext;
    const sync = gl.fenceSync(gl.SYNC_GPU_COMMANDS_COMPLETE, 0);
    gl.flush();
    const poll = () => {
      const state = sync && gl.getSyncParameter(sync, gl.SYNC_STATUS);
      if (state === gl.UNSIGNALED) {
        this.frameId = window.setTimeout(poll, 5);
      } else {
        if (sync) gl.deleteSync(sync);
        this.frameId = window.setTimeout(cb, 60);
      }
    };
    this.frameId = window.setTimeout(poll, 5);
  }

  private onResize = () => {
    if (!this.container) return;
    const w = this.container.clientWidth;
    const h = this.container.clientHeight;
    this.camera.aspect = w / h;
    this.camera.updateProjectionMatrix();
    this.renderer.setSize(w, h);
  };

  public dispose() {
    window.removeEventListener('resize', this.onResize);
    cancelAnimationFrame(this.frameId);
    clearTimeout(this.frameId);

    this.fighters.forEach((vf) => this.scene.remove(vf.group));
    this.fighters.clear();

    this.projectileMeshes.forEach((grp) => this.scene.remove(grp));
    this.projectileMeshes.clear();

    this.coverMeshes.forEach((grp) => this.scene.remove(grp));
    this.coverMeshes.clear();

    this.activeParticles.forEach((p) => {
      this.particleGroup.remove(p.mesh);
      (p.mesh.material as THREE.Material).dispose();
    });
    this.activeParticles = [];

    this.renderer.dispose();
    if (this.renderer.domElement.parentElement) {
      this.renderer.domElement.parentElement.removeChild(this.renderer.domElement);
    }
  }
}
