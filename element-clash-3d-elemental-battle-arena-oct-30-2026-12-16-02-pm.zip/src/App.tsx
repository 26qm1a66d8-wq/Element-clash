/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useEffect, useRef, useState, useCallback } from 'react';
import {
  ElementType,
  GameMode,
  AIDifficulty,
  PlayerStats,
  FighterState,
  Projectile,
  EarthCover,
  FloatingText,
  UserAccount,
  NotificationItem,
  StatusEffect,
} from './types/game';
import { ELEMENTS, COMBOS, evaluateClash, getRankTier } from './game/constants';
import { sound } from './audio/soundEngine';
import { ThreeSceneManager } from './game/threeScene';
import { StorageService } from './services/storageService';
import { NavigationHeader } from './components/NavigationHeader';
import { DashboardView } from './components/DashboardView';
import { FriendsView } from './components/FriendsView';
import { LeaderboardView } from './components/LeaderboardView';
import { ProfileView } from './components/ProfileView';
import { DailyRewardsModal } from './components/DailyRewardsModal';
import { AuthModal } from './components/AuthModal';
import { HUD } from './components/HUD';
import { PauseModal } from './components/PauseModal';
import { MatchOverModal } from './components/MatchOverModal';
import { CounterGuideModal } from './components/CounterGuideModal';
import { ClashCinematicOverlay } from './components/ClashCinematicOverlay';

export default function App() {
  // Navigation & User State
  const [currentTab, setCurrentTab] = useState<'dashboard' | 'arena' | 'friends' | 'leaderboard' | 'profile' | 'rewards'>('dashboard');
  const [currentUser, setCurrentUser] = useState<UserAccount>(() => StorageService.getCurrentUser());
  const [allUsers, setAllUsers] = useState<UserAccount[]>(() => StorageService.getAllUsers());
  const [notifications, setNotifications] = useState<NotificationItem[]>(() => StorageService.getNotifications());

  // Modals
  const [showAuthModal, setShowAuthModal] = useState<boolean>(false);
  const [showDailyRewards, setShowDailyRewards] = useState<boolean>(false);
  const [showGuide, setShowGuide] = useState<boolean>(false);

  // Sound & Inspection
  const [isMuted, setIsMuted] = useState<boolean>(false);
  const [isInspectMode, setIsInspectMode] = useState<boolean>(false);

  // Active 3D Dashboard Hero Element
  const [activeHeroElement, setActiveHeroElement] = useState<ElementType>('fire');

  // Match State
  const [arenaActive, setArenaActive] = useState<boolean>(false);
  const [gameMode, setGameMode] = useState<GameMode>('duel');
  const [aiDifficulty, setAiDifficulty] = useState<AIDifficulty>('adept');
  const [matchResult, setMatchResult] = useState<'victory' | 'defeat' | 'draw'>('victory');
  const [matchTime, setMatchTime] = useState<number>(90);
  const [isPaused, setIsPaused] = useState<boolean>(false);
  const [isMatchOver, setIsMatchOver] = useState<boolean>(false);

  // End match statistics
  const [damageDealt, setDamageDealt] = useState<number>(0);
  const [clashesWon, setClashesWon] = useState<number>(0);
  const [lpChange, setLpChange] = useState<number>(0);
  const [xpEarned, setXpEarned] = useState<number>(0);

  // Clash Cinematic Overlay State
  const [clashCinematic, setClashCinematic] = useState<{
    active: boolean;
    playerElem: ElementType;
    oppElem: ElementType;
    result: 'player' | 'opponent' | 'draw';
    message: string;
    statusEffect?: 'burn' | 'slow' | 'stun';
  }>({
    active: false,
    playerElem: 'fire',
    oppElem: 'water',
    result: 'draw',
    message: '',
  });

  // Three.js Scene References
  const canvasMountRef = useRef<HTMLDivElement>(null);
  const threeManagerRef = useRef<ThreeSceneManager | null>(null);

  // Simulation Entities
  const [player, setPlayer] = useState<FighterState>({
    id: 'player_1',
    name: currentUser.username,
    avatar: currentUser.avatar,
    isPlayer: true,
    team: 1,
    hp: 100,
    maxHp: 100,
    shield: 0,
    currentElement: 'fire',
    energy: 15,
    cooldowns: { fire: 0, water: 0, earth: 0, lightning: 0 },
    ultimateCooldown: 0,
    coverCooldown: 0,
    isDodging: false,
    dodgeTimer: 0,
    position: { x: 0, y: 0, z: 6 },
    targetPosition: { x: 0, y: 0, z: 6 },
    statusEffects: [],
    consecutiveHitCount: 0,
    lightningCharges: 2,
  });

  const [opponents, setOpponents] = useState<FighterState[]>([]);
  const [allies, setAllies] = useState<FighterState[]>([]);
  const [projectiles, setProjectiles] = useState<Projectile[]>([]);
  const [covers, setCovers] = useState<EarthCover[]>([]);
  const [floatingTexts, setFloatingTexts] = useState<FloatingText[]>([]);

  // Input keys
  const heldKeys = useRef<Set<string>>(new Set());

  // Initialize Three.js scene once
  useEffect(() => {
    if (!canvasMountRef.current) return;
    const manager = new ThreeSceneManager(canvasMountRef.current);
    threeManagerRef.current = manager;
    manager.setDashboardHeroElement('fire');

    return () => {
      manager.dispose();
      threeManagerRef.current = null;
    };
  }, []);

  // Update Hero Element when in Dashboard
  useEffect(() => {
    if (threeManagerRef.current) {
      if (currentTab === 'dashboard' && !arenaActive) {
        threeManagerRef.current.setDashboardHeroElement(activeHeroElement);
      } else {
        threeManagerRef.current.setDashboardHeroElement(null);
      }
    }
  }, [currentTab, arenaActive, activeHeroElement]);

  const refreshUserData = useCallback(() => {
    const updated = StorageService.getCurrentUser();
    setCurrentUser(updated);
    setAllUsers(StorageService.getAllUsers());
    setNotifications(StorageService.getNotifications());
  }, []);

  const toggleMute = useCallback(() => {
    setIsMuted((prev) => {
      const next = !prev;
      sound.setMuted(next);
      return next;
    });
  }, []);

  const toggleInspect = useCallback(() => {
    setIsInspectMode((prev) => {
      const next = !prev;
      if (threeManagerRef.current) {
        threeManagerRef.current.isInspectMode = next;
      }
      return next;
    });
  }, []);

  // Start Arena Match
  const startMatch = useCallback(
    (mode: GameMode, difficulty: AIDifficulty, customOpponent?: UserAccount) => {
      setGameMode(mode);
      setAiDifficulty(difficulty);
      setMatchTime(mode === 'battle_royale' ? 120 : 90);
      setDamageDealt(0);
      setClashesWon(0);
      setProjectiles([]);
      setCovers([]);
      setFloatingTexts([]);
      setIsPaused(false);
      setIsMatchOver(false);

      if (threeManagerRef.current) {
        threeManagerRef.current.clearAllFighters();
        threeManagerRef.current.setDashboardHeroElement(null);
      }

      const maxHp = currentUser.activePerk === 'balanced' ? 110 : 100;
      const initialLightningCharges = currentUser.activePerk === 'voltaic_surge' ? 3 : 2;

      const p: FighterState = {
        id: 'player_1',
        name: currentUser.username,
        avatar: currentUser.avatar,
        isPlayer: true,
        team: 1,
        hp: maxHp,
        maxHp: maxHp,
        shield: 0,
        currentElement: 'fire',
        energy: 10,
        cooldowns: { fire: 0, water: 0, earth: 0, lightning: 0 },
        ultimateCooldown: 0,
        coverCooldown: 0,
        isDodging: false,
        dodgeTimer: 0,
        position: { x: 0, y: 0, z: 6 },
        targetPosition: { x: 0, y: 0, z: 6 },
        statusEffects: [],
        consecutiveHitCount: 0,
        lightningCharges: initialLightningCharges,
      };
      setPlayer(p);

      // Opponent configuration
      const opps: FighterState[] = [];
      if (customOpponent) {
        opps.push({
          id: customOpponent.id,
          name: customOpponent.username,
          avatar: customOpponent.avatar,
          isPlayer: false,
          team: 2,
          hp: 110,
          maxHp: 110,
          shield: 0,
          currentElement: 'water',
          energy: 0,
          cooldowns: { fire: 0, water: 0, earth: 0, lightning: 0 },
          ultimateCooldown: 0,
          coverCooldown: 0,
          isDodging: false,
          dodgeTimer: 0,
          position: { x: 0, y: 0, z: -6 },
          targetPosition: { x: 0, y: 0, z: -6 },
          statusEffects: [],
          consecutiveHitCount: 0,
          lightningCharges: 2,
        });
      } else if (mode === 'duel' || mode === 'practice' || mode === 'random_ranked' || mode === 'pvp_friend') {
        const oppName =
          mode === 'practice'
            ? 'Training Automaton'
            : difficulty === 'grandmaster'
            ? 'ValkyriePrime'
            : 'IgnisImperator';
        const oppAvatar = difficulty === 'grandmaster' ? '⚡' : '🔥';
        opps.push({
          id: 'bot_1',
          name: oppName,
          avatar: oppAvatar,
          isPlayer: false,
          team: 2,
          hp: difficulty === 'grandmaster' ? 140 : 100,
          maxHp: difficulty === 'grandmaster' ? 140 : 100,
          shield: 0,
          currentElement: 'water',
          energy: 0,
          cooldowns: { fire: 0, water: 0, earth: 0, lightning: 0 },
          ultimateCooldown: 0,
          coverCooldown: 0,
          isDodging: false,
          dodgeTimer: 0,
          position: { x: 0, y: 0, z: -6 },
          targetPosition: { x: 0, y: 0, z: -6 },
          statusEffects: [],
          consecutiveHitCount: 0,
          lightningCharges: 2,
        });
      }

      setOpponents(opps);
      setArenaActive(true);
      setCurrentTab('arena');
    },
    [currentUser]
  );

  // Cast Element
  const handleCastElement = useCallback(
    (element: ElementType) => {
      // Check if player is stunned
      if (player.statusEffects.some((s) => s.type === 'stun')) return;
      if (player.cooldowns[element] > 0 || player.isDodging) return;

      // Check lightning charges
      if (element === 'lightning') {
        if (player.lightningCharges <= 0) return;
        setPlayer((prev) => ({ ...prev, lightningCharges: Math.max(0, prev.lightningCharges - 1) }));
      }

      const elemData = ELEMENTS[element];
      const targetOpp = opponents.find((o) => o.hp > 0);
      if (!targetOpp) return;

      sound.playCast(element);
      if (threeManagerRef.current) {
        threeManagerRef.current.triggerCastEffect(player.position, element);
      }

      // Add Projectile
      const isSlowed = player.statusEffects.some((s) => s.type === 'slow');
      const projSpeed = isSlowed ? 11 : 16;

      const newProj: Projectile = {
        id: `proj_${Date.now()}_${Math.random()}`,
        casterId: player.id,
        targetId: targetOpp.id,
        element,
        isUltimate: false,
        isCombo: false,
        x: player.position.x,
        y: player.position.y + 1.2,
        z: player.position.z - 0.5,
        targetX: targetOpp.position.x,
        targetY: targetOpp.position.y + 1.2,
        targetZ: targetOpp.position.z,
        speed: projSpeed,
        radius: 0.6,
        damage: elemData.baseDamage * (currentUser.activePerk === 'pyro_fury' && element === 'fire' ? 1.15 : 1.0),
        lifetime: 2.5,
      };

      setProjectiles((prev) => [...prev, newProj]);

      // Cooldown (slow effect delays cooldowns)
      const cdMult = isSlowed ? 1.45 : currentUser.activePerk === 'balanced' ? 0.9 : 1.0;
      setPlayer((prev) => ({
        ...prev,
        currentElement: element,
        cooldowns: {
          ...prev.cooldowns,
          [element]: elemData.cooldown * cdMult,
        },
      }));
    },
    [player, opponents, currentUser]
  );

  // Cast Combo
  const handleCastCombo = useCallback(
    (comboId: string) => {
      if (player.statusEffects.some((s) => s.type === 'stun')) return;
      const combo = COMBOS.find((c) => c.id === comboId);
      const targetOpp = opponents.find((o) => o.hp > 0);
      if (!combo || !targetOpp) return;

      sound.playCast(combo.elementA, true);
      if (threeManagerRef.current) {
        threeManagerRef.current.triggerCastEffect(player.position, combo.elementA);
      }

      if (combo.id === 'nature_aegis') {
        setPlayer((prev) => ({
          ...prev,
          hp: Math.min(prev.maxHp, prev.hp + 30),
        }));
        setFloatingTexts((prev) => [
          ...prev,
          {
            id: `heal_${Date.now()}`,
            text: '+30 HP HEALED',
            color: '#34d399',
            x: 0,
            y: 0,
            scale: 1,
            opacity: 1,
            isCritical: false,
          },
        ]);
      }

      const newProj: Projectile = {
        id: `combo_${Date.now()}`,
        casterId: player.id,
        targetId: targetOpp.id,
        element: combo.elementB,
        isUltimate: false,
        isCombo: true,
        comboName: combo.name,
        x: player.position.x,
        y: player.position.y + 1.2,
        z: player.position.z - 0.5,
        targetX: targetOpp.position.x,
        targetY: targetOpp.position.y + 1.2,
        targetZ: targetOpp.position.z,
        speed: 18,
        radius: 0.8,
        damage: 28 * combo.damageMultiplier,
        lifetime: 2.5,
      };

      setProjectiles((prev) => [...prev, newProj]);
      setFloatingTexts((prev) => [
        ...prev,
        {
          id: `combo_txt_${Date.now()}`,
          text: `FUSION: ${combo.name}!`,
          color: combo.color,
          x: 0,
          y: 0,
          scale: 1.15,
          opacity: 1,
          isCritical: true,
        },
      ]);
    },
    [player, opponents]
  );

  // Cast Ultimate
  const handleCastUltimate = useCallback(() => {
    if (player.statusEffects.some((s) => s.type === 'stun')) return;
    if (player.energy < 100 || player.ultimateCooldown > 0) return;
    const targetOpp = opponents.find((o) => o.hp > 0);
    if (!targetOpp) return;

    const elem = player.currentElement;
    sound.playCast(elem, true);

    if (threeManagerRef.current) {
      threeManagerRef.current.triggerCastEffect(player.position, elem);
    }

    const newProj: Projectile = {
      id: `ult_${Date.now()}`,
      casterId: player.id,
      targetId: targetOpp.id,
      element: elem,
      isUltimate: true,
      isCombo: false,
      x: player.position.x,
      y: player.position.y + 1.8,
      z: player.position.z - 0.5,
      targetX: targetOpp.position.x,
      targetY: targetOpp.position.y + 1.8,
      targetZ: targetOpp.position.z,
      speed: 14,
      radius: 1.5,
      damage: 75,
      lifetime: 3.5,
    };

    setProjectiles((prev) => [...prev, newProj]);
    setPlayer((prev) => ({
      ...prev,
      energy: 0,
      ultimateCooldown: ELEMENTS[elem].ultimateCooldown,
      lightningCharges: Math.min(2, prev.lightningCharges + 1), // restore 1 lightning charge
    }));

    setFloatingTexts((prev) => [
      ...prev,
      {
        id: `ult_txt_${Date.now()}`,
        text: `BURST: ${ELEMENTS[elem].ultimateName}!`,
        color: '#facc15',
        x: 0,
        y: 0,
        scale: 1.3,
        opacity: 1,
        isCritical: true,
      },
    ]);
  }, [player, opponents]);

  // Spawn Earth Cover
  const handleSpawnCover = useCallback(() => {
    if (player.statusEffects.some((s) => s.type === 'stun')) return;
    if (player.coverCooldown > 0) return;

    sound.playCoverSpawn();
    const coverHp = currentUser.activePerk === 'granite_shell' ? 95 : 65;
    const newCover: EarthCover = {
      id: `cover_${Date.now()}`,
      casterId: player.id,
      x: player.position.x,
      z: player.position.z - 2.0,
      hp: coverHp,
      maxHp: coverHp,
      scale: 1.0,
    };

    setCovers((prev) => [...prev, newCover]);
    setPlayer((prev) => ({
      ...prev,
      coverCooldown: 5.5,
    }));

    setFloatingTexts((prev) => [
      ...prev,
      {
        id: `cover_txt_${Date.now()}`,
        text: 'EARTH BARRIER SUMMONED!',
        color: '#34d399',
        x: 0,
        y: 0,
        scale: 1,
        opacity: 1,
        isCritical: false,
      },
    ]);
  }, [player, currentUser]);

  // Dash
  const handleDodge = useCallback(() => {
    if (player.statusEffects.some((s) => s.type === 'stun')) return;
    if (player.dodgeTimer > 0) return;

    sound.playDodge();
    setPlayer((prev) => ({
      ...prev,
      isDodging: true,
      dodgeTimer: 2.2,
    }));

    setTimeout(() => {
      setPlayer((prev) => ({ ...prev, isDodging: false }));
    }, 400);
  }, [player]);

  // Complete Match and Update Storage
  const finishMatch = useCallback(
    (outcome: 'victory' | 'defeat' | 'draw') => {
      setIsMatchOver(true);
      setMatchResult(outcome);

      const isWin = outcome === 'victory';
      const isLoss = outcome === 'defeat';
      const lp = isWin ? 35 : isLoss ? -20 : 5;
      const xp = isWin ? 120 : isLoss ? 45 : 70;

      setLpChange(lp);
      setXpEarned(xp);

      if (isWin) sound.playVictory();
      else if (isLoss) sound.playDefeat();

      // Create Battle Record
      const newRec = {
        id: `rec_${Date.now()}`,
        timestamp: Date.now(),
        opponentName: opponents[0]?.name || 'Opponent',
        opponentAvatar: opponents[0]?.avatar || '🤖',
        playerElement: player.currentElement,
        opponentElement: opponents[0]?.currentElement || 'water',
        result: outcome,
        damageDealt: Math.round(damageDealt),
        lpChange: lp,
        xpEarned: xp,
        mode: gameMode,
      };

      // Update User Persistence
      const nextWins = isWin ? currentUser.wins + 1 : currentUser.wins;
      const nextLosses = isLoss ? currentUser.losses + 1 : currentUser.losses;
      const nextDraws = outcome === 'draw' ? currentUser.draws + 1 : currentUser.draws;
      const nextStreak = isWin ? currentUser.streak + 1 : 0;
      const bestStreak = Math.max(currentUser.bestStreak, nextStreak);
      const nextLP = Math.max(0, currentUser.rankPoints + lp);

      const newTotalXp = currentUser.xp + xp;
      const threshold = currentUser.level * 150;
      const nextLevel = newTotalXp >= threshold ? currentUser.level + 1 : currentUser.level;
      const finalXp = newTotalXp >= threshold ? newTotalXp - threshold : newTotalXp;

      // Update daily missions progress
      const updatedMissions = currentUser.dailyMissions.map((m) => {
        if (m.id === 'm_1' && player.currentElement === 'fire') {
          return { ...m, progress: Math.min(m.target, m.progress + Math.round(damageDealt)) };
        }
        if (m.id === 'm_3' && isWin) {
          return { ...m, progress: Math.min(m.target, m.progress + 1) };
        }
        return m;
      });

      const updated = StorageService.updateUser({
        wins: nextWins,
        losses: nextLosses,
        draws: nextDraws,
        streak: nextStreak,
        bestStreak,
        rankPoints: nextLP,
        xp: finalXp,
        level: nextLevel,
        battleHistory: [newRec, ...currentUser.battleHistory].slice(0, 30),
        dailyMissions: updatedMissions,
      });

      setCurrentUser(updated);
      setAllUsers(StorageService.getAllUsers());
    },
    [currentUser, opponents, player, damageDealt, gameMode]
  );

  // Main 60fps Game Loop
  useEffect(() => {
    if (!arenaActive || isPaused || isMatchOver) return;

    let animFrame: number;
    let lastTime = performance.now();

    const loop = (currentTime: number) => {
      const dt = Math.min((currentTime - lastTime) / 1000, 0.05);
      lastTime = currentTime;

      // 1. Player Status Effects Processing (Burn DoT, Slow, Stun timers)
      setPlayer((prev) => {
        const isStunned = prev.statusEffects.some((s) => s.type === 'stun');
        const isSlowed = prev.statusEffects.some((s) => s.type === 'slow');

        // Burn DoT ticking
        let burnDmg = 0;
        const nextEffects: StatusEffect[] = [];

        prev.statusEffects.forEach((eff) => {
          eff.remainingTime -= dt;
          if (eff.type === 'burn') {
            eff.tickTimer = (eff.tickTimer || 0) + dt;
            if (eff.tickTimer >= 0.8) {
              eff.tickTimer = 0;
              burnDmg += 4;
            }
          }
          if (eff.remainingTime > 0) {
            nextEffects.push(eff);
          }
        });

        if (burnDmg > 0) {
          sound.playHit('fire');
          setFloatingTexts((ft) => [
            ...ft,
            {
              id: `burn_${Date.now()}`,
              text: `🔥 Burn -${burnDmg} HP`,
              color: '#f97316',
              x: 0,
              y: 0,
              scale: 0.95,
              opacity: 1,
              isCritical: false,
            },
          ]);
        }

        // Movement Speed
        const baseSpeed = isSlowed ? 4.0 : 7.5;
        let dx = 0;
        let dz = 0;

        if (!isStunned) {
          if (heldKeys.current.has('KeyW') || heldKeys.current.has('ArrowUp')) dz -= 1;
          if (heldKeys.current.has('KeyS') || heldKeys.current.has('ArrowDown')) dz += 1;
          if (heldKeys.current.has('KeyA') || heldKeys.current.has('ArrowLeft')) dx -= 1;
          if (heldKeys.current.has('KeyD') || heldKeys.current.has('ArrowRight')) dx += 1;

          if (dx !== 0 || dz !== 0) {
            const len = Math.hypot(dx, dz);
            dx /= len;
            dz /= len;
          }
        }

        let newX = prev.position.x + dx * baseSpeed * dt;
        let newZ = prev.position.z + dz * baseSpeed * dt;

        const dist = Math.hypot(newX, newZ);
        if (dist > 11.5) {
          newX = (newX / dist) * 11.5;
          newZ = (newZ / dist) * 11.5;
        }

        // Cooldowns
        const cds = { ...prev.cooldowns };
        (Object.keys(cds) as ElementType[]).forEach((el) => {
          if (cds[el] > 0) cds[el] = Math.max(0, cds[el] - dt);
        });

        return {
          ...prev,
          hp: Math.max(0, prev.hp - burnDmg),
          position: { x: newX, y: 0, z: newZ },
          statusEffects: nextEffects,
          cooldowns: cds,
          ultimateCooldown: Math.max(0, prev.ultimateCooldown - dt),
          coverCooldown: Math.max(0, prev.coverCooldown - dt),
          dodgeTimer: Math.max(0, prev.dodgeTimer - dt),
        };
      });

      // 2. Opponents Logic & Status Effects
      setOpponents((prevOpps) =>
        prevOpps.map((opp) => {
          if (opp.hp <= 0) return opp;

          const isStunned = opp.statusEffects.some((s) => s.type === 'stun');
          const isSlowed = opp.statusEffects.some((s) => s.type === 'slow');

          // Burn DoT
          let burnDmg = 0;
          const nextEffects: StatusEffect[] = [];
          opp.statusEffects.forEach((eff) => {
            eff.remainingTime -= dt;
            if (eff.type === 'burn') {
              eff.tickTimer = (eff.tickTimer || 0) + dt;
              if (eff.tickTimer >= 0.8) {
                eff.tickTimer = 0;
                burnDmg += 4;
              }
            }
            if (eff.remainingTime > 0) {
              nextEffects.push(eff);
            }
          });

          if (burnDmg > 0) {
            setDamageDealt((d) => d + burnDmg);
            setFloatingTexts((ft) => [
              ...ft,
              {
                id: `opp_burn_${Date.now()}`,
                text: `🔥 Burn -${burnDmg} HP`,
                color: '#f97316',
                x: 0,
                y: 0,
                scale: 0.95,
                opacity: 1,
                isCritical: false,
              },
            ]);
          }

          // Movement
          let oppX = opp.position.x;
          let oppZ = opp.position.z;
          if (!isStunned) {
            const strafeSpeed = isSlowed ? 2.0 : aiDifficulty === 'grandmaster' ? 4.5 : 3.0;
            oppX += Math.sin(currentTime * 0.002) * strafeSpeed * dt;
            oppZ += Math.cos(currentTime * 0.0015) * 0.8 * dt;

            const d = Math.hypot(oppX, oppZ);
            if (d > 11.5) {
              oppX = (oppX / d) * 11.5;
              oppZ = (oppZ / d) * 11.5;
            }
          }

          // Cooldowns
          const cds = { ...opp.cooldowns };
          (Object.keys(cds) as ElementType[]).forEach((el) => {
            if (cds[el] > 0) cds[el] = Math.max(0, cds[el] - dt);
          });

          // AI Casting
          const canCast = Object.values(cds).some((v) => v <= 0);
          if (!isStunned && canCast && Math.random() < (aiDifficulty === 'grandmaster' ? 0.035 : 0.018)) {
            let chosenElem: ElementType = 'fire';
            if (aiDifficulty !== 'apprentice') {
              // Counter AI logic
              if (player.currentElement === 'earth') chosenElem = 'fire';
              else if (player.currentElement === 'fire') chosenElem = 'water';
              else if (player.currentElement === 'water') chosenElem = Math.random() < 0.6 ? 'lightning' : 'earth';
              else if (player.currentElement === 'lightning') chosenElem = 'fire'; // Fire beats Lightning
            } else {
              const allElems: ElementType[] = ['fire', 'water', 'earth'];
              chosenElem = allElems[Math.floor(Math.random() * allElems.length)];
            }

            if (cds[chosenElem] <= 0) {
              cds[chosenElem] = ELEMENTS[chosenElem].cooldown * (isSlowed ? 1.45 : 1.2);

              sound.playCast(chosenElem);
              if (threeManagerRef.current) {
                threeManagerRef.current.triggerCastEffect(opp.position, chosenElem);
              }

              const newProj: Projectile = {
                id: `bot_proj_${Date.now()}_${Math.random()}`,
                casterId: opp.id,
                targetId: player.id,
                element: chosenElem,
                isUltimate: false,
                isCombo: false,
                x: opp.position.x,
                y: opp.position.y + 1.2,
                z: opp.position.z + 0.5,
                targetX: player.position.x,
                targetY: player.position.y + 1.2,
                targetZ: player.position.z,
                speed: 14,
                radius: 0.6,
                damage: ELEMENTS[chosenElem].baseDamage,
                lifetime: 2.5,
              };

              setProjectiles((p) => [...p, newProj]);
            }
          }

          return {
            ...opp,
            hp: Math.max(0, opp.hp - burnDmg),
            position: { x: oppX, y: 0, z: oppZ },
            statusEffects: nextEffects,
            cooldowns: cds,
          };
        })
      );

      // 3. Projectiles & Collision with Status Effects application
      setProjectiles((prevProjs) => {
        const remaining: Projectile[] = [];

        prevProjs.forEach((p) => {
          p.lifetime -= dt;
          if (p.lifetime <= 0) return;

          const vx = p.targetX - p.x;
          const vz = p.targetZ - p.z;
          const dist = Math.hypot(vx, vz);

          if (dist > 0.3) {
            p.x += (vx / dist) * p.speed * dt;
            p.z += (vz / dist) * p.speed * dt;
          }

          // Check Earth Covers
          let blockedByCover = false;
          setCovers((prevCovers) =>
            prevCovers
              .map((cover) => {
                const coverDist = Math.hypot(p.x - cover.x, p.z - cover.z);
                if (coverDist < 1.4) {
                  blockedByCover = true;
                  sound.playNullified();
                  if (threeManagerRef.current) {
                    threeManagerRef.current.triggerImpactEffect(
                      { x: cover.x, y: 1.0, z: cover.z },
                      p.element,
                      false,
                      false
                    );
                  }
                  setFloatingTexts((ft) => [
                    ...ft,
                    {
                      id: `blocked_${Date.now()}`,
                      text: 'BLOCKED BY COVER!',
                      color: '#a1a1aa',
                      x: 0,
                      y: 0,
                      scale: 1,
                      opacity: 1,
                      isCritical: false,
                    },
                  ]);
                  return { ...cover, hp: cover.hp - p.damage };
                }
                return cover;
              })
              .filter((c) => c.hp > 0)
          );

          if (blockedByCover) return;

          // Target Hit
          const isPlayerTarget = p.targetId === player.id;
          const targetFighter = isPlayerTarget ? player : opponents.find((o) => o.id === p.targetId);

          if (targetFighter && targetFighter.hp > 0) {
            const hitDist = Math.hypot(p.x - targetFighter.position.x, p.z - targetFighter.position.z);
            if (hitDist < p.radius + 0.6) {
              if (targetFighter.isDodging) {
                setFloatingTexts((ft) => [
                  ...ft,
                  {
                    id: `evade_${Date.now()}`,
                    text: 'DODGED!',
                    color: '#38bdf8',
                    x: 0,
                    y: 0,
                    scale: 1,
                    opacity: 1,
                    isCritical: false,
                  },
                ]);
                return;
              }

              // Evaluate Counter Matrix
              const clash = evaluateClash(p.element, targetFighter.currentElement);
              const isCrit = clash.multiplier >= 1.5;

              sound.playHit(p.element, isCrit);
              if (isCrit && p.casterId === player.id) sound.playCounterWin();

              if (threeManagerRef.current) {
                threeManagerRef.current.triggerImpactEffect(
                  targetFighter.position,
                  p.element,
                  isCrit,
                  p.isUltimate
                );
              }

              const finalDamage = p.damage * clash.multiplier;

              // Check Consecutive Hit Stun Condition
              // "Lightning stuns for a short duration when the opponent is hit by specific elements consecutively"
              const wasHitByWater = targetFighter.lastHitByElement === 'water' && p.element === 'lightning';
              const wasConsecutiveTwo = targetFighter.consecutiveHitCount >= 1 && p.element === 'lightning';
              const triggersStun = wasHitByWater || wasConsecutiveTwo;

              // Status Effects to Apply:
              const newStatusEffects: StatusEffect[] = [];

              if (p.element === 'fire') {
                // Fire applies Burn DoT
                newStatusEffects.push({
                  type: 'burn',
                  duration: 3.5,
                  remainingTime: 3.5,
                  sourceElement: 'fire',
                });
              } else if (p.element === 'water') {
                // Water applies Slow
                newStatusEffects.push({
                  type: 'slow',
                  duration: 3.5,
                  remainingTime: 3.5,
                  sourceElement: 'water',
                });
              }

              if (triggersStun) {
                // Consecutive Lightning Stun!
                newStatusEffects.push({
                  type: 'stun',
                  duration: 1.8,
                  remainingTime: 1.8,
                  sourceElement: 'lightning',
                });
              }

              if (isPlayerTarget) {
                setPlayer((prev) => ({
                  ...prev,
                  hp: Math.max(0, prev.hp - finalDamage),
                  energy: Math.min(100, prev.energy + 10),
                  statusEffects: [...prev.statusEffects, ...newStatusEffects],
                  lastHitByElement: p.element,
                  consecutiveHitCount: prev.consecutiveHitCount + 1,
                }));
              } else {
                setOpponents((prevOpps) =>
                  prevOpps.map((opp) =>
                    opp.id === targetFighter.id
                      ? {
                          ...opp,
                          hp: Math.max(0, opp.hp - finalDamage),
                          statusEffects: [...opp.statusEffects, ...newStatusEffects],
                          lastHitByElement: p.element,
                          consecutiveHitCount: opp.consecutiveHitCount + 1,
                        }
                      : opp
                  )
                );

                setDamageDealt((d) => d + finalDamage);
                if (isCrit) {
                  setClashesWon((c) => c + 1);
                  setPlayer((prev) => ({
                    ...prev,
                    energy: Math.min(100, prev.energy + 25),
                    lightningCharges: Math.min(2, prev.lightningCharges + 1), // restore charge on counter
                  }));
                }

                if (newStatusEffects.length > 0) {
                  StorageService.updateUser({
                    statusEffectsInflicted: (currentUser.statusEffectsInflicted || 0) + 1,
                  });
                }
              }

              // Text feedback
              let textMsg = `${clash.message} -${Math.round(finalDamage)} HP`;
              if (triggersStun) {
                textMsg = `⚡ SUPERCONDUCTIVE STUN! (1.8s)`;
              }

              setFloatingTexts((ft) => [
                ...ft,
                {
                  id: `hit_${Date.now()}_${Math.random()}`,
                  text: textMsg,
                  color: triggersStun ? '#facc15' : isCrit ? '#facc15' : '#f87171',
                  x: 0,
                  y: 0,
                  scale: triggersStun ? 1.35 : isCrit ? 1.2 : 1.0,
                  opacity: 1,
                  isCritical: isCrit || triggersStun,
                },
              ]);

              return;
            }
          }

          remaining.push(p);
        });

        return remaining;
      });

      // 4. Clean up Floating Texts
      setFloatingTexts((prev) =>
        prev
          .map((ft) => ({ ...ft, opacity: ft.opacity - dt * 0.8 }))
          .filter((ft) => ft.opacity > 0)
      );

      // 5. Timer
      setMatchTime((prevTime) => Math.max(0, prevTime - dt));

      animFrame = requestAnimationFrame(loop);
    };

    animFrame = requestAnimationFrame(loop);
    return () => cancelAnimationFrame(animFrame);
  }, [arenaActive, isPaused, isMatchOver, player, opponents, aiDifficulty, currentUser]);

  // Win/Loss Condition
  useEffect(() => {
    if (!arenaActive || isMatchOver) return;

    if (player.hp <= 0) {
      finishMatch('defeat');
      return;
    }

    const aliveOpponents = opponents.filter((o) => o.hp > 0);
    if (opponents.length > 0 && aliveOpponents.length === 0) {
      finishMatch('victory');
      return;
    }

    if (matchTime <= 0) {
      const oppTotalHp = opponents.reduce((acc, o) => acc + o.hp, 0);
      if (player.hp > oppTotalHp) finishMatch('victory');
      else if (player.hp < oppTotalHp) finishMatch('defeat');
      else finishMatch('draw');
    }
  }, [player.hp, opponents, matchTime, arenaActive, isMatchOver, finishMatch]);

  // Sync 3D Scene
  useEffect(() => {
    const tm = threeManagerRef.current;
    if (!tm || !arenaActive) return;

    tm.updateFighter(
      player.id,
      player.position,
      player.currentElement,
      player.isDodging,
      player.statusEffects
    );

    opponents.forEach((opp) => {
      tm.updateFighter(opp.id, opp.position, opp.currentElement, opp.isDodging, opp.statusEffects);
    });

    tm.syncProjectiles(projectiles);
    tm.syncEarthCovers(covers);
  }, [player, opponents, projectiles, covers, arenaActive]);

  // Keyboard handler for arena
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      heldKeys.current.add(e.code);

      if (e.code === 'Escape' && arenaActive) {
        setIsPaused((prev) => !prev);
        return;
      }

      if (!arenaActive || isPaused || isMatchOver) return;

      if (e.code === 'Digit1' || e.code === 'Numpad1') handleCastElement('fire');
      else if (e.code === 'Digit2' || e.code === 'Numpad2') handleCastElement('water');
      else if (e.code === 'Digit3' || e.code === 'Numpad3') handleCastElement('earth');
      else if (e.code === 'Digit4' || e.code === 'Numpad4') handleCastElement('lightning');
      else if (e.code === 'KeyQ') handleSpawnCover();
      else if (e.code === 'ShiftLeft' || e.code === 'ShiftRight') handleDodge();
      else if (e.code === 'Space') handleCastUltimate();
    };

    const handleKeyUp = (e: KeyboardEvent) => {
      heldKeys.current.delete(e.code);
    };

    window.addEventListener('keydown', handleKeyDown);
    window.addEventListener('keyup', handleKeyUp);
    return () => {
      window.removeEventListener('keydown', handleKeyDown);
      window.removeEventListener('keyup', handleKeyUp);
    };
  }, [arenaActive, isPaused, isMatchOver, handleCastElement, handleSpawnCover, handleDodge, handleCastUltimate]);

  const handleClaimDailyMission = (missionId: string) => {
    const targetMission = currentUser.dailyMissions.find((m) => m.id === missionId);
    if (!targetMission || targetMission.claimed) return;

    sound.playVictory();
    const updatedMissions = currentUser.dailyMissions.map((m) =>
      m.id === missionId ? { ...m, claimed: true } : m
    );

    const updated = StorageService.updateUser({
      xp: currentUser.xp + targetMission.rewardXp,
      rankPoints: currentUser.rankPoints + targetMission.rewardLp,
      dailyMissions: updatedMissions,
    });
    setCurrentUser(updated);
  };

  const handleClaimDailyReward = () => {
    const updated = StorageService.updateUser({
      dailyRewardClaimed: true,
      xp: currentUser.xp + 100,
      rankPoints: currentUser.rankPoints + 25,
    });
    setCurrentUser(updated);
  };

  const handleChallengeFriend = (friend: UserAccount) => {
    startMatch('pvp_friend', 'adept', friend);
  };

  return (
    <div className="relative h-screen w-screen overflow-hidden bg-slate-950 font-sans select-none text-slate-100">
      {/* 3D WebGL Canvas Container */}
      <div ref={canvasMountRef} className="absolute inset-0 h-full w-full pointer-events-auto" />

      {/* Futuristic Navigation Header */}
      {!arenaActive && (
        <NavigationHeader
          currentUser={currentUser}
          currentTab={currentTab}
          onSelectTab={(tab) => {
            if (tab === 'arena') {
              startMatch('duel', 'adept');
            } else if (tab === 'rewards') {
              setShowDailyRewards(true);
            } else {
              setCurrentTab(tab);
            }
          }}
          notifications={notifications}
          onOpenAuth={() => setShowAuthModal(true)}
          isMuted={isMuted}
          onToggleMute={toggleMute}
          onAcceptFriendInvite={(fromId) => {
            const friend = allUsers.find((u) => u.id === fromId);
            if (friend) startMatch('pvp_friend', 'adept', friend);
          }}
        />
      )}

      {/* Main Views Container */}
      {!arenaActive && (
        <main className="relative z-10 w-full h-[calc(100vh-4rem)]">
          {currentTab === 'dashboard' && (
            <DashboardView
              currentUser={currentUser}
              onStartBattle={startMatch}
              onNavigateTab={(tab) => {
                if (tab === 'arena') startMatch('duel', 'adept');
                else if (tab === 'rewards') setShowDailyRewards(true);
                else setCurrentTab(tab);
              }}
              onSelectHeroElement={(elem) => setActiveHeroElement(elem)}
              activeHeroElement={activeHeroElement}
              onClaimDailyMission={handleClaimDailyMission}
            />
          )}

          {currentTab === 'friends' && (
            <FriendsView
              currentUser={currentUser}
              allUsers={allUsers}
              onRefreshUsers={refreshUserData}
              onChallengeFriend={handleChallengeFriend}
            />
          )}

          {currentTab === 'leaderboard' && (
            <LeaderboardView currentUser={currentUser} allUsers={allUsers} />
          )}

          {currentTab === 'profile' && (
            <ProfileView
              currentUser={currentUser}
              onUpdateProfile={(up) => {
                const u = StorageService.updateUser(up);
                setCurrentUser(u);
              }}
            />
          )}
        </main>
      )}

      {/* Active Battle Arena HUD */}
      {arenaActive && (
        <HUD
          player={player}
          opponents={opponents}
          allies={allies}
          matchTime={matchTime}
          stats={{
            wins: currentUser.wins,
            losses: currentUser.losses,
            draws: currentUser.draws,
            streak: currentUser.streak,
            bestStreak: currentUser.bestStreak,
            rankPoints: currentUser.rankPoints,
            xp: currentUser.xp,
            level: currentUser.level,
            unlockedLightning: true,
            activePerk: currentUser.activePerk,
            activeSkin: currentUser.activeSkin,
          }}
          mode={gameMode}
          floatingTexts={floatingTexts}
          onCastElement={handleCastElement}
          onCastUltimate={handleCastUltimate}
          onSpawnCover={handleSpawnCover}
          onDodge={handleDodge}
          onCastCombo={handleCastCombo}
          onPause={() => setIsPaused(true)}
          onOpenGuide={() => setShowGuide(true)}
          onToggleInspect={toggleInspect}
          isInspectMode={isInspectMode}
          isMuted={isMuted}
          onToggleMute={toggleMute}
          onExitToDashboard={() => {
            setArenaActive(false);
            setCurrentTab('dashboard');
          }}
        />
      )}

      {/* Clash Cinematic Overlay */}
      <ClashCinematicOverlay
        isActive={clashCinematic.active}
        playerAvatar={currentUser.avatar}
        playerName={currentUser.username}
        playerElement={clashCinematic.playerElem}
        opponentAvatar={opponents[0]?.avatar || '🤖'}
        opponentName={opponents[0]?.name || 'Opponent'}
        opponentElement={clashCinematic.oppElem}
        result={clashCinematic.result}
        message={clashCinematic.message}
        statusEffect={clashCinematic.statusEffect}
        onComplete={() => setClashCinematic((prev) => ({ ...prev, active: false }))}
      />

      {/* Paused Modal */}
      {isPaused && (
        <PauseModal
          isOpen={true}
          onResume={() => setIsPaused(false)}
          onRestart={() => startMatch(gameMode, aiDifficulty)}
          onReturnMenu={() => {
            setIsPaused(false);
            setArenaActive(false);
            setCurrentTab('dashboard');
          }}
          onOpenGuide={() => setShowGuide(true)}
          isMuted={isMuted}
          onToggleMute={toggleMute}
        />
      )}

      {/* Match Over Modal */}
      {isMatchOver && (
        <MatchOverModal
          result={matchResult}
          stats={{
            wins: currentUser.wins,
            losses: currentUser.losses,
            draws: currentUser.draws,
            streak: currentUser.streak,
            bestStreak: currentUser.bestStreak,
            rankPoints: currentUser.rankPoints,
            xp: currentUser.xp,
            level: currentUser.level,
            unlockedLightning: true,
            activePerk: currentUser.activePerk,
            activeSkin: currentUser.activeSkin,
          }}
          damageDealt={damageDealt}
          clashesWon={clashesWon}
          lpChange={lpChange}
          xpEarned={xpEarned}
          onRematch={() => startMatch(gameMode, aiDifficulty)}
          onReturnMenu={() => {
            setIsMatchOver(false);
            setArenaActive(false);
            setCurrentTab('dashboard');
          }}
        />
      )}

      {/* Counter Guide Modal */}
      <CounterGuideModal isOpen={showGuide} onClose={() => setShowGuide(false)} />

      {/* Daily Rewards Modal */}
      <DailyRewardsModal
        currentUser={currentUser}
        isOpen={showDailyRewards}
        onClose={() => setShowDailyRewards(false)}
        onClaimDailyReward={handleClaimDailyReward}
      />

      {/* Authentication Modal */}
      <AuthModal
        isOpen={showAuthModal}
        onClose={() => setShowAuthModal(false)}
        currentUser={currentUser}
        allUsers={allUsers}
        onAccountSwitched={(u) => {
          setCurrentUser(u);
          setAllUsers(StorageService.getAllUsers());
        }}
      />
    </div>
  );
}
