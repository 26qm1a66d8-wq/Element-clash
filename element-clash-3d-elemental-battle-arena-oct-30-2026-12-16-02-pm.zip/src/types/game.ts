/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export type ElementType = 'fire' | 'water' | 'earth' | 'lightning';

export type GameMode = 'duel' | 'pvp_friend' | 'random_ranked' | 'team_deathmatch' | 'battle_royale' | 'practice';

export type AIDifficulty = 'apprentice' | 'adept' | 'grandmaster';

export type StatusEffectType = 'burn' | 'slow' | 'stun';

export interface StatusEffect {
  type: StatusEffectType;
  duration: number;
  remainingTime: number;
  tickTimer?: number;
  value?: number;
  sourceElement: ElementType;
}

export interface PlayerStats {
  wins: number;
  losses: number;
  draws: number;
  streak: number;
  bestStreak: number;
  rankPoints: number;
  xp: number;
  level: number;
  unlockedLightning: boolean;
  activePerk: string;
  activeSkin: string;
}

export interface ElementInfo {
  id: ElementType;
  name: string;
  icon: string;
  color: string;
  glowColor: string;
  hexColor: number;
  description: string;
  beats: ElementType[];
  beatenBy: ElementType[];
  specialRule: string;
  baseDamage: number;
  cooldown: number; // in seconds
  ultimateName: string;
  ultimateDesc: string;
  ultimateCooldown: number;
}

export interface ComboSynergy {
  id: string;
  name: string;
  elementA: ElementType;
  elementB: ElementType;
  description: string;
  effect: string;
  damageMultiplier: number;
  color: string;
}

export interface BattleRecord {
  id: string;
  timestamp: number;
  opponentName: string;
  opponentAvatar: string;
  playerElement: ElementType;
  opponentElement: ElementType;
  result: 'victory' | 'defeat' | 'draw';
  damageDealt: number;
  lpChange: number;
  xpEarned: number;
  mode: GameMode;
}

export interface DailyMission {
  id: string;
  title: string;
  desc: string;
  rewardXp: number;
  rewardLp: number;
  progress: number;
  target: number;
  completed: boolean;
  claimed: boolean;
  icon: string;
}

export interface UserAccount {
  id: string;
  username: string;
  email: string;
  password?: string;
  playerTag: string; // e.g. #EC-8492
  avatar: string;
  title: string;
  level: number;
  xp: number;
  rankPoints: number; // LP
  wins: number;
  losses: number;
  draws: number;
  streak: number;
  bestStreak: number;
  countersWon: number;
  statusEffectsInflicted: number;
  friends: string[]; // user IDs
  pendingFriendRequests: string[]; // user IDs who sent requests
  achievements: string[];
  lastLoginDate: string;
  dailyRewardDay: number;
  dailyRewardClaimed: boolean;
  dailyMissions: DailyMission[];
  battleHistory: BattleRecord[];
  activePerk: string;
  activeSkin: string;
  lightningCharges: number;
  maxLightningCharges: number;
}

export interface NotificationItem {
  id: string;
  type: 'friend_request' | 'battle_invite' | 'achievement' | 'reward';
  title: string;
  message: string;
  fromUserId?: string;
  fromUsername?: string;
  timestamp: number;
  read: boolean;
}

export interface FighterState {
  id: string;
  name: string;
  avatar?: string;
  isPlayer: boolean;
  team: 1 | 2 | 3 | 4;
  hp: number;
  maxHp: number;
  shield: number;
  currentElement: ElementType;
  energy: number; // 0 to 100 for Ultimate
  cooldowns: Record<ElementType, number>;
  ultimateCooldown: number;
  coverCooldown: number;
  isDodging: boolean;
  dodgeTimer: number;
  position: { x: number; y: number; z: number };
  targetPosition: { x: number; y: number; z: number };
  // Status Effect System
  statusEffects: StatusEffect[];
  // Consecutive hits tracker for triggering Stun
  lastHitByElement?: ElementType;
  consecutiveHitCount: number;
  lightningCharges: number;
}

export interface Projectile {
  id: string;
  casterId: string;
  targetId: string;
  element: ElementType;
  isUltimate: boolean;
  isCombo: boolean;
  comboName?: string;
  x: number;
  y: number;
  z: number;
  targetX: number;
  targetY: number;
  targetZ: number;
  speed: number;
  radius: number;
  damage: number;
  lifetime: number;
}

export interface EarthCover {
  id: string;
  casterId: string;
  x: number;
  z: number;
  hp: number;
  maxHp: number;
  scale: number;
}

export interface FloatingText {
  id: string;
  text: string;
  color: string;
  x: number;
  y: number;
  scale: number;
  opacity: number;
  isCritical: boolean;
}

export interface ClashCinematicState {
  active: boolean;
  playerElement: ElementType;
  opponentElement: ElementType;
  phase: 'charging' | 'clashing' | 'impact' | 'resolved';
  winner: 'player' | 'opponent' | 'draw';
  statusEffectApplied?: StatusEffectType;
  narrativeText: string;
}
