/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { UserAccount, BattleRecord, DailyMission, NotificationItem } from '../types/game';
import { SEED_PLAYERS, INITIAL_DAILY_MISSIONS } from '../game/constants';

const USERS_STORAGE_KEY = 'element_clash_accounts_v2';
const CURRENT_USER_KEY = 'element_clash_current_user_v2';
const NOTIFICATIONS_KEY = 'element_clash_notifications_v2';

export class StorageService {
  public static getAllUsers(): UserAccount[] {
    try {
      const raw = localStorage.getItem(USERS_STORAGE_KEY);
      if (raw) {
        return JSON.parse(raw);
      }
    } catch {}

    // Initialize with seed players + default initial player
    const initialPlayers = [...SEED_PLAYERS];
    const defaultUser: UserAccount = {
      id: 'user_player_main',
      username: 'AetherMage',
      email: 'player@elementclash.gg',
      password: 'password123',
      playerTag: '#EC-7721',
      avatar: '🧙‍♂️',
      title: 'Grandmaster Archon',
      level: 5,
      xp: 180,
      rankPoints: 850, // Gold III
      wins: 18,
      losses: 5,
      draws: 2,
      streak: 4,
      bestStreak: 7,
      countersWon: 42,
      statusEffectsInflicted: 34,
      friends: ['user_valkyrie', 'user_ignis_lord'],
      pendingFriendRequests: ['user_tidal_queen'],
      achievements: ['first_blood', 'pyromancer'],
      lastLoginDate: new Date().toISOString().split('T')[0],
      dailyRewardDay: 3,
      dailyRewardClaimed: false,
      dailyMissions: [...INITIAL_DAILY_MISSIONS],
      battleHistory: [
        {
          id: 'bh_1',
          timestamp: Date.now() - 3600000 * 2,
          opponentName: 'IgnisImperator',
          opponentAvatar: '🔥',
          playerElement: 'water',
          opponentElement: 'fire',
          result: 'victory',
          damageDealt: 125,
          lpChange: 35,
          xpEarned: 120,
          mode: 'duel',
        },
        {
          id: 'bh_2',
          timestamp: Date.now() - 3600000 * 8,
          opponentName: 'ValkyriePrime',
          opponentAvatar: '⚡',
          playerElement: 'fire',
          opponentElement: 'lightning',
          result: 'victory',
          damageDealt: 140,
          lpChange: 35,
          xpEarned: 130,
          mode: 'duel',
        },
      ],
      activePerk: 'balanced',
      activeSkin: 'initiate',
      lightningCharges: 2,
      maxLightningCharges: 2,
    };

    const all = [defaultUser, ...initialPlayers];
    localStorage.setItem(USERS_STORAGE_KEY, JSON.stringify(all));
    return all;
  }

  public static saveAllUsers(users: UserAccount[]) {
    try {
      localStorage.setItem(USERS_STORAGE_KEY, JSON.stringify(users));
    } catch {}
  }

  public static getCurrentUser(): UserAccount {
    const all = this.getAllUsers();
    try {
      const currentId = localStorage.getItem(CURRENT_USER_KEY);
      if (currentId) {
        const found = all.find((u) => u.id === currentId);
        if (found) return found;
      }
    } catch {}
    // Return first user
    const fallback = all[0];
    localStorage.setItem(CURRENT_USER_KEY, fallback.id);
    return fallback;
  }

  public static setCurrentUser(user: UserAccount) {
    localStorage.setItem(CURRENT_USER_KEY, user.id);
    const all = this.getAllUsers();
    const idx = all.findIndex((u) => u.id === user.id);
    if (idx >= 0) {
      all[idx] = user;
    } else {
      all.push(user);
    }
    this.saveAllUsers(all);
  }

  public static updateUser(updates: Partial<UserAccount>): UserAccount {
    const current = this.getCurrentUser();
    const updated: UserAccount = { ...current, ...updates };
    this.setCurrentUser(updated);
    return updated;
  }

  public static register(
    username: string,
    email: string,
    password: string,
    avatar: string
  ): { success: boolean; user?: UserAccount; error?: string } {
    const all = this.getAllUsers();
    if (all.some((u) => u.username.toLowerCase() === username.toLowerCase())) {
      return { success: false, error: 'Username is already taken.' };
    }
    if (all.some((u) => u.email.toLowerCase() === email.toLowerCase())) {
      return { success: false, error: 'Email is already registered.' };
    }

    const randomTag = `#EC-${Math.floor(1000 + Math.random() * 9000)}`;
    const newUser: UserAccount = {
      id: `user_${Date.now()}`,
      username: username.trim(),
      email: email.trim().toLowerCase(),
      password,
      playerTag: randomTag,
      avatar: avatar || '🧙‍♂️',
      title: 'Novice Elementalist',
      level: 1,
      xp: 0,
      rankPoints: 100, // Bronze II
      wins: 0,
      losses: 0,
      draws: 0,
      streak: 0,
      bestStreak: 0,
      countersWon: 0,
      statusEffectsInflicted: 0,
      friends: [],
      pendingFriendRequests: [],
      achievements: [],
      lastLoginDate: new Date().toISOString().split('T')[0],
      dailyRewardDay: 1,
      dailyRewardClaimed: false,
      dailyMissions: [...INITIAL_DAILY_MISSIONS],
      battleHistory: [],
      activePerk: 'balanced',
      activeSkin: 'initiate',
      lightningCharges: 2,
      maxLightningCharges: 2,
    };

    all.push(newUser);
    this.saveAllUsers(all);
    this.setCurrentUser(newUser);

    return { success: true, user: newUser };
  }

  public static login(
    emailOrUsername: string,
    password: string
  ): { success: boolean; user?: UserAccount; error?: string } {
    const all = this.getAllUsers();
    const target = emailOrUsername.trim().toLowerCase();
    const user = all.find(
      (u) => u.email.toLowerCase() === target || u.username.toLowerCase() === target
    );

    if (!user) {
      return { success: false, error: 'Player account not found.' };
    }
    if (user.password && user.password !== password) {
      return { success: false, error: 'Invalid password. Please check your credentials.' };
    }

    this.setCurrentUser(user);
    return { success: true, user };
  }

  public static logout() {
    localStorage.removeItem(CURRENT_USER_KEY);
  }

  // --- SOCIAL / FRIENDS SYSTEM ---
  public static sendFriendRequest(targetUserId: string): boolean {
    const all = this.getAllUsers();
    const current = this.getCurrentUser();
    const target = all.find((u) => u.id === targetUserId);

    if (!target || target.id === current.id) return false;
    if (current.friends.includes(target.id)) return false;

    if (!target.pendingFriendRequests.includes(current.id)) {
      target.pendingFriendRequests.push(current.id);
      this.saveAllUsers(all);

      this.addNotification({
        id: `notif_${Date.now()}`,
        type: 'friend_request',
        title: 'Friend Request Sent',
        message: `You sent a friend request to ${target.username} (${target.playerTag})`,
        timestamp: Date.now(),
        read: false,
      });
      return true;
    }
    return false;
  }

  public static acceptFriendRequest(requesterId: string) {
    const all = this.getAllUsers();
    const current = this.getCurrentUser();
    const requester = all.find((u) => u.id === requesterId);

    if (!requester) return;

    // Remove from pending
    current.pendingFriendRequests = current.pendingFriendRequests.filter((id) => id !== requesterId);
    if (!current.friends.includes(requesterId)) {
      current.friends.push(requesterId);
    }
    if (!requester.friends.includes(current.id)) {
      requester.friends.push(current.id);
    }

    this.saveAllUsers(all);
    this.setCurrentUser(current);

    this.addNotification({
      id: `notif_${Date.now()}`,
      type: 'friend_request',
      title: 'Friend Added!',
      message: `You are now friends with ${requester.username}! Challenge them to a clash!`,
      timestamp: Date.now(),
      read: false,
    });
  }

  public static rejectFriendRequest(requesterId: string) {
    const current = this.getCurrentUser();
    current.pendingFriendRequests = current.pendingFriendRequests.filter((id) => id !== requesterId);
    this.setCurrentUser(current);
  }

  public static removeFriend(friendId: string) {
    const all = this.getAllUsers();
    const current = this.getCurrentUser();
    const target = all.find((u) => u.id === friendId);

    current.friends = current.friends.filter((id) => id !== friendId);
    if (target) {
      target.friends = target.friends.filter((id) => id !== current.id);
    }

    this.saveAllUsers(all);
    this.setCurrentUser(current);
  }

  // --- NOTIFICATIONS ---
  public static getNotifications(): NotificationItem[] {
    try {
      const raw = localStorage.getItem(NOTIFICATIONS_KEY);
      if (raw) return JSON.parse(raw);
    } catch {}
    return [
      {
        id: 'n_welcome',
        type: 'reward',
        title: 'Welcome to Element Clash!',
        message: 'Master Fire, Water, Earth, and rare Lightning to conquer the arena.',
        timestamp: Date.now() - 3600000,
        read: false,
      },
    ];
  }

  public static addNotification(item: NotificationItem) {
    const list = this.getNotifications();
    list.unshift(item);
    try {
      localStorage.setItem(NOTIFICATIONS_KEY, JSON.stringify(list.slice(0, 20)));
    } catch {}
  }

  public static markAllNotificationsRead() {
    const list = this.getNotifications().map((n) => ({ ...n, read: true }));
    try {
      localStorage.setItem(NOTIFICATIONS_KEY, JSON.stringify(list));
    } catch {}
  }
}
