/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { UserAccount, NotificationItem } from '../types/game';
import { getRankTier } from '../game/constants';
import {
  Swords,
  Users,
  Trophy,
  User,
  Gift,
  Bell,
  Volume2,
  VolumeX,
  LogOut,
  Sparkles,
  Flame,
  Droplets,
  Mountain,
  Zap,
  CheckCircle2,
  Home,
} from 'lucide-react';
import { sound } from '../audio/soundEngine';

interface Props {
  currentUser: UserAccount;
  currentTab: 'dashboard' | 'arena' | 'friends' | 'leaderboard' | 'profile' | 'rewards';
  onSelectTab: (tab: 'dashboard' | 'arena' | 'friends' | 'leaderboard' | 'profile' | 'rewards') => void;
  notifications: NotificationItem[];
  onOpenAuth: () => void;
  isMuted: boolean;
  onToggleMute: () => void;
  onAcceptFriendInvite?: (fromUserId: string) => void;
}

export const NavigationHeader: React.FC<Props> = ({
  currentUser,
  currentTab,
  onSelectTab,
  notifications,
  onOpenAuth,
  isMuted,
  onToggleMute,
  onAcceptFriendInvite,
}) => {
  const [showNotifications, setShowNotifications] = useState(false);
  const rank = getRankTier(currentUser.rankPoints);
  const unreadCount = notifications.filter((n) => !n.read).length;
  const pendingFriendCount = currentUser.pendingFriendRequests?.length || 0;

  const xpNeeded = currentUser.level * 150;
  const xpPct = Math.min(100, Math.floor((currentUser.xp / xpNeeded) * 100));

  const navItems: {
    id: 'dashboard' | 'arena' | 'friends' | 'leaderboard' | 'profile' | 'rewards';
    label: string;
    icon: React.ReactNode;
    badge?: number;
  }[] = [
    { id: 'dashboard', label: 'Home', icon: <Home className="h-4 w-4" /> },
    { id: 'arena', label: 'Arena', icon: <Swords className="h-4 w-4" /> },
    { id: 'friends', label: 'Friends', icon: <Users className="h-4 w-4" />, badge: pendingFriendCount },
    { id: 'leaderboard', label: 'Leaderboard', icon: <Trophy className="h-4 w-4" /> },
    { id: 'profile', label: 'Profile', icon: <User className="h-4 w-4" /> },
    { id: 'rewards', label: 'Rewards', icon: <Gift className="h-4 w-4" /> },
  ];

  return (
    <header className="relative z-30 flex h-16 w-full items-center justify-between border-b border-purple-900/40 bg-slate-950/80 px-4 md:px-8 backdrop-blur-md">
      {/* Brand / Logo */}
      <div
        onClick={() => {
          sound.playClick();
          onSelectTab('dashboard');
        }}
        className="flex items-center gap-3 cursor-pointer group"
      >
        <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-gradient-to-br from-purple-600 via-fuchsia-600 to-amber-500 shadow-lg shadow-purple-500/20 group-hover:scale-105 transition">
          <Sparkles className="h-5 w-5 text-white" />
        </div>
        <div>
          <div className="flex items-center gap-1.5">
            <span className="font-cinzel text-lg font-black tracking-wider bg-gradient-to-r from-purple-300 via-pink-400 to-amber-300 bg-clip-text text-transparent">
              ELEMENT CLASH
            </span>
            <span className="rounded bg-purple-500/20 border border-purple-500/30 px-1.5 py-0.2 text-[9px] font-bold text-purple-300 uppercase tracking-widest">
              ARENA
            </span>
          </div>
          <div className="hidden sm:flex items-center gap-2 text-[10px] text-slate-400 font-semibold tracking-wider">
            <span className="text-orange-400">FIRE</span> • <span className="text-cyan-400">WATER</span> • <span className="text-emerald-400">EARTH</span> • <span className="text-purple-400">LIGHTNING</span>
          </div>
        </div>
      </div>

      {/* Center Nav Tabs */}
      <nav className="hidden lg:flex items-center gap-1 bg-slate-900/60 p-1 rounded-2xl border border-purple-900/30">
        {navItems.map((item) => {
          const isActive = currentTab === item.id;
          return (
            <button
              key={item.id}
              onClick={() => {
                sound.playClick();
                onSelectTab(item.id);
              }}
              className={`relative flex items-center gap-2 rounded-xl px-4 py-2 text-xs font-bold transition ${
                isActive
                  ? 'bg-gradient-to-r from-purple-600 to-indigo-600 text-white shadow-md shadow-purple-600/30'
                  : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/50'
              }`}
            >
              {item.icon}
              <span>{item.label}</span>
              {item.badge !== undefined && item.badge > 0 && (
                <span className="flex h-4 w-4 items-center justify-center rounded-full bg-rose-500 text-[10px] font-bold text-white">
                  {item.badge}
                </span>
              )}
            </button>
          );
        })}
      </nav>

      {/* Right User & Utility Controls */}
      <div className="flex items-center gap-3">
        {/* Audio Mute */}
        <button
          onClick={() => {
            sound.playClick();
            onToggleMute();
          }}
          className="flex h-9 w-9 items-center justify-center rounded-xl border border-slate-800 bg-slate-900/80 text-slate-300 hover:text-white transition shadow-sm"
          title={isMuted ? 'Unmute' : 'Mute'}
        >
          {isMuted ? <VolumeX className="h-4 w-4 text-red-400" /> : <Volume2 className="h-4 w-4 text-emerald-400" />}
        </button>

        {/* Notifications Bell */}
        <div className="relative">
          <button
            onClick={() => {
              sound.playClick();
              setShowNotifications(!showNotifications);
            }}
            className="relative flex h-9 w-9 items-center justify-center rounded-xl border border-slate-800 bg-slate-900/80 text-slate-300 hover:text-white transition shadow-sm"
          >
            <Bell className="h-4 w-4" />
            {unreadCount > 0 && (
              <span className="absolute -top-1 -right-1 flex h-4 w-4 items-center justify-center rounded-full bg-purple-500 text-[10px] font-bold text-white animate-pulse">
                {unreadCount}
              </span>
            )}
          </button>

          {/* Notifications Dropdown */}
          {showNotifications && (
            <div className="absolute right-0 mt-2 w-80 rounded-2xl border border-purple-900/60 bg-slate-950/95 p-3 shadow-2xl z-50">
              <div className="flex items-center justify-between border-b border-slate-800 pb-2 mb-2">
                <span className="text-xs font-bold font-cinzel text-purple-300">Notifications</span>
                <span className="text-[10px] text-slate-400">{notifications.length} recent</span>
              </div>
              <div className="max-h-64 overflow-y-auto flex flex-col gap-2">
                {notifications.length === 0 ? (
                  <p className="text-xs text-slate-500 text-center py-4">No notifications yet.</p>
                ) : (
                  notifications.map((n) => (
                    <div
                      key={n.id}
                      className="rounded-xl border border-slate-800/80 bg-slate-900/60 p-2.5 text-xs flex flex-col gap-1"
                    >
                      <div className="flex items-center justify-between">
                        <span className="font-bold text-slate-200">{n.title}</span>
                        <span className="text-[10px] text-slate-500">
                          {new Date(n.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                        </span>
                      </div>
                      <p className="text-[11px] text-slate-400">{n.message}</p>
                      {n.type === 'battle_invite' && n.fromUserId && onAcceptFriendInvite && (
                        <button
                          onClick={() => {
                            onAcceptFriendInvite(n.fromUserId!);
                            setShowNotifications(false);
                          }}
                          className="mt-1 rounded-lg bg-gradient-to-r from-amber-500 to-orange-500 py-1 text-center font-bold text-[10px] text-slate-950 hover:opacity-90"
                        >
                          Accept Battle Challenge
                        </button>
                      )}
                    </div>
                  ))
                )}
              </div>
            </div>
          )}
        </div>

        {/* User Profile Pill */}
        <div
          onClick={() => {
            sound.playClick();
            onSelectTab('profile');
          }}
          className="flex items-center gap-2.5 rounded-2xl border border-purple-900/40 bg-slate-900/80 p-1.5 pr-3 cursor-pointer hover:border-purple-500/60 transition shadow-lg"
        >
          <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-purple-950 border border-purple-700/50 text-lg">
            {currentUser.avatar}
          </div>
          <div className="hidden sm:flex flex-col text-left">
            <div className="flex items-center gap-1.5">
              <span className="text-xs font-bold text-slate-200 leading-tight">{currentUser.username}</span>
              <span className="text-[10px] font-mono-num text-purple-400 font-bold">{currentUser.playerTag}</span>
            </div>
            <div className="flex items-center gap-2 text-[10px] text-slate-400">
              <span className="font-bold text-amber-400">Lvl {currentUser.level}</span>
              <span>•</span>
              <span style={{ color: rank.color }} className="font-bold">
                {rank.badge} {rank.name}
              </span>
            </div>
          </div>
        </div>

        {/* Auth / Account Switcher Button */}
        <button
          onClick={() => {
            sound.playClick();
            onOpenAuth();
          }}
          className="flex h-9 w-9 items-center justify-center rounded-xl border border-purple-900/40 bg-slate-900/80 text-slate-400 hover:text-white hover:border-purple-500 transition shadow-sm"
          title="Switch Account / Sign In"
        >
          <LogOut className="h-4 w-4" />
        </button>
      </div>
    </header>
  );
};
