/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { FighterState, ElementType, FloatingText, PlayerStats, GameMode } from '../types/game';
import { ELEMENTS, COMBOS } from '../game/constants';
import { Shield, Zap, Sparkles, Pause, BookOpen, Volume2, VolumeX, Eye, ArrowLeft, Flame, Droplets, Mountain } from 'lucide-react';
import { sound } from '../audio/soundEngine';

interface Props {
  player: FighterState;
  opponents: FighterState[];
  allies?: FighterState[];
  matchTime: number;
  stats: PlayerStats;
  mode: GameMode;
  floatingTexts: FloatingText[];
  onCastElement: (element: ElementType) => void;
  onCastUltimate: () => void;
  onSpawnCover: () => void;
  onDodge: () => void;
  onCastCombo: (comboId: string) => void;
  onPause: () => void;
  onOpenGuide: () => void;
  onToggleInspect: () => void;
  isInspectMode: boolean;
  isMuted: boolean;
  onToggleMute: () => void;
  onExitToDashboard: () => void;
}

export const HUD: React.FC<Props> = ({
  player,
  opponents,
  matchTime,
  stats,
  mode,
  floatingTexts,
  onCastElement,
  onCastUltimate,
  onSpawnCover,
  onDodge,
  onCastCombo,
  onPause,
  onOpenGuide,
  onToggleInspect,
  isInspectMode,
  isMuted,
  onToggleMute,
  onExitToDashboard,
}) => {
  const [showComboMenu, setShowComboMenu] = useState(false);
  const primaryOpponent = opponents[0];

  const formatTime = (secs: number) => {
    const m = Math.floor(secs / 60);
    const s = Math.floor(secs % 60);
    return `${m}:${s < 10 ? '0' : ''}${s}`;
  };

  const playerHpPct = Math.max(0, Math.min(100, (player.hp / player.maxHp) * 100));
  const oppHpPct = primaryOpponent
    ? Math.max(0, Math.min(100, (primaryOpponent.hp / primaryOpponent.maxHp) * 100))
    : 0;

  const isPlayerStunned = player.statusEffects.some((s) => s.type === 'stun');
  const isPlayerSlowed = player.statusEffects.some((s) => s.type === 'slow');
  const isPlayerBurning = player.statusEffects.some((s) => s.type === 'burn');

  const oppStunned = primaryOpponent?.statusEffects.some((s) => s.type === 'stun');
  const oppSlowed = primaryOpponent?.statusEffects.some((s) => s.type === 'slow');
  const oppBurning = primaryOpponent?.statusEffects.some((s) => s.type === 'burn');

  return (
    <div className="absolute inset-0 pointer-events-none select-none z-10 flex flex-col justify-between p-4 md:p-6">
      {/* Top Status Cluster */}
      <div className="flex items-start justify-between w-full">
        {/* Player Status Cluster (Left) */}
        <div className="flex flex-col gap-1 w-56 sm:w-68 bg-slate-950/85 p-3 rounded-2xl border border-purple-900/50 shadow-2xl pointer-events-auto backdrop-blur-none">
          <div className="flex items-center justify-between text-xs font-bold text-slate-200">
            <span className="flex items-center gap-1.5 font-cinzel text-amber-400">
              <span className="text-base">{player.avatar || '🧙‍♂️'}</span>
              <span>{player.name} (P1)</span>
            </span>
            <span className="font-mono-num text-[11px] text-slate-400">
              {Math.round(player.hp)} / {player.maxHp} HP
            </span>
          </div>

          {/* Health Bar */}
          <div className="h-3 w-full bg-slate-900 rounded-full overflow-hidden p-0.5 border border-slate-800">
            <div
              className={`h-full rounded-full transition-all duration-300 ${
                playerHpPct > 50
                  ? 'bg-gradient-to-r from-emerald-500 to-green-400'
                  : playerHpPct > 25
                  ? 'bg-gradient-to-r from-amber-500 to-yellow-400'
                  : 'bg-gradient-to-r from-red-600 to-rose-400'
              }`}
              style={{ width: `${playerHpPct}%` }}
            />
          </div>

          {/* Ultimate Energy Bar */}
          <div className="flex items-center justify-between text-[10px] text-slate-400 mt-0.5">
            <span className="flex items-center gap-1">
              <Sparkles className="h-3 w-3 text-amber-400" /> Ultimate Energy
            </span>
            <span className="font-mono-num font-bold text-amber-400">{Math.floor(player.energy)}%</span>
          </div>
          <div className="h-1.5 w-full bg-slate-900 rounded-full overflow-hidden">
            <div
              className="h-full bg-gradient-to-r from-amber-500 via-purple-500 to-pink-500 transition-all duration-200"
              style={{ width: `${player.energy}%` }}
            />
          </div>

          {/* Player Active Status Effect Badges */}
          <div className="flex flex-wrap items-center gap-1.5 mt-1">
            {isPlayerBurning && (
              <span className="flex items-center gap-1 rounded-md bg-orange-950/80 border border-orange-500/60 px-1.5 py-0.5 text-[9px] font-bold text-orange-300 animate-pulse">
                <Flame className="h-2.5 w-2.5 text-orange-400" /> BURN DoT
              </span>
            )}
            {isPlayerSlowed && (
              <span className="flex items-center gap-1 rounded-md bg-cyan-950/80 border border-cyan-500/60 px-1.5 py-0.5 text-[9px] font-bold text-cyan-300">
                <Droplets className="h-2.5 w-2.5 text-cyan-400" /> SLOW -45%
              </span>
            )}
            {isPlayerStunned && (
              <span className="flex items-center gap-1 rounded-md bg-yellow-950/90 border border-yellow-500 px-1.5 py-0.5 text-[9px] font-black text-yellow-300 animate-bounce">
                <Zap className="h-2.5 w-2.5 text-yellow-400" /> STUNNED!
              </span>
            )}
            {!isPlayerBurning && !isPlayerSlowed && !isPlayerStunned && (
              <span className="text-[10px] text-slate-500">Status: Normal</span>
            )}
          </div>
        </div>

        {/* Center Match Info & Scoreboard */}
        <div className="flex flex-col items-center gap-1 bg-slate-950/85 px-4 py-2.5 rounded-2xl border border-purple-900/50 shadow-2xl pointer-events-auto backdrop-blur-none">
          <div className="text-base font-bold font-mono-num text-slate-100">{formatTime(matchTime)}</div>
          <div className="flex items-center gap-2 text-xs font-mono-num">
            <span className="text-emerald-400 font-bold">{stats.wins}W</span>
            <span className="text-slate-600">-</span>
            <span className="text-red-400 font-bold">{stats.losses}L</span>
            <span className="text-slate-600">-</span>
            <span className="text-amber-400 font-bold">{stats.draws}D</span>
          </div>
          <div className="text-[9px] uppercase tracking-widest text-purple-300 font-bold mt-0.5">
            {mode === 'duel'
              ? '1v1 Duel'
              : mode === 'pvp_friend'
              ? 'Friend Duel'
              : mode === 'random_ranked'
              ? 'Ranked Match'
              : mode === 'team_deathmatch'
              ? '2v2 Team Clash'
              : 'Battle Royale'}
          </div>
        </div>

        {/* Opponent Status Cluster (Right) */}
        {primaryOpponent ? (
          <div className="flex flex-col gap-1 w-56 sm:w-68 bg-slate-950/85 p-3 rounded-2xl border border-purple-900/50 shadow-2xl pointer-events-auto text-right backdrop-blur-none">
            <div className="flex items-center justify-between text-xs font-bold text-slate-200">
              <span className="font-mono-num text-[11px] text-slate-400">
                {Math.round(primaryOpponent.hp)} / {primaryOpponent.maxHp} HP
              </span>
              <span className="flex items-center gap-1.5 font-cinzel text-red-400">
                <span>{primaryOpponent.name}</span>
                <span className="text-base">{primaryOpponent.avatar || '🤖'}</span>
              </span>
            </div>

            {/* Health Bar */}
            <div className="h-3 w-full bg-slate-900 rounded-full overflow-hidden p-0.5 border border-slate-800">
              <div
                className="h-full rounded-full bg-gradient-to-l from-red-600 to-rose-400 transition-all duration-300 ml-auto"
                style={{ width: `${oppHpPct}%` }}
              />
            </div>

            {/* Opponent Status Badges */}
            <div className="flex flex-wrap items-center justify-end gap-1.5 mt-1">
              {oppBurning && (
                <span className="flex items-center gap-1 rounded-md bg-orange-950/80 border border-orange-500/60 px-1.5 py-0.5 text-[9px] font-bold text-orange-300 animate-pulse">
                  <Flame className="h-2.5 w-2.5 text-orange-400" /> BURN DoT
                </span>
              )}
              {oppSlowed && (
                <span className="flex items-center gap-1 rounded-md bg-cyan-950/80 border border-cyan-500/60 px-1.5 py-0.5 text-[9px] font-bold text-cyan-300">
                  <Droplets className="h-2.5 w-2.5 text-cyan-400" /> SLOW -45%
                </span>
              )}
              {oppStunned && (
                <span className="flex items-center gap-1 rounded-md bg-yellow-950/90 border border-yellow-500 px-1.5 py-0.5 text-[9px] font-black text-yellow-300 animate-bounce">
                  <Zap className="h-2.5 w-2.5 text-yellow-400" /> STUNNED!
                </span>
              )}
              {!oppBurning && !oppSlowed && !oppStunned && (
                <span className="text-[10px] text-slate-500">Status: Normal</span>
              )}
            </div>
          </div>
        ) : (
          <div className="w-56" />
        )}
      </div>

      {/* Floating Combat Text Feed (Center playfield) */}
      <div className="relative flex-1 flex flex-col items-center justify-center pointer-events-none">
        {floatingTexts.map((ft) => (
          <div
            key={ft.id}
            className={`font-black font-cinzel tracking-wider px-4 py-1.5 rounded-full my-1 transition-all duration-300 shadow-2xl ${
              ft.isCritical
                ? 'text-yellow-300 bg-red-950/95 border-2 border-yellow-500 scale-110 animate-bounce'
                : 'text-slate-100 bg-slate-950/90 border border-purple-800/80 text-xs sm:text-sm'
            }`}
            style={{ color: ft.color }}
          >
            {ft.text}
          </div>
        ))}
      </div>

      {/* Quick Utility Bar */}
      <div className="flex items-center justify-between mb-2">
        <button
          onClick={onOpenGuide}
          className="flex items-center gap-1.5 bg-slate-950/85 px-3 py-1.5 rounded-xl border border-purple-900/50 text-xs text-purple-200 hover:border-purple-400 transition pointer-events-auto shadow-md"
        >
          <BookOpen className="h-3.5 w-3.5" />
          <span>Rules: Fire &gt; Earth &gt; Water &gt; Fire | ⚡ &gt; Water &amp; Earth</span>
        </button>

        <div className="flex items-center gap-2 pointer-events-auto">
          <button
            onClick={onToggleInspect}
            className={`flex items-center gap-1 px-3 py-1.5 rounded-xl border text-xs transition shadow-md ${
              isInspectMode
                ? 'border-cyan-400 bg-cyan-950/60 text-cyan-300'
                : 'border-purple-900/50 bg-slate-950/85 text-slate-300 hover:text-white'
            }`}
          >
            <Eye className="h-3.5 w-3.5" />
            <span className="hidden sm:inline">Orbit Cam</span>
          </button>

          <button
            onClick={onToggleMute}
            className="flex h-8 w-8 items-center justify-center rounded-xl border border-purple-900/50 bg-slate-950/85 text-slate-300 hover:text-white transition shadow-md"
          >
            {isMuted ? <VolumeX className="h-4 w-4 text-red-400" /> : <Volume2 className="h-4 w-4 text-emerald-400" />}
          </button>

          <button
            onClick={onPause}
            className="flex items-center gap-1 bg-slate-950/85 px-3 py-1.5 rounded-xl border border-purple-900/50 text-xs text-slate-300 hover:text-white transition shadow-md"
          >
            <Pause className="h-3.5 w-3.5" />
            <span className="hidden sm:inline">Pause</span>
          </button>

          <button
            onClick={onExitToDashboard}
            className="flex items-center gap-1 bg-rose-950/70 border border-rose-800/60 px-3 py-1.5 rounded-xl text-xs text-rose-300 hover:bg-rose-900/80 transition shadow-md"
            title="Leave Battle"
          >
            <ArrowLeft className="h-3.5 w-3.5" />
            <span className="hidden sm:inline">Exit</span>
          </button>
        </div>
      </div>

      {/* Bottom Action Dock (Low-Occlusion & Ergonomic) */}
      <div className="relative mx-auto w-full max-w-3xl pointer-events-auto">
        {/* Combo Fusions Drawer */}
        {showComboMenu && (
          <div className="mb-3 rounded-2xl border border-purple-800/80 bg-slate-950/95 p-3 shadow-2xl grid grid-cols-2 sm:grid-cols-4 gap-2">
            {COMBOS.map((combo) => (
              <button
                key={combo.id}
                onClick={() => {
                  onCastCombo(combo.id);
                  setShowComboMenu(false);
                }}
                disabled={isPlayerStunned}
                className="flex flex-col items-center justify-center rounded-xl border border-slate-800 bg-slate-900/80 p-2.5 text-center hover:border-amber-400 hover:bg-slate-800 transition disabled:opacity-40"
              >
                <span className="text-xs font-bold text-amber-300">{combo.name}</span>
                <span className="text-[10px] text-slate-400 mt-0.5 line-clamp-1">{combo.description}</span>
              </button>
            ))}
          </div>
        )}

        {/* Action Buttons Dock */}
        <div className="relative flex items-center justify-center gap-2 rounded-2xl border border-purple-900/60 bg-slate-950/90 p-2.5 shadow-2xl">
          {/* Stunned Lock Overlay */}
          {isPlayerStunned && (
            <div className="absolute inset-0 z-20 flex items-center justify-center rounded-2xl bg-yellow-950/85 border-2 border-yellow-400 text-yellow-300 font-cinzel font-black text-sm tracking-wider animate-pulse">
              ⚡ PARALYZED BY STUN! CANNOT CAST SPELLS
            </div>
          )}

          {/* 1: FIRE */}
          <button
            onClick={() => onCastElement('fire')}
            disabled={player.cooldowns.fire > 0 || isPlayerStunned}
            className={`group relative flex flex-col items-center justify-center rounded-xl border px-3 sm:px-4 py-2 transition min-w-[62px] sm:min-w-[76px] ${
              player.currentElement === 'fire'
                ? 'border-orange-500 bg-orange-500/20 text-orange-300 shadow-md shadow-orange-500/20'
                : 'border-slate-800 bg-slate-900/70 text-slate-300 hover:border-orange-500/60'
            } ${player.cooldowns.fire > 0 ? 'opacity-50 cursor-not-allowed' : 'cursor-pointer active:scale-95'}`}
          >
            <span className="text-xl">🔥</span>
            <span className="text-xs font-bold mt-0.5">Fire</span>
            <span className="text-[10px] text-slate-400 font-mono-num">[1]</span>
            {player.cooldowns.fire > 0 && (
              <div className="absolute inset-0 flex items-center justify-center rounded-xl bg-black/60 font-mono-num text-xs font-bold text-amber-400">
                {player.cooldowns.fire.toFixed(1)}s
              </div>
            )}
          </button>

          {/* 2: WATER */}
          <button
            onClick={() => onCastElement('water')}
            disabled={player.cooldowns.water > 0 || isPlayerStunned}
            className={`group relative flex flex-col items-center justify-center rounded-xl border px-3 sm:px-4 py-2 transition min-w-[62px] sm:min-w-[76px] ${
              player.currentElement === 'water'
                ? 'border-blue-500 bg-blue-500/20 text-blue-300 shadow-md shadow-blue-500/20'
                : 'border-slate-800 bg-slate-900/70 text-slate-300 hover:border-blue-500/60'
            } ${player.cooldowns.water > 0 ? 'opacity-50 cursor-not-allowed' : 'cursor-pointer active:scale-95'}`}
          >
            <span className="text-xl">💧</span>
            <span className="text-xs font-bold mt-0.5">Water</span>
            <span className="text-[10px] text-slate-400 font-mono-num">[2]</span>
            {player.cooldowns.water > 0 && (
              <div className="absolute inset-0 flex items-center justify-center rounded-xl bg-black/60 font-mono-num text-xs font-bold text-cyan-400">
                {player.cooldowns.water.toFixed(1)}s
              </div>
            )}
          </button>

          {/* 3: EARTH */}
          <button
            onClick={() => onCastElement('earth')}
            disabled={player.cooldowns.earth > 0 || isPlayerStunned}
            className={`group relative flex flex-col items-center justify-center rounded-xl border px-3 sm:px-4 py-2 transition min-w-[62px] sm:min-w-[76px] ${
              player.currentElement === 'earth'
                ? 'border-emerald-500 bg-emerald-500/20 text-emerald-300 shadow-md shadow-emerald-500/20'
                : 'border-slate-800 bg-slate-900/70 text-slate-300 hover:border-emerald-500/60'
            } ${player.cooldowns.earth > 0 ? 'opacity-50 cursor-not-allowed' : 'cursor-pointer active:scale-95'}`}
          >
            <span className="text-xl">🌍</span>
            <span className="text-xs font-bold mt-0.5">Earth</span>
            <span className="text-[10px] text-slate-400 font-mono-num">[3]</span>
            {player.cooldowns.earth > 0 && (
              <div className="absolute inset-0 flex items-center justify-center rounded-xl bg-black/60 font-mono-num text-xs font-bold text-emerald-400">
                {player.cooldowns.earth.toFixed(1)}s
              </div>
            )}
          </button>

          {/* 4: LIGHTNING (Rare limited-use element) */}
          <button
            onClick={() => onCastElement('lightning')}
            disabled={player.cooldowns.lightning > 0 || isPlayerStunned || player.lightningCharges <= 0}
            className={`group relative flex flex-col items-center justify-center rounded-xl border px-3 sm:px-4 py-2 transition min-w-[62px] sm:min-w-[76px] ${
              player.currentElement === 'lightning'
                ? 'border-purple-400 bg-purple-500/30 text-purple-200 shadow-md shadow-purple-500/30'
                : 'border-purple-900/80 bg-purple-950/40 text-purple-300 hover:border-purple-400'
            } ${player.cooldowns.lightning > 0 || player.lightningCharges <= 0 ? 'opacity-50 cursor-not-allowed' : 'cursor-pointer active:scale-95'}`}
          >
            <span className="text-xl">⚡</span>
            <span className="text-xs font-bold mt-0.5">Lightning</span>
            <div className="flex items-center gap-1 text-[9px] text-purple-300 font-mono-num">
              <span>[4]</span>
              <span className="font-bold text-yellow-300">({player.lightningCharges}/2)</span>
            </div>
            {player.cooldowns.lightning > 0 && (
              <div className="absolute inset-0 flex items-center justify-center rounded-xl bg-black/60 font-mono-num text-xs font-bold text-purple-300">
                {player.cooldowns.lightning.toFixed(1)}s
              </div>
            )}
          </button>

          <div className="h-9 w-px bg-slate-800 mx-1 hidden sm:block" />

          {/* Q: EARTH COVER */}
          <button
            onClick={onSpawnCover}
            disabled={player.coverCooldown > 0 || isPlayerStunned}
            className={`flex flex-col items-center justify-center rounded-xl border px-2.5 sm:px-3 py-2 transition min-w-[56px] ${
              player.coverCooldown > 0 || isPlayerStunned
                ? 'border-slate-800 bg-slate-900/40 opacity-40 cursor-not-allowed'
                : 'border-emerald-600/60 bg-emerald-950/30 text-emerald-300 hover:bg-emerald-900/40 cursor-pointer active:scale-95'
            }`}
            title="Summon Earth Wall to block incoming spells"
          >
            <Shield className="h-4 w-4" />
            <span className="text-[11px] font-bold mt-0.5">Cover</span>
            <span className="text-[9px] text-slate-400 font-mono-num">[Q]</span>
          </button>

          {/* Shift: DASH */}
          <button
            onClick={onDodge}
            disabled={player.dodgeTimer > 0 || isPlayerStunned}
            className={`flex flex-col items-center justify-center rounded-xl border px-2.5 sm:px-3 py-2 transition min-w-[56px] ${
              player.dodgeTimer > 0 || isPlayerStunned
                ? 'border-slate-800 bg-slate-900/40 opacity-40 cursor-not-allowed'
                : 'border-cyan-600/60 bg-cyan-950/30 text-cyan-300 hover:bg-cyan-900/40 cursor-pointer active:scale-95'
            }`}
            title="Dash to evade attacks"
          >
            <Zap className="h-4 w-4" />
            <span className="text-[11px] font-bold mt-0.5">Dash</span>
            <span className="text-[9px] text-slate-400 font-mono-num">[Shift]</span>
          </button>

          {/* E: COMBOS */}
          <button
            onClick={() => setShowComboMenu(!showComboMenu)}
            disabled={isPlayerStunned}
            className="flex flex-col items-center justify-center rounded-xl border border-amber-600/60 bg-amber-950/30 px-2.5 sm:px-3 py-2 text-amber-300 hover:bg-amber-900/40 transition min-w-[56px] cursor-pointer active:scale-95 disabled:opacity-40"
            title="Open Fusion Combos"
          >
            <Sparkles className="h-4 w-4" />
            <span className="text-[11px] font-bold mt-0.5">Combos</span>
            <span className="text-[9px] text-slate-400 font-mono-num">[E]</span>
          </button>

          {/* Space: ULTIMATE BURST */}
          <button
            onClick={onCastUltimate}
            disabled={player.energy < 100 || player.ultimateCooldown > 0 || isPlayerStunned}
            className={`flex flex-col items-center justify-center rounded-xl px-3 sm:px-4 py-2 font-cinzel transition font-black ${
              player.energy >= 100 && player.ultimateCooldown <= 0 && !isPlayerStunned
                ? 'bg-gradient-to-r from-amber-500 to-orange-500 text-slate-950 shadow-lg shadow-orange-500/30 hover:scale-105 active:scale-95 cursor-pointer animate-pulse'
                : 'bg-slate-800/60 text-slate-500 border border-slate-700/50 cursor-not-allowed opacity-50'
            }`}
          >
            <span className="text-sm">💥 BURST</span>
            <span className="text-[9px] font-mono-num">[Space]</span>
          </button>
        </div>
      </div>
    </div>
  );
};
