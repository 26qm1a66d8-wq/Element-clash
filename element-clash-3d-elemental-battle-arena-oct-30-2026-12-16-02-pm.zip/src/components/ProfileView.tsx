/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { UserAccount } from '../types/game';
import { AVATARS, TITLES, getRankTier, ELEMENTS } from '../game/constants';
import {
  User,
  Shield,
  Award,
  Clock,
  Sparkles,
  Trophy,
  Flame,
  Droplets,
  Mountain,
  Zap,
  Check,
  Edit3,
} from 'lucide-react';
import { sound } from '../audio/soundEngine';

interface Props {
  currentUser: UserAccount;
  onUpdateProfile: (updates: Partial<UserAccount>) => void;
}

export const ProfileView: React.FC<Props> = ({ currentUser, onUpdateProfile }) => {
  const [isEditing, setIsEditing] = useState(false);
  const [selectedAvatar, setSelectedAvatar] = useState(currentUser.avatar);
  const [selectedTitle, setSelectedTitle] = useState(currentUser.title);

  const rank = getRankTier(currentUser.rankPoints);
  const totalBattles = currentUser.wins + currentUser.losses + currentUser.draws;
  const winRate = totalBattles > 0 ? Math.round((currentUser.wins / totalBattles) * 100) : 0;

  const xpNeeded = currentUser.level * 150;
  const xpPct = Math.min(100, Math.floor((currentUser.xp / xpNeeded) * 100));

  const achievementsList = [
    { id: 'first_blood', name: 'First Blood', desc: 'Win your inaugural arena duel.', icon: '⚔️' },
    { id: 'pyromancer', name: 'Pyromancer', desc: 'Win 10 matches commanding Fire.', icon: '🔥' },
    { id: 'storm_overcharge', name: 'Storm Overcharge', desc: 'Inflict a Superconductive Stun.', icon: '⚡' },
    { id: 'tidal_wave', name: 'Tidal Sovereign', desc: 'Slow 15 opponents with Water.', icon: '🌊' },
    { id: 'earth_bastion', name: 'Granite Bastion', desc: 'Construct 10 Earth barriers in battle.', icon: '🛡️' },
    { id: 'grandmaster', name: 'Grandmaster Archon', desc: 'Reach 2400+ Ladder Points.', icon: '👑' },
  ];

  const handleSave = () => {
    sound.playClick();
    onUpdateProfile({ avatar: selectedAvatar, title: selectedTitle });
    setIsEditing(false);
  };

  return (
    <div className="relative z-10 flex flex-col gap-6 p-4 md:p-8 max-w-5xl mx-auto overflow-y-auto max-h-[calc(100vh-4rem)]">
      {/* Profile Header Card */}
      <div className="rounded-3xl border border-purple-900/50 bg-gradient-to-r from-purple-950/70 via-slate-950 to-indigo-950/70 p-6 md:p-8 shadow-2xl backdrop-blur-md">
        <div className="flex flex-col sm:flex-row items-center sm:items-start justify-between gap-6">
          <div className="flex flex-col sm:flex-row items-center gap-5 text-center sm:text-left">
            <div className="relative">
              <div className="flex h-24 w-24 items-center justify-center rounded-3xl bg-purple-950/90 text-5xl border-2 border-purple-500/50 shadow-2xl shadow-purple-500/30">
                {currentUser.avatar}
              </div>
              <button
                onClick={() => setIsEditing(!isEditing)}
                className="absolute -bottom-2 -right-2 flex h-8 w-8 items-center justify-center rounded-full bg-purple-600 text-white shadow-lg hover:bg-purple-500 transition"
                title="Edit Avatar & Title"
              >
                <Edit3 className="h-4 w-4" />
              </button>
            </div>

            <div>
              <div className="flex items-center justify-center sm:justify-start gap-2">
                <h1 className="font-cinzel text-2xl sm:text-3xl font-black text-white">{currentUser.username}</h1>
                <span className="rounded-lg bg-purple-500/20 border border-purple-500/40 px-2 py-0.5 text-xs font-mono-num font-bold text-purple-300">
                  {currentUser.playerTag}
                </span>
              </div>
              <div className="text-sm font-semibold text-amber-400 mt-0.5">{currentUser.title}</div>
              <p className="text-xs text-slate-400 mt-1 font-mono-num">{currentUser.email}</p>
            </div>
          </div>

          {/* Current Rank Badge */}
          <div className="flex flex-col items-center sm:items-end">
            <div className="flex items-center gap-2 rounded-2xl border border-purple-800/50 bg-slate-900/80 px-4 py-2.5 shadow-xl">
              <span className="text-2xl">{rank.badge}</span>
              <div className="text-right">
                <div style={{ color: rank.color }} className="text-xs font-bold uppercase tracking-wider">
                  {rank.name}
                </div>
                <div className="text-sm font-bold font-mono-num text-white">{currentUser.rankPoints} LP</div>
              </div>
            </div>
          </div>
        </div>

        {/* Level XP Bar */}
        <div className="mt-6 rounded-2xl border border-slate-800 bg-slate-900/60 p-4">
          <div className="flex items-center justify-between text-xs text-slate-400 mb-1.5 font-mono-num">
            <span className="font-bold text-white">Level {currentUser.level} Elementalist</span>
            <span>
              {currentUser.xp} / {xpNeeded} XP ({xpPct}%)
            </span>
          </div>
          <div className="h-2.5 w-full overflow-hidden rounded-full bg-slate-800">
            <div
              className="h-full bg-gradient-to-r from-purple-500 via-pink-500 to-amber-400 transition-all duration-500"
              style={{ width: `${xpPct}%` }}
            />
          </div>
        </div>
      </div>

      {/* Avatar & Title Customizer Modal / Drawer */}
      {isEditing && (
        <div className="rounded-3xl border border-purple-700/60 bg-slate-950/95 p-6 shadow-2xl">
          <div className="flex items-center justify-between border-b border-slate-800 pb-3 mb-4">
            <h3 className="font-cinzel text-lg font-bold text-purple-300">Customize Identity</h3>
            <button onClick={() => setIsEditing(false)} className="text-slate-400 hover:text-white">
              ✕
            </button>
          </div>

          {/* Avatar selector */}
          <div className="mb-5">
            <span className="text-xs font-bold uppercase tracking-wider text-slate-300 block mb-2">
              Choose Avatar:
            </span>
            <div className="grid grid-cols-4 sm:grid-cols-8 gap-2.5">
              {AVATARS.map((av) => (
                <button
                  key={av.id}
                  onClick={() => setSelectedAvatar(av.icon)}
                  className={`flex flex-col items-center justify-center rounded-2xl p-2.5 text-2xl transition border ${
                    selectedAvatar === av.icon
                      ? 'border-purple-400 bg-purple-900/40 scale-105 shadow-lg shadow-purple-500/20'
                      : 'border-slate-800 bg-slate-900/60 hover:border-slate-700'
                  }`}
                >
                  <span>{av.icon}</span>
                </button>
              ))}
            </div>
          </div>

          {/* Title selector */}
          <div className="mb-6">
            <span className="text-xs font-bold uppercase tracking-wider text-slate-300 block mb-2">
              Choose Title:
            </span>
            <div className="flex flex-wrap gap-2">
              {TITLES.map((t) => (
                <button
                  key={t}
                  onClick={() => setSelectedTitle(t)}
                  className={`rounded-xl px-3 py-1.5 text-xs font-semibold transition border ${
                    selectedTitle === t
                      ? 'border-amber-400 bg-amber-500/20 text-amber-300'
                      : 'border-slate-800 bg-slate-900/60 text-slate-400 hover:text-white'
                  }`}
                >
                  {t}
                </button>
              ))}
            </div>
          </div>

          <div className="flex justify-end gap-2">
            <button
              onClick={() => setIsEditing(false)}
              className="rounded-xl border border-slate-700 px-4 py-2 text-xs font-bold text-slate-300"
            >
              Cancel
            </button>
            <button
              onClick={handleSave}
              className="rounded-xl bg-purple-600 px-5 py-2 text-xs font-bold text-white hover:bg-purple-500 shadow-md shadow-purple-600/30"
            >
              Save Changes
            </button>
          </div>
        </div>
      )}

      {/* Career Stats Grid */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        <div className="rounded-2xl border border-purple-900/40 bg-slate-950/80 p-4 shadow-xl text-center">
          <div className="text-[10px] uppercase font-bold text-slate-400 tracking-wider">Total Battles</div>
          <div className="text-2xl font-black font-mono-num text-white mt-1">{totalBattles}</div>
          <div className="text-[10px] text-slate-500 mt-0.5">
            {currentUser.wins}W - {currentUser.losses}L - {currentUser.draws}D
          </div>
        </div>

        <div className="rounded-2xl border border-purple-900/40 bg-slate-950/80 p-4 shadow-xl text-center">
          <div className="text-[10px] uppercase font-bold text-slate-400 tracking-wider">Win Percentage</div>
          <div className="text-2xl font-black font-mono-num text-emerald-400 mt-1">{winRate}%</div>
          <div className="text-[10px] text-slate-500 mt-0.5">Victories / Total</div>
        </div>

        <div className="rounded-2xl border border-purple-900/40 bg-slate-950/80 p-4 shadow-xl text-center">
          <div className="text-[10px] uppercase font-bold text-slate-400 tracking-wider">Current Streak</div>
          <div className="text-2xl font-black font-mono-num text-amber-400 mt-1">🔥 {currentUser.streak}</div>
          <div className="text-[10px] text-slate-500 mt-0.5">Best: {currentUser.bestStreak}</div>
        </div>

        <div className="rounded-2xl border border-purple-900/40 bg-slate-950/80 p-4 shadow-xl text-center">
          <div className="text-[10px] uppercase font-bold text-slate-400 tracking-wider">Status Inflicted</div>
          <div className="text-2xl font-black font-mono-num text-cyan-400 mt-1">
            {currentUser.statusEffectsInflicted || 0}
          </div>
          <div className="text-[10px] text-slate-500 mt-0.5">Burns, Slows &amp; Stuns</div>
        </div>
      </div>

      {/* Achievements Badges Showcase */}
      <div className="rounded-3xl border border-purple-900/40 bg-slate-950/80 p-6 shadow-xl">
        <div className="flex items-center gap-2 mb-4">
          <Award className="h-5 w-5 text-amber-400" />
          <h2 className="font-cinzel text-base font-bold text-white">Achievements &amp; Badges</h2>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3">
          {achievementsList.map((ach) => {
            const isUnlocked = currentUser.achievements.includes(ach.id);
            return (
              <div
                key={ach.id}
                className={`rounded-2xl border p-3.5 flex items-start gap-3 transition ${
                  isUnlocked
                    ? 'border-purple-600/50 bg-purple-950/30 shadow-lg shadow-purple-600/10'
                    : 'border-slate-800/60 bg-slate-900/20 opacity-40'
                }`}
              >
                <span className="text-2xl">{ach.icon}</span>
                <div>
                  <div className="flex items-center gap-1.5">
                    <span className="text-xs font-bold text-white">{ach.name}</span>
                    {isUnlocked && <Check className="h-3.5 w-3.5 text-emerald-400" />}
                  </div>
                  <p className="text-[11px] text-slate-400 mt-0.5">{ach.desc}</p>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Complete Recent Battle History */}
      <div className="rounded-3xl border border-purple-900/40 bg-slate-950/80 p-6 shadow-xl">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-2">
            <Clock className="h-5 w-5 text-cyan-400" />
            <h2 className="font-cinzel text-base font-bold text-white">Complete Battle History</h2>
          </div>
          <span className="text-xs text-slate-400 font-mono-num">{currentUser.battleHistory.length} matches logged</span>
        </div>

        <div className="flex flex-col gap-2.5">
          {currentUser.battleHistory.length === 0 ? (
            <p className="text-xs text-slate-500 text-center py-8">No battles recorded yet.</p>
          ) : (
            currentUser.battleHistory.map((rec) => {
              const isWin = rec.result === 'victory';
              const isLoss = rec.result === 'defeat';
              return (
                <div
                  key={rec.id}
                  className="rounded-2xl border border-slate-800 bg-slate-900/60 p-3.5 flex items-center justify-between text-xs"
                >
                  <div className="flex items-center gap-3">
                    <div
                      className={`flex h-9 w-9 items-center justify-center rounded-xl font-bold font-cinzel text-sm ${
                        isWin
                          ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30'
                          : isLoss
                          ? 'bg-rose-500/20 text-rose-400 border border-rose-500/30'
                          : 'bg-amber-500/20 text-amber-400 border border-amber-500/30'
                      }`}
                    >
                      {isWin ? 'W' : isLoss ? 'L' : 'D'}
                    </div>
                    <div>
                      <div className="font-bold text-slate-100">vs {rec.opponentName}</div>
                      <div className="text-[10px] text-slate-400 mt-0.5">
                        {ELEMENTS[rec.playerElement].icon} {rec.playerElement} vs {ELEMENTS[rec.opponentElement].icon} {rec.opponentElement} • {new Date(rec.timestamp).toLocaleDateString()}
                      </div>
                    </div>
                  </div>

                  <div className="text-right font-mono-num">
                    <div className={`font-bold ${rec.lpChange >= 0 ? 'text-amber-400' : 'text-rose-400'}`}>
                      {rec.lpChange >= 0 ? `+${rec.lpChange}` : rec.lpChange} LP
                    </div>
                    <div className="text-[10px] text-cyan-400">+{rec.xpEarned} XP</div>
                  </div>
                </div>
              );
            })
          )}
        </div>
      </div>
    </div>
  );
};
