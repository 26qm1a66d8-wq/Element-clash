/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { GameMode, AIDifficulty, PlayerStats } from '../types/game';
import { getRankTier } from '../game/constants';
import { Volume2, VolumeX, Swords, Shield, Trophy, BookOpen, Flame, Droplets, Mountain, Zap } from 'lucide-react';
import { sound } from '../audio/soundEngine';

interface Props {
  onStartGame: (mode: GameMode, difficulty: AIDifficulty) => void;
  onOpenLoadout: () => void;
  onOpenGuide: () => void;
  stats: PlayerStats;
  isMuted: boolean;
  onToggleMute: () => void;
}

export const TitleScreen: React.FC<Props> = ({
  onStartGame,
  onOpenLoadout,
  onOpenGuide,
  stats,
  isMuted,
  onToggleMute,
}) => {
  const [selectedMode, setSelectedMode] = React.useState<GameMode>('duel');
  const [selectedDifficulty, setSelectedDifficulty] = React.useState<AIDifficulty>('adept');
  const rank = getRankTier(stats.rankPoints);

  React.useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Enter' || e.key === ' ') {
        e.preventDefault();
        sound.playClick();
        onStartGame(selectedMode, selectedDifficulty);
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [selectedMode, selectedDifficulty, onStartGame]);

  const modes: { id: GameMode; title: string; subtitle: string; icon: string }[] = [
    { id: 'duel', title: '1v1 Duel', subtitle: 'Skill test vs Computer AI', icon: '⚔️' },
    { id: 'team_deathmatch', title: '2v2 Team Clash', subtitle: 'Coordinate combo synergies', icon: '🛡️' },
    { id: 'battle_royale', title: 'Battle Royale', subtitle: '4-Player Elemental Free-for-All', icon: '🌪️' },
    { id: 'practice', title: 'Training Grounds', subtitle: 'Practice combos & elemental counters', icon: '🎯' },
  ];

  const difficulties: { id: AIDifficulty; label: string; desc: string; color: string }[] = [
    { id: 'apprentice', label: 'Apprentice', desc: 'Predictable casts, slow dodge', color: 'text-emerald-400' },
    { id: 'adept', label: 'Adept', desc: 'Tactical counters & combo usage', color: 'text-amber-400' },
    { id: 'grandmaster', label: 'Grandmaster', desc: 'Instant counters, cover builds & rapid fusions', color: 'text-purple-400' },
  ];

  return (
    <div className="relative z-20 flex h-full w-full flex-col justify-between p-6 md:p-10 pointer-events-auto">
      {/* Top Header Bar */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="flex h-11 w-11 items-center justify-center rounded-xl bg-slate-900/90 border border-slate-800 text-xl shadow-lg">
            {rank.badge}
          </div>
          <div>
            <div className="text-xs uppercase tracking-wider text-slate-400 font-semibold">Ranked League</div>
            <div className="flex items-center gap-2 font-mono-num text-sm">
              <span className="font-bold" style={{ color: rank.color }}>
                {rank.name}
              </span>
              <span className="text-slate-500">•</span>
              <span className="text-slate-300">{stats.rankPoints} LP</span>
            </div>
          </div>
        </div>

        {/* Action Pills */}
        <div className="flex items-center gap-3">
          {/* Win/Loss/Draw pill */}
          <div className="hidden sm:flex items-center gap-3 rounded-xl border border-slate-800 bg-slate-900/80 px-4 py-2 text-xs font-mono-num shadow-lg">
            <span className="text-emerald-400 font-bold">{stats.wins}W</span>
            <span className="text-slate-600">/</span>
            <span className="text-red-400 font-bold">{stats.losses}L</span>
            <span className="text-slate-600">/</span>
            <span className="text-amber-400 font-bold">{stats.draws}D</span>
            {stats.streak > 1 && (
              <span className="rounded bg-amber-500/20 px-1.5 py-0.5 text-[10px] text-amber-300 font-bold">
                🔥 {stats.streak} Streak
              </span>
            )}
          </div>

          <button
            onClick={() => {
              sound.playClick();
              onOpenGuide();
            }}
            className="flex items-center gap-2 rounded-xl border border-slate-700 bg-slate-900/80 px-3.5 py-2 text-xs font-medium text-slate-200 hover:border-amber-400 hover:text-amber-300 transition shadow-lg"
          >
            <BookOpen className="h-4 w-4" />
            <span>Counter Guide</span>
          </button>

          <button
            onClick={() => {
              sound.playClick();
              onOpenLoadout();
            }}
            className="flex items-center gap-2 rounded-xl border border-slate-700 bg-slate-900/80 px-3.5 py-2 text-xs font-medium text-slate-200 hover:border-amber-400 hover:text-amber-300 transition shadow-lg"
          >
            <Shield className="h-4 w-4" />
            <span>Loadouts & Perks</span>
          </button>

          <button
            onClick={() => {
              sound.playClick();
              onToggleMute();
            }}
            className="flex h-9 w-9 items-center justify-center rounded-xl border border-slate-700 bg-slate-900/80 text-slate-300 hover:text-white transition shadow-lg"
            title={isMuted ? 'Unmute Audio' : 'Mute Audio'}
          >
            {isMuted ? <VolumeX className="h-4 w-4 text-red-400" /> : <Volume2 className="h-4 w-4 text-emerald-400" />}
          </button>
        </div>
      </div>

      {/* Center Hero Lockup */}
      <div className="flex flex-col items-center justify-center my-auto text-center max-w-3xl mx-auto py-6">
        {/* Inline SVG Title Lockup */}
        <div className="relative mb-3">
          <svg className="w-80 sm:w-96 md:w-[480px] h-20 md:h-24 drop-shadow-[0_10px_20px_rgba(245,158,11,0.25)]" viewBox="0 0 500 100" fill="none" xmlns="http://www.w3.org/2000/svg">
            <defs>
              <linearGradient id="elementalGrad" x1="0%" y1="0%" x2="100%" y2="0%">
                <stop offset="0%" stopColor="#f97316" />
                <stop offset="35%" stopColor="#38bdf8" />
                <stop offset="70%" stopColor="#10b981" />
                <stop offset="100%" stopColor="#c084fc" />
              </linearGradient>
            </defs>
            <text
              x="250"
              y="72"
              textAnchor="middle"
              className="font-cinzel"
              fontSize="68"
              fontWeight="900"
              fill="url(#elementalGrad)"
              letterSpacing="6"
            >
              ELEMENT CLASH
            </text>
          </svg>
          <div className="flex items-center justify-center gap-3 text-sm tracking-widest text-slate-400 uppercase font-semibold">
            <span className="flex items-center gap-1 text-orange-400"><Flame className="h-3.5 w-3.5" /> Fire</span>
            <span>•</span>
            <span className="flex items-center gap-1 text-cyan-400"><Droplets className="h-3.5 w-3.5" /> Water</span>
            <span>•</span>
            <span className="flex items-center gap-1 text-emerald-400"><Mountain className="h-3.5 w-3.5" /> Earth</span>
            <span>•</span>
            <span className="flex items-center gap-1 text-purple-400"><Zap className="h-3.5 w-3.5" /> Lightning</span>
          </div>
        </div>

        {/* Mode Selector Cards */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-2.5 w-full max-w-2xl my-6">
          {modes.map((m) => {
            const isSelected = selectedMode === m.id;
            return (
              <button
                key={m.id}
                onClick={() => {
                  sound.playClick();
                  setSelectedMode(m.id);
                }}
                className={`flex flex-col items-center justify-center rounded-xl border p-3 transition text-center ${
                  isSelected
                    ? 'border-amber-400 bg-amber-500/15 shadow-lg shadow-amber-500/20'
                    : 'border-slate-800 bg-slate-900/70 hover:border-slate-700 hover:bg-slate-900'
                }`}
              >
                <span className="text-2xl mb-1">{m.icon}</span>
                <span className="text-xs font-bold text-slate-200">{m.title}</span>
                <span className="text-[10px] text-slate-400 mt-0.5 line-clamp-1">{m.subtitle}</span>
              </button>
            );
          })}
        </div>

        {/* AI Difficulty Selector */}
        <div className="flex items-center gap-2 mb-6">
          <span className="text-xs uppercase tracking-wider text-slate-400 font-semibold mr-1">Opponent AI:</span>
          {difficulties.map((d) => {
            const isSelected = selectedDifficulty === d.id;
            return (
              <button
                key={d.id}
                onClick={() => {
                  sound.playClick();
                  setSelectedDifficulty(d.id);
                }}
                className={`rounded-lg px-3 py-1.5 text-xs font-semibold transition border ${
                  isSelected
                    ? 'border-amber-400 bg-amber-500/20 text-amber-300'
                    : 'border-slate-800 bg-slate-900/60 text-slate-400 hover:text-slate-200'
                }`}
              >
                {d.label}
              </button>
            );
          })}
        </div>

        {/* Primary Start CTA Button */}
        <button
          onClick={() => {
            sound.playClick();
            onStartGame(selectedMode, selectedDifficulty);
          }}
          className="group relative inline-flex items-center justify-center rounded-2xl bg-gradient-to-r from-amber-500 via-orange-500 to-amber-600 px-10 py-4 text-lg font-black font-cinzel text-slate-950 shadow-2xl shadow-orange-500/30 transition hover:scale-105 active:scale-95 cursor-pointer"
        >
          <Swords className="mr-3 h-5 w-5 transition group-hover:rotate-12" />
          ENTER THE ARENA
        </button>
      </div>

      {/* Bottom Flat Control Hint Line */}
      <div className="flex items-center justify-center text-center">
        <p className="text-xs text-slate-400 font-mono-num bg-slate-900/80 px-4 py-2 rounded-full border border-slate-800 shadow-md">
          <strong className="text-slate-200">WASD</strong> Move · <strong className="text-slate-200">1-4</strong> Cast Element · <strong className="text-slate-200">Q</strong> Earth Wall · <strong className="text-slate-200">Shift</strong> Dash · <strong className="text-slate-200">Space</strong> Elemental Burst · <strong className="text-slate-200">Esc</strong> Pause
        </p>
      </div>
    </div>
  );
};
