/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { Play, RotateCcw, Home, BookOpen, Volume2, VolumeX } from 'lucide-react';
import { sound } from '../audio/soundEngine';

interface Props {
  isOpen: boolean;
  onResume: () => void;
  onRestart: () => void;
  onReturnMenu: () => void;
  onOpenGuide: () => void;
  isMuted: boolean;
  onToggleMute: () => void;
}

export const PauseModal: React.FC<Props> = ({
  isOpen,
  onResume,
  onRestart,
  onReturnMenu,
  onOpenGuide,
  isMuted,
  onToggleMute,
}) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 p-4 backdrop-blur-sm">
      <div className="relative w-full max-w-sm rounded-2xl border border-slate-700 bg-slate-900/95 p-6 shadow-2xl text-center text-slate-100">
        <h2 className="text-2xl font-bold font-cinzel text-amber-400 mb-1">Game Paused</h2>
        <p className="text-xs text-slate-400 mb-6">Take a breath, elemental master</p>

        <div className="flex flex-col gap-2.5">
          <button
            onClick={() => {
              sound.playClick();
              onResume();
            }}
            className="flex items-center justify-center gap-2 rounded-xl bg-gradient-to-r from-amber-500 to-orange-500 px-4 py-3 text-xs font-bold text-slate-950 shadow-lg shadow-orange-500/20 hover:scale-102 active:scale-98 transition"
          >
            <Play className="h-4 w-4 fill-slate-950" />
            <span>Resume Battle (Esc)</span>
          </button>

          <button
            onClick={() => {
              sound.playClick();
              onOpenGuide();
            }}
            className="flex items-center justify-center gap-2 rounded-xl border border-slate-700 bg-slate-800/80 px-4 py-2.5 text-xs font-semibold text-slate-300 hover:bg-slate-700 hover:text-white transition"
          >
            <BookOpen className="h-4 w-4" />
            <span>Elemental Counter Guide</span>
          </button>

          <button
            onClick={() => {
              sound.playClick();
              onToggleMute();
            }}
            className="flex items-center justify-center gap-2 rounded-xl border border-slate-700 bg-slate-800/80 px-4 py-2.5 text-xs font-semibold text-slate-300 hover:bg-slate-700 hover:text-white transition"
          >
            {isMuted ? <VolumeX className="h-4 w-4 text-red-400" /> : <Volume2 className="h-4 w-4 text-emerald-400" />}
            <span>{isMuted ? 'Unmute Sound' : 'Mute Sound'}</span>
          </button>

          <button
            onClick={() => {
              sound.playClick();
              onRestart();
            }}
            className="flex items-center justify-center gap-2 rounded-xl border border-slate-700 bg-slate-800/80 px-4 py-2.5 text-xs font-semibold text-slate-300 hover:bg-slate-700 hover:text-white transition"
          >
            <RotateCcw className="h-4 w-4" />
            <span>Restart Match</span>
          </button>

          <button
            onClick={() => {
              sound.playClick();
              onReturnMenu();
            }}
            className="flex items-center justify-center gap-2 rounded-xl border border-slate-800 bg-slate-950 px-4 py-2.5 text-xs font-semibold text-slate-400 hover:text-slate-200 transition"
          >
            <Home className="h-4 w-4" />
            <span>Leave to Main Menu</span>
          </button>
        </div>
      </div>
    </div>
  );
};
