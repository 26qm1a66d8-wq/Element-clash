/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { UserAccount } from '../types/game';
import { StorageService } from '../services/storageService';
import { AVATARS } from '../game/constants';
import { LogIn, UserPlus, Users, Lock, Mail, User, ShieldCheck, AlertCircle } from 'lucide-react';
import { sound } from '../audio/soundEngine';

interface Props {
  isOpen: boolean;
  onClose: () => void;
  currentUser: UserAccount;
  allUsers: UserAccount[];
  onAccountSwitched: (user: UserAccount) => void;
}

export const AuthModal: React.FC<Props> = ({
  isOpen,
  onClose,
  currentUser,
  allUsers,
  onAccountSwitched,
}) => {
  if (!isOpen) return null;

  const [mode, setMode] = useState<'login' | 'signup' | 'switch'>('login');
  const [username, setUsername] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [selectedAvatar, setSelectedAvatar] = useState('🧙‍♂️');
  const [error, setError] = useState('');

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    sound.playClick();
    const res = StorageService.login(email || username, password);
    if (!res.success) {
      setError(res.error || 'Failed to login');
      return;
    }
    if (res.user) {
      onAccountSwitched(res.user);
      onClose();
    }
  };

  const handleSignup = (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    sound.playClick();
    if (!username.trim() || !email.trim() || !password) {
      setError('Please fill in all required fields.');
      return;
    }
    const res = StorageService.register(username, email, password, selectedAvatar);
    if (!res.success) {
      setError(res.error || 'Failed to register account');
      return;
    }
    if (res.user) {
      onAccountSwitched(res.user);
      onClose();
    }
  };

  const handleQuickSwitch = (user: UserAccount) => {
    sound.playClick();
    StorageService.setCurrentUser(user);
    onAccountSwitched(user);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/85 p-4 backdrop-blur-sm">
      <div className="relative w-full max-w-md rounded-3xl border border-purple-800/60 bg-slate-950/95 p-6 md:p-8 shadow-2xl text-slate-100 max-h-[90vh] overflow-y-auto">
        {/* Header */}
        <div className="flex items-center justify-between border-b border-slate-800 pb-3 mb-5">
          <div className="flex items-center gap-2">
            <ShieldCheck className="h-5 w-5 text-purple-400" />
            <h2 className="font-cinzel text-lg font-bold text-white">Gladiator Authentication</h2>
          </div>
          <button onClick={onClose} className="text-slate-400 hover:text-white">
            ✕
          </button>
        </div>

        {/* Tab switchers */}
        <div className="grid grid-cols-3 gap-1 bg-slate-900/80 p-1 rounded-2xl border border-purple-900/40 mb-6 text-xs font-bold">
          <button
            onClick={() => {
              setMode('login');
              setError('');
            }}
            className={`rounded-xl py-2 transition ${
              mode === 'login' ? 'bg-purple-600 text-white shadow-md' : 'text-slate-400 hover:text-white'
            }`}
          >
            Sign In
          </button>
          <button
            onClick={() => {
              setMode('signup');
              setError('');
            }}
            className={`rounded-xl py-2 transition ${
              mode === 'signup' ? 'bg-purple-600 text-white shadow-md' : 'text-slate-400 hover:text-white'
            }`}
          >
            Register
          </button>
          <button
            onClick={() => {
              setMode('switch');
              setError('');
            }}
            className={`rounded-xl py-2 transition ${
              mode === 'switch' ? 'bg-purple-600 text-white shadow-md' : 'text-slate-400 hover:text-white'
            }`}
          >
            Accounts ({allUsers.length})
          </button>
        </div>

        {error && (
          <div className="mb-4 rounded-xl border border-rose-500/50 bg-rose-950/40 p-3 text-xs text-rose-300 flex items-center gap-2">
            <AlertCircle className="h-4 w-4 shrink-0" />
            <span>{error}</span>
          </div>
        )}

        {/* Mode 1: Login */}
        {mode === 'login' && (
          <form onSubmit={handleLogin} className="flex flex-col gap-3">
            <div>
              <label className="text-[11px] font-bold text-slate-300 uppercase tracking-wider block mb-1">
                Username or Email
              </label>
              <div className="relative">
                <User className="absolute left-3 top-3 h-4 w-4 text-purple-400" />
                <input
                  type="text"
                  required
                  placeholder="e.g. player@elementclash.gg or AetherMage"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="w-full rounded-xl border border-slate-800 bg-slate-900 py-2.5 pl-10 pr-3 text-xs text-white placeholder-slate-500 focus:border-purple-400 focus:outline-none"
                />
              </div>
            </div>

            <div>
              <label className="text-[11px] font-bold text-slate-300 uppercase tracking-wider block mb-1">
                Password
              </label>
              <div className="relative">
                <Lock className="absolute left-3 top-3 h-4 w-4 text-purple-400" />
                <input
                  type="password"
                  required
                  placeholder="••••••••"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="w-full rounded-xl border border-slate-800 bg-slate-900 py-2.5 pl-10 pr-3 text-xs text-white placeholder-slate-500 focus:border-purple-400 focus:outline-none"
                />
              </div>
            </div>

            <button
              type="submit"
              className="mt-3 w-full rounded-xl bg-gradient-to-r from-purple-600 to-indigo-600 py-3 text-xs font-bold text-white shadow-lg shadow-purple-600/30 hover:opacity-95"
            >
              Sign In to Element Clash
            </button>
          </form>
        )}

        {/* Mode 2: Register */}
        {mode === 'signup' && (
          <form onSubmit={handleSignup} className="flex flex-col gap-3">
            <div>
              <label className="text-[11px] font-bold text-slate-300 uppercase tracking-wider block mb-1">
                Gladiator Username
              </label>
              <div className="relative">
                <User className="absolute left-3 top-3 h-4 w-4 text-purple-400" />
                <input
                  type="text"
                  required
                  placeholder="Choose your battle name"
                  value={username}
                  onChange={(e) => setUsername(e.target.value)}
                  className="w-full rounded-xl border border-slate-800 bg-slate-900 py-2.5 pl-10 pr-3 text-xs text-white placeholder-slate-500 focus:border-purple-400 focus:outline-none"
                />
              </div>
            </div>

            <div>
              <label className="text-[11px] font-bold text-slate-300 uppercase tracking-wider block mb-1">
                Email Address
              </label>
              <div className="relative">
                <Mail className="absolute left-3 top-3 h-4 w-4 text-purple-400" />
                <input
                  type="email"
                  required
                  placeholder="gladiator@arena.gg"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="w-full rounded-xl border border-slate-800 bg-slate-900 py-2.5 pl-10 pr-3 text-xs text-white placeholder-slate-500 focus:border-purple-400 focus:outline-none"
                />
              </div>
            </div>

            <div>
              <label className="text-[11px] font-bold text-slate-300 uppercase tracking-wider block mb-1">
                Secure Password
              </label>
              <div className="relative">
                <Lock className="absolute left-3 top-3 h-4 w-4 text-purple-400" />
                <input
                  type="password"
                  required
                  placeholder="Min 6 characters"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="w-full rounded-xl border border-slate-800 bg-slate-900 py-2.5 pl-10 pr-3 text-xs text-white placeholder-slate-500 focus:border-purple-400 focus:outline-none"
                />
              </div>
            </div>

            <div>
              <label className="text-[11px] font-bold text-slate-300 uppercase tracking-wider block mb-1">
                Choose Starter Avatar
              </label>
              <div className="grid grid-cols-4 gap-2">
                {AVATARS.slice(0, 4).map((av) => (
                  <button
                    key={av.id}
                    type="button"
                    onClick={() => setSelectedAvatar(av.icon)}
                    className={`rounded-xl border p-2 text-xl transition ${
                      selectedAvatar === av.icon
                        ? 'border-purple-400 bg-purple-900/50 shadow-md'
                        : 'border-slate-800 bg-slate-900/60'
                    }`}
                  >
                    {av.icon}
                  </button>
                ))}
              </div>
            </div>

            <button
              type="submit"
              className="mt-3 w-full rounded-xl bg-gradient-to-r from-amber-500 to-orange-500 py-3 text-xs font-black font-cinzel text-slate-950 shadow-lg shadow-orange-500/20 hover:scale-102 transition"
            >
              CREATE GLADIATOR ACCOUNT
            </button>
          </form>
        )}

        {/* Mode 3: Quick Switch Registered Account */}
        {mode === 'switch' && (
          <div className="flex flex-col gap-2 max-h-72 overflow-y-auto">
            <p className="text-[11px] text-slate-400 mb-2">
              Select any registered or seeded gladiator account to instantly simulate multiple player perspectives:
            </p>
            {allUsers.map((u) => {
              const isCurrent = u.id === currentUser.id;
              return (
                <div
                  key={u.id}
                  onClick={() => handleQuickSwitch(u)}
                  className={`rounded-2xl border p-3 flex items-center justify-between cursor-pointer transition ${
                    isCurrent
                      ? 'border-purple-400 bg-purple-950/40 shadow-md'
                      : 'border-slate-800 bg-slate-900/60 hover:border-slate-700 hover:bg-slate-900'
                  }`}
                >
                  <div className="flex items-center gap-3">
                    <span className="text-2xl">{u.avatar}</span>
                    <div>
                      <div className="flex items-center gap-1.5 font-bold text-xs text-white">
                        <span>{u.username}</span>
                        {isCurrent && <span className="text-[10px] text-amber-400">(Active)</span>}
                      </div>
                      <div className="text-[10px] text-slate-400 font-mono-num">{u.playerTag} • {u.rankPoints} LP</div>
                    </div>
                  </div>
                  <span className="text-xs text-purple-400 font-bold">Switch</span>
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
};
