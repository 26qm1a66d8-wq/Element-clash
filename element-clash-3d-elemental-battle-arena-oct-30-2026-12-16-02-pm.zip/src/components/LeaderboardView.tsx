/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { UserAccount } from '../types/game';
import { getRankTier } from '../game/constants';
import { Trophy, Medal, Search, Crown, Flame, Sparkles, TrendingUp, User } from 'lucide-react';
import { sound } from '../audio/soundEngine';

interface Props {
  currentUser: UserAccount;
  allUsers: UserAccount[];
}

export const LeaderboardView: React.FC<Props> = ({ currentUser, allUsers }) => {
  const [boardType, setBoardType] = useState<'global' | 'weekly' | 'friends'>('global');
  const [searchQuery, setSearchQuery] = useState('');

  // Sort by LP descending, then by wins
  let list = [...allUsers].sort((a, b) => b.rankPoints - a.rankPoints || b.wins - a.wins);

  if (boardType === 'friends') {
    list = list.filter((u) => u.id === currentUser.id || currentUser.friends.includes(u.id));
  } else if (boardType === 'weekly') {
    // simulated weekly activity weighting
    list = [...list].sort(
      (a, b) => b.wins * 35 + b.streak * 10 - (a.wins * 35 + a.streak * 10)
    );
  }

  // Filter by search query if any
  const filteredList = searchQuery.trim()
    ? list.filter(
        (u) =>
          u.username.toLowerCase().includes(searchQuery.toLowerCase()) ||
          u.playerTag.toLowerCase().includes(searchQuery.toLowerCase())
      )
    : list;

  const top1 = list[0];
  const top2 = list[1];
  const top3 = list[2];

  const currentUserRankIndex = list.findIndex((u) => u.id === currentUser.id) + 1;

  return (
    <div className="relative z-10 flex flex-col gap-6 p-4 md:p-8 max-w-5xl mx-auto overflow-y-auto max-h-[calc(100vh-4rem)]">
      {/* Header */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 border-b border-purple-900/40 pb-5">
        <div>
          <h1 className="font-cinzel text-2xl md:text-3xl font-black text-white flex items-center gap-2">
            <Trophy className="h-6 w-6 text-amber-400" /> Grand Elemental Leaderboard
          </h1>
          <p className="text-xs text-slate-400 mt-1">
            Official rankings across the global competitive arena. Battle to earn LP and ascend the ranks!
          </p>
        </div>

        {/* Tab switchers */}
        <div className="flex items-center gap-1 bg-slate-900/80 p-1 rounded-2xl border border-purple-900/40">
          <button
            onClick={() => {
              sound.playClick();
              setBoardType('global');
            }}
            className={`rounded-xl px-4 py-2 text-xs font-bold transition ${
              boardType === 'global' ? 'bg-amber-500 text-slate-950 shadow-md font-black' : 'text-slate-400 hover:text-white'
            }`}
          >
            Global
          </button>
          <button
            onClick={() => {
              sound.playClick();
              setBoardType('weekly');
            }}
            className={`rounded-xl px-4 py-2 text-xs font-bold transition ${
              boardType === 'weekly' ? 'bg-amber-500 text-slate-950 shadow-md font-black' : 'text-slate-400 hover:text-white'
            }`}
          >
            Weekly
          </button>
          <button
            onClick={() => {
              sound.playClick();
              setBoardType('friends');
            }}
            className={`rounded-xl px-4 py-2 text-xs font-bold transition ${
              boardType === 'friends' ? 'bg-amber-500 text-slate-950 shadow-md font-black' : 'text-slate-400 hover:text-white'
            }`}
          >
            Friends
          </button>
        </div>
      </div>

      {/* 3D-Styled Podium for Top 3 Gladiators */}
      {list.length >= 3 && !searchQuery.trim() && (
        <div className="my-2 rounded-3xl border border-purple-900/40 bg-gradient-to-b from-purple-950/40 via-slate-950/80 to-slate-950/90 p-6 pt-10 shadow-2xl">
          <div className="flex items-end justify-center gap-3 sm:gap-6 max-w-2xl mx-auto">
            {/* 2nd Place: Silver Podium */}
            {top2 && (
              <div className="flex flex-col items-center flex-1">
                <div className="relative mb-2 flex flex-col items-center">
                  <div className="flex h-14 w-14 sm:h-16 sm:w-16 items-center justify-center rounded-2xl bg-slate-900 border-2 border-slate-300 text-3xl shadow-xl shadow-slate-400/20">
                    {top2.avatar}
                  </div>
                  <span className="absolute -top-3.5 -right-2 flex h-6 w-6 items-center justify-center rounded-full bg-slate-300 text-slate-950 font-black text-xs shadow-md">
                    2
                  </span>
                </div>
                <div className="font-bold text-slate-200 text-xs sm:text-sm text-center truncate max-w-[120px]">
                  {top2.username}
                </div>
                <div className="text-[10px] text-slate-400 font-mono-num font-bold">{top2.rankPoints} LP</div>

                {/* Silver Pedestal */}
                <div className="mt-2 w-full h-24 sm:h-28 rounded-t-2xl border-t-2 border-x-2 border-slate-400/60 bg-gradient-to-b from-slate-400/30 to-slate-900/60 flex items-center justify-center">
                  <span className="font-cinzel text-xl sm:text-2xl font-black text-slate-300">#2</span>
                </div>
              </div>
            )}

            {/* 1st Place: Gold Podium (Elevated) */}
            {top1 && (
              <div className="flex flex-col items-center flex-1">
                <Crown className="h-6 w-6 text-yellow-400 mb-1 animate-bounce" />
                <div className="relative mb-2 flex flex-col items-center">
                  <div className="flex h-18 w-18 sm:h-20 sm:w-20 items-center justify-center rounded-3xl bg-slate-900 border-2 border-yellow-400 text-4xl shadow-2xl shadow-yellow-500/30">
                    {top1.avatar}
                  </div>
                  <span className="absolute -top-3 -right-2 flex h-7 w-7 items-center justify-center rounded-full bg-gradient-to-r from-amber-400 to-yellow-500 text-slate-950 font-black text-xs shadow-lg">
                    1
                  </span>
                </div>
                <div className="font-bold text-amber-300 text-sm sm:text-base text-center truncate max-w-[140px]">
                  {top1.username}
                </div>
                <div className="text-xs text-yellow-400 font-mono-num font-bold">{top1.rankPoints} LP</div>

                {/* Gold Pedestal */}
                <div className="mt-2 w-full h-32 sm:h-36 rounded-t-2xl border-t-2 border-x-2 border-yellow-500/80 bg-gradient-to-b from-amber-500/30 to-slate-900/80 flex items-center justify-center">
                  <span className="font-cinzel text-2xl sm:text-3xl font-black text-yellow-400 drop-shadow-[0_2px_8px_rgba(245,158,11,0.5)]">
                    #1
                  </span>
                </div>
              </div>
            )}

            {/* 3rd Place: Bronze Podium */}
            {top3 && (
              <div className="flex flex-col items-center flex-1">
                <div className="relative mb-2 flex flex-col items-center">
                  <div className="flex h-14 w-14 sm:h-16 sm:w-16 items-center justify-center rounded-2xl bg-slate-900 border-2 border-amber-700 text-3xl shadow-xl shadow-amber-800/20">
                    {top3.avatar}
                  </div>
                  <span className="absolute -top-3.5 -right-2 flex h-6 w-6 items-center justify-center rounded-full bg-amber-700 text-amber-100 font-black text-xs shadow-md">
                    3
                  </span>
                </div>
                <div className="font-bold text-slate-200 text-xs sm:text-sm text-center truncate max-w-[120px]">
                  {top3.username}
                </div>
                <div className="text-[10px] text-amber-500 font-mono-num font-bold">{top3.rankPoints} LP</div>

                {/* Bronze Pedestal */}
                <div className="mt-2 w-full h-18 sm:h-22 rounded-t-2xl border-t-2 border-x-2 border-amber-700/60 bg-gradient-to-b from-amber-700/30 to-slate-900/60 flex items-center justify-center">
                  <span className="font-cinzel text-xl sm:text-2xl font-black text-amber-600">#3</span>
                </div>
              </div>
            )}
          </div>
        </div>
      )}

      {/* Currently Logged-in Player Position Highlight */}
      <div className="rounded-2xl border-2 border-amber-500/50 bg-gradient-to-r from-amber-950/40 via-purple-950/50 to-slate-950 p-4 shadow-xl flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-amber-500 text-slate-950 font-black font-cinzel text-base shadow-md">
            #{currentUserRankIndex || '-'}
          </div>
          <div className="flex items-center gap-2.5">
            <div className="text-2xl">{currentUser.avatar}</div>
            <div>
              <div className="flex items-center gap-2">
                <span className="font-bold text-white text-sm">{currentUser.username} (You)</span>
                <span className="text-[10px] font-mono-num text-purple-400 font-bold">{currentUser.playerTag}</span>
              </div>
              <div className="text-[11px] text-slate-400">{currentUser.title}</div>
            </div>
          </div>
        </div>

        <div className="flex items-center gap-4 text-right">
          <div>
            <div className="text-xs font-bold text-amber-400 font-mono-num">{currentUser.rankPoints} LP</div>
            <div className="text-[10px] text-slate-400">{currentUser.wins} Wins</div>
          </div>
        </div>
      </div>

      {/* Search Bar */}
      <div className="relative">
        <Search className="absolute left-4 top-3.5 h-4 w-4 text-purple-400" />
        <input
          type="text"
          placeholder="Filter gladiator leaderboard by name or tag..."
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          className="w-full rounded-2xl border border-purple-900/50 bg-slate-900/80 py-3 pl-11 pr-4 text-xs text-white placeholder-slate-500 focus:border-purple-400 focus:outline-none shadow-lg"
        />
      </div>

      {/* Leaderboard Table */}
      <div className="rounded-2xl border border-purple-900/40 bg-slate-950/80 overflow-hidden shadow-xl">
        <div className="grid grid-cols-12 gap-2 bg-slate-900/80 px-4 py-3 text-[11px] uppercase tracking-wider font-bold text-slate-400 border-b border-purple-900/40">
          <div className="col-span-1 text-center">Rank</div>
          <div className="col-span-5 sm:col-span-4">Gladiator</div>
          <div className="col-span-3 sm:col-span-3">Tier</div>
          <div className="hidden sm:block sm:col-span-2 text-right">Record</div>
          <div className="col-span-3 sm:col-span-2 text-right">LP</div>
        </div>

        <div className="divide-y divide-slate-800/60">
          {filteredList.map((player, idx) => {
            const rank = getRankTier(player.rankPoints);
            const isSelf = player.id === currentUser.id;
            const battles = player.wins + player.losses + player.draws;
            const winRate = battles > 0 ? Math.round((player.wins / battles) * 100) : 0;

            return (
              <div
                key={player.id}
                className={`grid grid-cols-12 gap-2 px-4 py-3 text-xs items-center transition ${
                  isSelf ? 'bg-purple-900/25 border-l-4 border-amber-400' : 'hover:bg-slate-900/40'
                }`}
              >
                {/* Rank column */}
                <div className="col-span-1 text-center font-bold font-cinzel">
                  {idx === 0 ? (
                    <span className="text-yellow-400 font-black">🥇 1</span>
                  ) : idx === 1 ? (
                    <span className="text-slate-300 font-black">🥈 2</span>
                  ) : idx === 2 ? (
                    <span className="text-amber-600 font-black">🥉 3</span>
                  ) : (
                    <span className="text-slate-500 font-mono-num">{idx + 1}</span>
                  )}
                </div>

                {/* Gladiator Avatar & Username */}
                <div className="col-span-5 sm:col-span-4 flex items-center gap-2.5 truncate">
                  <span className="text-xl">{player.avatar}</span>
                  <div className="truncate">
                    <div className="font-bold text-slate-200 truncate flex items-center gap-1.5">
                      <span>{player.username}</span>
                      {isSelf && <span className="text-[10px] text-amber-400 font-mono-num">(You)</span>}
                    </div>
                    <div className="text-[10px] text-slate-400 font-mono-num">{player.playerTag}</div>
                  </div>
                </div>

                {/* Tier Badge */}
                <div className="col-span-3 sm:col-span-3 flex items-center gap-1.5 truncate">
                  <span>{rank.badge}</span>
                  <span style={{ color: rank.color }} className="font-bold truncate text-[11px]">
                    {rank.name}
                  </span>
                </div>

                {/* Record */}
                <div className="hidden sm:block sm:col-span-2 text-right font-mono-num text-[11px] text-slate-300">
                  <span className="text-emerald-400 font-bold">{player.wins}W</span> /{' '}
                  <span className="text-rose-400">{player.losses}L</span> ({winRate}%)
                </div>

                {/* LP Rating */}
                <div className="col-span-3 sm:col-span-2 text-right font-mono-num font-bold text-amber-400">
                  {player.rankPoints} LP
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};
