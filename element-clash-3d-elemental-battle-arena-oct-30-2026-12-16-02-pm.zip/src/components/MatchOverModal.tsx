/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { PlayerStats } from '../types/game';
import { getRankTier } from '../game/constants';
import confetti from 'canvas-confetti';
import { Trophy, Swords, RotateCcw, Home, Award } from 'lucide-react';
import { sound } from '../audio/soundEngine';

interface Props {
  result: 'victory' | 'defeat' | 'draw';
  stats: PlayerStats;
  damageDealt: number;
  clashesWon: number;
  lpChange: number;
  xpEarned: number;
  onRematch: () => void;
  onReturnMenu: () => void;
}

export const MatchOverModal: React.FC<Props> = ({
  result,
  stats,
  damageDealt,
  clashesWon,
  lpChange,
  xpEarned,
  onRematch,
  onReturnMenu,
}) => {
  const rank = getRankTier(stats.rankPoints);

  React.useEffect(() => {
    if (result === 'victory') {
      try {
        confetti({
          particleCount: 80,
          spread: 70,
          origin: { y: 0.6 },
          colors: ['#f97316', '#38bdf8', '#10b981', '#c084fc', '#facc15'],
        });
      } catch {}
    }
  }, [result]);

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/85 p-4 backdrop-blur-sm">
      <div className="relative w-full max-w-md rounded-2xl border border-slate-700 bg-slate-900/95 p-6 shadow-2xl text-center text-slate-100">
        {/* Result Header */}
        <div className="mb-4">
          <div className="text-4xl mb-2">
            {result === 'victory' ? '🏆' : result === 'defeat' ? '💀' : '⚖️'}
          </div>
          <h2
            className={`text-3xl font-black font-cinzel tracking-wider ${
              result === 'victory'
                ? 'text-amber-400 drop-shadow-[0_4px_12px_rgba(245,158,11,0.4)]'
                : result === 'defeat'
                ? 'text-rose-500'
                : 'text-slate-300'
            }`}
          >
            {result === 'victory' ? 'VICTORY!' : result === 'defeat' ? 'DEFEAT' : 'STALEMATE'}
          </h2>
          <p className="text-xs text-slate-400 mt-1">
            {result === 'victory'
              ? 'You commanded the elements and crushed your rival!'
              : result === 'defeat'
              ? 'Your defenses fell to the opponent’s counter spells.'
              : 'Both gladiators fought with equal elemental prowess.'}
          </p>
        </div>

        {/* Stats Grid */}
        <div className="my-5 rounded-xl border border-slate-800 bg-slate-950/70 p-4">
          <div className="grid grid-cols-2 gap-3 text-left text-xs">
            <div className="p-2 rounded-lg bg-slate-900/80 border border-slate-800">
              <span className="text-[11px] text-slate-400">Total Damage</span>
              <div className="text-base font-bold font-mono-num text-slate-100">{Math.round(damageDealt)}</div>
            </div>

            <div className="p-2 rounded-lg bg-slate-900/80 border border-slate-800">
              <span className="text-[11px] text-slate-400">Counters Won</span>
              <div className="text-base font-bold font-mono-num text-emerald-400">{clashesWon}</div>
            </div>

            <div className="p-2 rounded-lg bg-slate-900/80 border border-slate-800">
              <span className="text-[11px] text-slate-400">Rank LP</span>
              <div className="text-base font-bold font-mono-num">
                <span className={lpChange >= 0 ? 'text-amber-400' : 'text-rose-400'}>
                  {lpChange >= 0 ? `+${lpChange}` : lpChange} LP
                </span>
              </div>
            </div>

            <div className="p-2 rounded-lg bg-slate-900/80 border border-slate-800">
              <span className="text-[11px] text-slate-400">Experience</span>
              <div className="text-base font-bold font-mono-num text-cyan-400">+{xpEarned} XP</div>
            </div>
          </div>

          {/* Current Rank Tier */}
          <div className="mt-3 flex items-center justify-between border-t border-slate-800/80 pt-3 text-xs">
            <div className="flex items-center gap-2">
              <span className="text-lg">{rank.badge}</span>
              <span className="font-bold" style={{ color: rank.color }}>
                {rank.name}
              </span>
            </div>
            <span className="font-mono-num text-slate-400">{stats.rankPoints} LP Total</span>
          </div>
        </div>

        {/* Action Buttons */}
        <div className="flex items-center justify-center gap-3 mt-6">
          <button
            onClick={() => {
              sound.playClick();
              onReturnMenu();
            }}
            className="flex-1 flex items-center justify-center gap-2 rounded-xl border border-slate-700 bg-slate-800/80 px-4 py-3 text-xs font-bold text-slate-300 hover:bg-slate-700 hover:text-white transition"
          >
            <Home className="h-4 w-4" />
            <span>Main Menu</span>
          </button>

          <button
            onClick={() => {
              sound.playClick();
              onRematch();
            }}
            className="flex-1 flex items-center justify-center gap-2 rounded-xl bg-gradient-to-r from-amber-500 to-orange-500 px-4 py-3 text-xs font-black font-cinzel text-slate-950 shadow-lg shadow-orange-500/20 hover:scale-105 active:scale-95 transition"
          >
            <RotateCcw className="h-4 w-4" />
            <span>Rematch</span>
          </button>
        </div>
      </div>
    </div>
  );
};
