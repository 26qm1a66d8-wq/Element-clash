/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { ELEMENTS, COMBOS } from '../game/constants';
import { ElementType } from '../types/game';

interface Props {
  isOpen: boolean;
  onClose: () => void;
}

export const CounterGuideModal: React.FC<Props> = ({ isOpen, onClose }) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 p-4 backdrop-blur-sm">
      <div className="relative w-full max-w-2xl rounded-2xl border border-slate-700 bg-slate-900/95 p-6 shadow-2xl text-slate-100 max-h-[90vh] overflow-y-auto">
        {/* Header */}
        <div className="flex items-center justify-between border-b border-slate-800 pb-4">
          <div>
            <h2 className="text-2xl font-bold font-cinzel text-amber-400">Elemental Counter Matrix</h2>
            <p className="text-xs text-slate-400">Master the rock-paper-scissors relationships and the rare 4th element rules</p>
          </div>
          <button
            onClick={onClose}
            className="flex h-9 w-9 items-center justify-center rounded-lg bg-slate-800 text-slate-400 hover:bg-slate-700 hover:text-white transition"
          >
            ✕
          </button>
        </div>

        {/* Visual RPS Triangle + 4th Element */}
        <div className="my-6 rounded-xl border border-slate-800 bg-slate-950/70 p-5">
          <h3 className="text-sm font-semibold uppercase tracking-wider text-slate-400 mb-3">Core Triangle</h3>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-3 text-center text-xs">
            <div className="rounded-lg border border-red-500/30 bg-red-950/30 p-3">
              <span className="text-3xl block mb-1">🔥</span>
              <span className="font-bold text-red-400 text-sm">FIRE</span>
              <p className="text-slate-300 mt-1">Crushes & melts <strong className="text-emerald-400">EARTH</strong> (+75% dmg)</p>
              <p className="text-slate-400 text-[11px] mt-1">Extinguished by <span className="text-blue-400">Water</span></p>
            </div>

            <div className="rounded-lg border border-emerald-500/30 bg-emerald-950/30 p-3">
              <span className="text-3xl block mb-1">🌿</span>
              <span className="font-bold text-emerald-400 text-sm">EARTH</span>
              <p className="text-slate-300 mt-1">Absorbs & buries <strong className="text-blue-400">WATER</strong> (+75% dmg)</p>
              <p className="text-slate-400 text-[11px] mt-1">Burned by <span className="text-red-400">Fire</span></p>
            </div>

            <div className="rounded-lg border border-blue-500/30 bg-blue-950/30 p-3">
              <span className="text-3xl block mb-1">💧</span>
              <span className="font-bold text-blue-400 text-sm">WATER</span>
              <p className="text-slate-300 mt-1">Douses & drench <strong className="text-red-400">FIRE</strong> (+75% dmg)</p>
              <p className="text-slate-400 text-[11px] mt-1">Absorbed by <span className="text-emerald-400">Earth</span></p>
            </div>
          </div>

          {/* Rare 4th Element Card */}
          <div className="mt-4 rounded-xl border border-purple-500/50 bg-gradient-to-r from-purple-950/40 to-indigo-950/40 p-4">
            <div className="flex items-center gap-2 mb-2">
              <span className="text-2xl">⚡</span>
              <span className="font-bold text-purple-300 text-sm font-cinzel">BONUS ELEMENT: LIGHTNING</span>
              <span className="rounded-full bg-purple-500/20 px-2 py-0.5 text-[10px] text-purple-300 border border-purple-500/40 font-bold uppercase">
                Special Rule
              </span>
            </div>
            <ul className="text-xs text-slate-300 space-y-1.5 list-disc list-inside">
              <li>
                <strong className="text-cyan-300">Conducts violently through Water:</strong> Deals <strong className="text-yellow-400">200% Critical Damage</strong> against Water champions!
              </li>
              <li>
                <strong className="text-emerald-400">Grounded by Earth:</strong> Earth completely absorbs and discharges Lightning with <strong className="text-red-400">0 damage</strong>!
              </li>
              <li>
                <strong className="text-amber-300">Clashes with Fire:</strong> Triggers neutral explosive plasma discharge.
              </li>
            </ul>
          </div>
        </div>

        {/* Combo Fusions */}
        <div className="my-6">
          <h3 className="text-sm font-semibold uppercase tracking-wider text-slate-400 mb-3">Elemental Fusion Combos (Press E)</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3 text-xs">
            {COMBOS.map((combo) => (
              <div key={combo.id} className="rounded-xl border border-slate-800 bg-slate-950/60 p-3 flex flex-col justify-between">
                <div className="flex items-center justify-between mb-1">
                  <span className="font-bold text-amber-300">{combo.name}</span>
                  <span className="text-[10px] px-2 py-0.5 rounded bg-slate-800 text-slate-300">
                    {ELEMENTS[combo.elementA].icon} + {ELEMENTS[combo.elementB].icon}
                  </span>
                </div>
                <p className="text-slate-400 text-[11px] mb-2">{combo.description}</p>
                <div className="text-[11px] font-semibold text-emerald-400 bg-emerald-950/30 px-2 py-1 rounded border border-emerald-800/40">
                  {combo.effect}
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Ultimate Burst Abilities */}
        <div>
          <h3 className="text-sm font-semibold uppercase tracking-wider text-slate-400 mb-3">Ultimate Elemental Bursts (Spacebar)</h3>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs">
            {(Object.keys(ELEMENTS) as ElementType[]).map((k) => {
              const el = ELEMENTS[k];
              return (
                <div key={k} className="p-2.5 rounded-lg border border-slate-800 bg-slate-950/40 flex items-start gap-2.5">
                  <span className="text-xl">{el.icon}</span>
                  <div>
                    <div className="font-bold text-slate-200">{el.ultimateName}</div>
                    <div className="text-[11px] text-slate-400 mt-0.5">{el.ultimateDesc}</div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Footer */}
        <div className="mt-6 pt-4 border-t border-slate-800 flex justify-end">
          <button
            onClick={onClose}
            className="rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold px-6 py-2.5 text-sm transition shadow-lg shadow-amber-500/20"
          >
            Understood, Let's Clash!
          </button>
        </div>
      </div>
    </div>
  );
};
