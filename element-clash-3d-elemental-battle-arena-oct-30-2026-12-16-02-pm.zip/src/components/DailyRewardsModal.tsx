/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { UserAccount } from '../types/game';
import confetti from 'canvas-confetti';
import { Gift, Award, CheckCircle2, Sparkles, Calendar } from 'lucide-react';
import { sound } from '../audio/soundEngine';

interface Props {
  currentUser: UserAccount;
  isOpen: boolean;
  onClose: () => void;
  onClaimDailyReward: () => void;
}

export const DailyRewardsModal: React.FC<Props> = ({
  currentUser,
  isOpen,
  onClose,
  onClaimDailyReward,
}) => {
  if (!isOpen) return null;

  const rewards = [
    { day: 1, title: '+50 XP', desc: 'Arcane Sparks', icon: '✨' },
    { day: 2, title: '+100 XP & 15 LP', desc: 'Rank Boost', icon: '💎' },
    { day: 3, title: '+150 XP', desc: 'Elemental Fuel', icon: '🔥' },
    { day: 4, title: 'Tidal Ward Perk', desc: 'Rare Defense', icon: '💧' },
    { day: 5, title: '+200 XP & 30 LP', desc: 'Gladiator Surge', icon: '🏆' },
    { day: 6, title: 'Granite Skin', desc: 'Earth Armor', icon: '🛡️' },
    { day: 7, title: 'Raijin Stormlord', desc: 'Exclusive Champion Skin', icon: '👑' },
  ];

  const handleClaim = () => {
    sound.playVictory();
    try {
      confetti({
        particleCount: 70,
        spread: 60,
        origin: { y: 0.6 },
        colors: ['#a855f7', '#38bdf8', '#facc15', '#f97316'],
      });
    } catch {}
    onClaimDailyReward();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/85 p-4 backdrop-blur-sm">
      <div className="relative w-full max-w-2xl rounded-3xl border border-purple-800/60 bg-slate-950/95 p-6 md:p-8 shadow-2xl text-slate-100 max-h-[90vh] overflow-y-auto">
        <div className="flex items-center justify-between border-b border-slate-800 pb-4 mb-6">
          <div className="flex items-center gap-3">
            <div className="flex h-12 w-12 items-center justify-center rounded-2xl bg-gradient-to-br from-purple-600 to-amber-500 text-2xl shadow-lg">
              🎁
            </div>
            <div>
              <h2 className="font-cinzel text-xl md:text-2xl font-bold text-white">Daily Login Sanctions</h2>
              <p className="text-xs text-slate-400">Claim your rewards each consecutive day to unlock exclusive rewards</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="flex h-9 w-9 items-center justify-center rounded-xl bg-slate-800 text-slate-400 hover:text-white"
          >
            ✕
          </button>
        </div>

        {/* 7 Days Grid */}
        <div className="grid grid-cols-2 sm:grid-cols-4 md:grid-cols-7 gap-2.5 mb-8">
          {rewards.map((r) => {
            const isPast = r.day < currentUser.dailyRewardDay;
            const isToday = r.day === currentUser.dailyRewardDay;
            const isClaimedToday = isToday && currentUser.dailyRewardClaimed;

            return (
              <div
                key={r.day}
                className={`rounded-2xl border p-3 flex flex-col items-center justify-between text-center transition ${
                  isToday
                    ? 'border-amber-400 bg-amber-950/40 shadow-xl shadow-amber-500/20 scale-105'
                    : isPast || isClaimedToday
                    ? 'border-emerald-600/50 bg-emerald-950/30 opacity-70'
                    : 'border-slate-800 bg-slate-900/50 opacity-50'
                }`}
              >
                <div className="text-[10px] uppercase font-bold text-slate-400 mb-1">Day {r.day}</div>
                <div className="text-3xl my-2">{r.icon}</div>
                <div className="text-xs font-bold text-white leading-tight">{r.title}</div>
                <div className="text-[10px] text-slate-400 mt-0.5 line-clamp-1">{r.desc}</div>

                <div className="mt-2 w-full pt-1">
                  {isClaimedToday || isPast ? (
                    <span className="flex items-center justify-center gap-1 text-[10px] font-bold text-emerald-400">
                      <CheckCircle2 className="h-3 w-3" /> Claimed
                    </span>
                  ) : isToday ? (
                    <span className="rounded bg-amber-500/30 text-amber-300 text-[10px] font-bold px-1.5 py-0.5 block">
                      READY
                    </span>
                  ) : (
                    <span className="text-[10px] text-slate-600">Locked</span>
                  )}
                </div>
              </div>
            );
          })}
        </div>

        {/* CTA Button */}
        <div className="flex flex-col sm:flex-row items-center justify-between gap-4 border-t border-slate-800 pt-5">
          <div className="text-xs text-slate-400">
            Current Streak: <strong className="text-amber-400">{currentUser.dailyRewardDay} Days</strong>
          </div>

          <div className="flex items-center gap-3">
            <button
              onClick={onClose}
              className="rounded-xl border border-slate-800 bg-slate-900 px-5 py-2.5 text-xs font-bold text-slate-300 hover:text-white"
            >
              Close
            </button>
            <button
              onClick={handleClaim}
              disabled={currentUser.dailyRewardClaimed}
              className={`rounded-xl px-6 py-2.5 text-xs font-black font-cinzel transition shadow-xl ${
                currentUser.dailyRewardClaimed
                  ? 'bg-slate-800 text-slate-500 cursor-not-allowed border border-slate-700/50'
                  : 'bg-gradient-to-r from-amber-500 to-orange-500 text-slate-950 hover:scale-105 active:scale-95 shadow-orange-500/30'
              }`}
            >
              {currentUser.dailyRewardClaimed ? 'Claimed for Today' : 'CLAIM TODAY’S REWARD!'}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
