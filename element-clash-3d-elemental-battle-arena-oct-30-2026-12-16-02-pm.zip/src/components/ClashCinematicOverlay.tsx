/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useEffect, useState } from 'react';
import { ElementType, StatusEffectType } from '../types/game';
import { ELEMENTS } from '../game/constants';
import { sound } from '../audio/soundEngine';

interface Props {
  isActive: boolean;
  playerAvatar: string;
  playerName: string;
  playerElement: ElementType;
  opponentAvatar: string;
  opponentName: string;
  opponentElement: ElementType;
  result: 'player' | 'opponent' | 'draw';
  message: string;
  statusEffect?: StatusEffectType;
  onComplete: () => void;
}

export const ClashCinematicOverlay: React.FC<Props> = ({
  isActive,
  playerAvatar,
  playerName,
  playerElement,
  opponentAvatar,
  opponentName,
  opponentElement,
  result,
  message,
  statusEffect,
  onComplete,
}) => {
  const [phase, setPhase] = useState<'charging' | 'flying' | 'impact' | 'reveal'>('charging');

  useEffect(() => {
    if (!isActive) {
      setPhase('charging');
      return;
    }

    setPhase('charging');
    sound.playCast(playerElement);

    const t1 = setTimeout(() => {
      setPhase('flying');
    }, 400);

    const t2 = setTimeout(() => {
      setPhase('impact');
      sound.playHit(playerElement, true);
    }, 1100);

    const t3 = setTimeout(() => {
      setPhase('reveal');
      if (result === 'player') sound.playCounterWin();
      else if (result === 'opponent') sound.playNullified();
    }, 1600);

    const t4 = setTimeout(() => {
      onComplete();
    }, 3200);

    return () => {
      clearTimeout(t1);
      clearTimeout(t2);
      clearTimeout(t3);
      clearTimeout(t4);
    };
  }, [isActive, playerElement, result, onComplete]);

  if (!isActive) return null;

  const pInfo = ELEMENTS[playerElement];
  const oInfo = ELEMENTS[opponentElement];

  return (
    <div className="fixed inset-0 z-40 flex items-center justify-center bg-black/80 backdrop-blur-md select-none overflow-hidden">
      {/* Dynamic Clash Arena */}
      <div className="relative w-full max-w-4xl h-96 flex items-center justify-between px-8">
        {/* Left Side: Player */}
        <div
          className={`flex flex-col items-center transition-all duration-500 ${
            phase === 'reveal' && result === 'opponent' ? 'opacity-40 scale-95' : 'scale-105'
          }`}
        >
          <div className="relative mb-3">
            <div className="flex h-20 w-20 sm:h-24 sm:w-24 items-center justify-center rounded-3xl bg-purple-950/80 text-4xl sm:text-5xl border-2 border-purple-500 shadow-2xl">
              {playerAvatar}
            </div>
            <span className="absolute -bottom-2 left-1/2 -translate-x-1/2 rounded-full bg-slate-900 border border-purple-500 px-2 py-0.5 text-[10px] font-bold text-amber-400 uppercase tracking-wider">
              {playerName}
            </span>
          </div>
          <span className="text-xs font-bold text-slate-300 font-cinzel mt-1">{pInfo.name}</span>
        </div>

        {/* Flying Player Element (moves towards center) */}
        <div
          className={`absolute text-5xl sm:text-6xl transition-all duration-700 ease-in-out ${
            phase === 'charging'
              ? 'left-28 sm:left-36 scale-75'
              : phase === 'flying'
              ? 'left-[46%] -translate-x-1/2 scale-125'
              : 'left-1/2 -translate-x-1/2 scale-150'
          }`}
          style={{ filter: `drop-shadow(0 0 25px ${pInfo.glowColor})` }}
        >
          {pInfo.icon}
        </div>

        {/* Center Impact Shockwave */}
        {phase === 'impact' && (
          <div className="absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 flex items-center justify-center pointer-events-none">
            <div className="h-44 w-44 rounded-full border-4 border-amber-400 bg-white/20 animate-ping" />
            <div className="h-28 w-28 rounded-full bg-gradient-to-r from-orange-500 via-amber-400 to-purple-500 blur-lg animate-pulse" />
          </div>
        )}

        {/* Flying Opponent Element (moves towards center) */}
        <div
          className={`absolute text-5xl sm:text-6xl transition-all duration-700 ease-in-out ${
            phase === 'charging'
              ? 'right-28 sm:right-36 scale-75'
              : phase === 'flying'
              ? 'right-[46%] translate-x-1/2 scale-125'
              : 'left-1/2 -translate-x-1/2 scale-150'
          }`}
          style={{ filter: `drop-shadow(0 0 25px ${oInfo.glowColor})` }}
        >
          {oInfo.icon}
        </div>

        {/* Right Side: Opponent */}
        <div
          className={`flex flex-col items-center transition-all duration-500 ${
            phase === 'reveal' && result === 'player' ? 'opacity-40 scale-95' : 'scale-105'
          }`}
        >
          <div className="relative mb-3">
            <div className="flex h-20 w-20 sm:h-24 sm:w-24 items-center justify-center rounded-3xl bg-purple-950/80 text-4xl sm:text-5xl border-2 border-red-500 shadow-2xl">
              {opponentAvatar}
            </div>
            <span className="absolute -bottom-2 left-1/2 -translate-x-1/2 rounded-full bg-slate-900 border border-red-500 px-2 py-0.5 text-[10px] font-bold text-red-400 uppercase tracking-wider">
              {opponentName}
            </span>
          </div>
          <span className="text-xs font-bold text-slate-300 font-cinzel mt-1">{oInfo.name}</span>
        </div>
      </div>

      {/* Reveal Banner at Bottom of Clash */}
      {phase === 'reveal' && (
        <div className="absolute bottom-16 sm:bottom-20 max-w-xl text-center px-6 animate-fade-in">
          <div
            className={`font-cinzel text-2xl sm:text-3xl font-black mb-1.5 ${
              result === 'player'
                ? 'text-amber-400 drop-shadow-[0_4px_16px_rgba(245,158,11,0.6)]'
                : result === 'opponent'
                ? 'text-rose-400'
                : 'text-slate-300'
            }`}
          >
            {result === 'player' ? 'ELEMENTAL VICTORY!' : result === 'opponent' ? 'COUNTER DEFEAT!' : 'EQUAL CLASH!'}
          </div>
          <p className="text-xs sm:text-sm text-slate-200 font-semibold">{message}</p>

          {statusEffect && (
            <div className="inline-flex items-center gap-1.5 mt-2 rounded-full bg-purple-900/60 border border-purple-400/60 px-3 py-1 text-xs font-bold text-purple-200 animate-pulse">
              <span>Status Applied:</span>
              <span className="text-amber-300 uppercase">
                {statusEffect === 'burn' ? '🔥 BURN (DoT)' : statusEffect === 'slow' ? '💧 SLOW (-45%)' : '⚡ STUNNED (Paralyzed)'}
              </span>
            </div>
          )}
        </div>
      )}
    </div>
  );
};
