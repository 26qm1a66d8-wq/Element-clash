/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { UserAccount, ElementType, GameMode, AIDifficulty } from '../types/game';
import { ELEMENTS, getRankTier } from '../game/constants';
import {
  Swords,
  Users,
  Trophy,
  User,
  Gift,
  Flame,
  Droplets,
  Mountain,
  Zap,
  Play,
  Sparkles,
  ArrowRight,
  TrendingUp,
  Award,
  Shield,
  Clock,
  CheckCircle2,
} from 'lucide-react';
import { sound } from '../audio/soundEngine';

interface Props {
  currentUser: UserAccount;
  onStartBattle: (mode: GameMode, difficulty: AIDifficulty) => void;
  onNavigateTab: (tab: 'dashboard' | 'arena' | 'friends' | 'leaderboard' | 'profile' | 'rewards') => void;
  onSelectHeroElement: (element: ElementType) => void;
  activeHeroElement: ElementType;
  onClaimDailyMission: (missionId: string) => void;
}

export const DashboardView: React.FC<Props> = ({
  currentUser,
  onStartBattle,
  onNavigateTab,
  onSelectHeroElement,
  activeHeroElement,
  onClaimDailyMission,
}) => {
  const [selectedMode, setSelectedMode] = useState<GameMode>('duel');
  const [selectedDifficulty, setSelectedDifficulty] = useState<AIDifficulty>('adept');
  const [showModeModal, setShowModeModal] = useState<boolean>(false);

  const rank = getRankTier(currentUser.rankPoints);
  const totalBattles = currentUser.wins + currentUser.losses + currentUser.draws;
  const winRate = totalBattles > 0 ? Math.round((currentUser.wins / totalBattles) * 100) : 0;
  const currentElemInfo = ELEMENTS[activeHeroElement];

  const modes: { id: GameMode; title: string; subtitle: string; icon: string; badge?: string }[] = [
    { id: 'duel', title: '1v1 Duel', subtitle: 'Computer AI Combat Challenge', icon: '⚔️' },
    { id: 'random_ranked', title: 'Ranked Matchmaking', subtitle: 'Climb the competitive LP ladder', icon: '🏆', badge: 'RANKED' },
    { id: 'pvp_friend', title: 'Duel a Friend', subtitle: 'Challenge friends from social list', icon: '👥' },
    { id: 'battle_royale', title: 'Battle Royale', subtitle: '4-Player Elemental Free-for-All', icon: '🌪️' },
    { id: 'practice', title: 'Training Grounds', subtitle: 'Test combos & status effects freely', icon: '🎯' },
  ];

  return (
    <div className="relative z-10 flex flex-col gap-6 p-4 md:p-8 max-w-7xl mx-auto overflow-y-auto max-h-[calc(100vh-4rem)]">
      {/* Top Banner: 3D Hero Elemental Showcase & Quick Play */}
      <div className="relative overflow-hidden rounded-3xl border border-purple-900/50 bg-gradient-to-r from-purple-950/70 via-slate-950/90 to-indigo-950/70 p-6 md:p-8 shadow-2xl backdrop-blur-md">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
          {/* Left Hero Description */}
          <div className="lg:col-span-7 flex flex-col gap-4">
            <div className="flex items-center gap-2">
              <span className="flex items-center gap-1.5 rounded-full bg-purple-500/20 border border-purple-500/40 px-3 py-1 text-xs font-bold text-purple-300 uppercase tracking-widest">
                <Sparkles className="h-3.5 w-3.5" /> Next-Gen 3D Elemental Arena
              </span>
              <span className="rounded-full bg-amber-500/20 border border-amber-500/40 px-2.5 py-1 text-xs font-mono-num font-bold text-amber-300">
                Season 1 Active
              </span>
            </div>

            <h1 className="font-cinzel text-3xl sm:text-4xl md:text-5xl font-black text-white tracking-wide leading-tight">
              HARNESS THE POWER OF <br />
              <span
                className="bg-clip-text text-transparent"
                style={{
                  backgroundImage: `linear-gradient(to right, ${
                    activeHeroElement === 'fire'
                      ? '#f97316, #ef4444'
                      : activeHeroElement === 'water'
                      ? '#38bdf8, #2563eb'
                      : activeHeroElement === 'earth'
                      ? '#34d399, #059669'
                      : '#c084fc, #eab308'
                  })`,
                }}
              >
                {currentElemInfo.name.toUpperCase()}
              </span>
            </h1>

            <p className="text-sm text-slate-300 max-w-xl leading-relaxed">
              {currentElemInfo.description} {currentElemInfo.specialRule}
            </p>

            {/* Interactive 3D Element Switcher Tabs */}
            <div className="flex items-center gap-2 pt-2">
              <span className="text-xs uppercase tracking-wider text-slate-400 font-bold mr-1">
                Inspect 3D Artifact:
              </span>
              {(['fire', 'water', 'earth', 'lightning'] as ElementType[]).map((el) => {
                const isSelected = activeHeroElement === el;
                const info = ELEMENTS[el];
                return (
                  <button
                    key={el}
                    onClick={() => {
                      sound.playClick();
                      onSelectHeroElement(el);
                    }}
                    className={`flex items-center gap-1.5 rounded-xl border px-3 py-1.5 text-xs font-bold transition ${
                      isSelected
                        ? 'border-purple-400 bg-purple-600/30 text-white shadow-lg shadow-purple-500/20 scale-105'
                        : 'border-slate-800 bg-slate-900/60 text-slate-400 hover:text-white hover:border-slate-700'
                    }`}
                  >
                    <span>{info.icon}</span>
                    <span className="capitalize">{info.name}</span>
                  </button>
                );
              })}
            </div>

            {/* Big Action Buttons */}
            <div className="flex flex-wrap items-center gap-3 pt-4">
              <button
                onClick={() => {
                  sound.playClick();
                  onStartBattle('duel', 'adept');
                }}
                className="group relative inline-flex items-center justify-center rounded-2xl bg-gradient-to-r from-amber-500 via-orange-500 to-amber-600 px-8 py-3.5 text-base font-black font-cinzel text-slate-950 shadow-xl shadow-orange-500/20 hover:scale-105 active:scale-95 transition cursor-pointer"
              >
                <Play className="mr-2 h-5 w-5 fill-slate-950" />
                PLAY NOW
              </button>

              <button
                onClick={() => {
                  sound.playClick();
                  setShowModeModal(true);
                }}
                className="inline-flex items-center justify-center rounded-2xl border border-purple-700/60 bg-purple-950/40 px-6 py-3.5 text-xs font-bold text-purple-200 hover:bg-purple-900/50 hover:border-purple-400 transition"
              >
                <Swords className="mr-2 h-4 w-4" />
                Select Mode
              </button>

              <button
                onClick={() => {
                  sound.playClick();
                  onNavigateTab('friends');
                }}
                className="inline-flex items-center justify-center rounded-2xl border border-slate-800 bg-slate-900/60 px-5 py-3.5 text-xs font-bold text-slate-300 hover:text-white hover:border-slate-700 transition"
              >
                <Users className="mr-2 h-4 w-4" />
                Challenge Friends
              </button>
            </div>
          </div>

          {/* Right Showcase Card */}
          <div className="lg:col-span-5 flex flex-col gap-3">
            <div className="rounded-2xl border border-purple-900/40 bg-slate-950/80 p-5 shadow-xl flex flex-col gap-3">
              <div className="flex items-center justify-between border-b border-slate-800 pb-3">
                <div className="flex items-center gap-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-purple-900/50 text-2xl border border-purple-500/30">
                    {currentUser.avatar}
                  </div>
                  <div>
                    <div className="text-sm font-bold text-white">{currentUser.username}</div>
                    <div className="text-[11px] text-purple-400 font-mono-num">{currentUser.playerTag}</div>
                  </div>
                </div>
                <div className="text-right">
                  <div className="text-xs font-bold" style={{ color: rank.color }}>
                    {rank.badge} {rank.name}
                  </div>
                  <div className="text-[11px] font-mono-num text-slate-400">{currentUser.rankPoints} LP</div>
                </div>
              </div>

              {/* Stats Grid */}
              <div className="grid grid-cols-3 gap-2 text-center">
                <div className="rounded-xl bg-slate-900/80 p-2.5 border border-slate-800/80">
                  <span className="text-[10px] text-slate-400 uppercase font-semibold">Win Rate</span>
                  <div className="text-base font-bold font-mono-num text-emerald-400">{winRate}%</div>
                </div>
                <div className="rounded-xl bg-slate-900/80 p-2.5 border border-slate-800/80">
                  <span className="text-[10px] text-slate-400 uppercase font-semibold">Streak</span>
                  <div className="text-base font-bold font-mono-num text-amber-400">🔥 {currentUser.streak}</div>
                </div>
                <div className="rounded-xl bg-slate-900/80 p-2.5 border border-slate-800/80">
                  <span className="text-[10px] text-slate-400 uppercase font-semibold">Counters</span>
                  <div className="text-base font-bold font-mono-num text-cyan-400">{currentUser.countersWon}</div>
                </div>
              </div>

              {/* Status Effect System Highlight */}
              <div className="rounded-xl border border-purple-800/40 bg-purple-950/30 p-3 text-xs">
                <div className="font-bold text-purple-300 mb-1 flex items-center gap-1.5">
                  <Sparkles className="h-3.5 w-3.5" /> Combat Status Effects Active
                </div>
                <ul className="text-[11px] text-slate-300 space-y-1">
                  <li>🔥 <strong className="text-orange-400">Burn</strong>: Fire spells inflict ticking DoT damage.</li>
                  <li>💧 <strong className="text-cyan-400">Slow</strong>: Water slows target speed and reaction by 45%.</li>
                  <li>⚡ <strong className="text-purple-300">Stun</strong>: Consecutive hits trigger ionized paralysis!</li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Quick Nav Cards Bar */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        <button
          onClick={() => {
            sound.playClick();
            onNavigateTab('arena');
          }}
          className="flex items-center gap-3 rounded-2xl border border-purple-900/40 bg-slate-900/70 p-4 text-left hover:border-purple-500 hover:bg-slate-900 transition shadow-lg group"
        >
          <div className="flex h-11 w-11 items-center justify-center rounded-xl bg-orange-500/20 text-orange-400 group-hover:scale-110 transition">
            <Swords className="h-5 w-5" />
          </div>
          <div>
            <div className="text-xs font-bold text-white">ARENA MODES</div>
            <div className="text-[11px] text-slate-400">Jump straight into 3D combat</div>
          </div>
        </button>

        <button
          onClick={() => {
            sound.playClick();
            onNavigateTab('friends');
          }}
          className="flex items-center gap-3 rounded-2xl border border-purple-900/40 bg-slate-900/70 p-4 text-left hover:border-purple-500 hover:bg-slate-900 transition shadow-lg group"
        >
          <div className="flex h-11 w-11 items-center justify-center rounded-xl bg-cyan-500/20 text-cyan-400 group-hover:scale-110 transition">
            <Users className="h-5 w-5" />
          </div>
          <div>
            <div className="text-xs font-bold text-white">FRIENDS &amp; SOCIAL</div>
            <div className="text-[11px] text-slate-400">Search, invite &amp; duel friends</div>
          </div>
        </button>

        <button
          onClick={() => {
            sound.playClick();
            onNavigateTab('leaderboard');
          }}
          className="flex items-center gap-3 rounded-2xl border border-purple-900/40 bg-slate-900/70 p-4 text-left hover:border-purple-500 hover:bg-slate-900 transition shadow-lg group"
        >
          <div className="flex h-11 w-11 items-center justify-center rounded-xl bg-amber-500/20 text-amber-400 group-hover:scale-110 transition">
            <Trophy className="h-5 w-5" />
          </div>
          <div>
            <div className="text-xs font-bold text-white">LEADERBOARD</div>
            <div className="text-[11px] text-slate-400">Top 3 3D Podium &amp; Ladder</div>
          </div>
        </button>

        <button
          onClick={() => {
            sound.playClick();
            onNavigateTab('rewards');
          }}
          className="flex items-center gap-3 rounded-2xl border border-purple-900/40 bg-slate-900/70 p-4 text-left hover:border-purple-500 hover:bg-slate-900 transition shadow-lg group"
        >
          <div className="flex h-11 w-11 items-center justify-center rounded-xl bg-purple-500/20 text-purple-400 group-hover:scale-110 transition">
            <Gift className="h-5 w-5" />
          </div>
          <div>
            <div className="text-xs font-bold text-white">DAILY REWARDS</div>
            <div className="text-[11px] text-slate-400">Claim XP, LP &amp; perks</div>
          </div>
        </button>
      </div>

      {/* Two Column Grid: Daily Missions & Recent Battles */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Daily Missions */}
        <div className="lg:col-span-6 rounded-2xl border border-purple-900/40 bg-slate-950/80 p-5 shadow-xl">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-2">
              <Award className="h-4 w-4 text-amber-400" />
              <h2 className="text-sm font-bold font-cinzel text-slate-100">Daily Combat Challenges</h2>
            </div>
            <span className="text-[11px] text-slate-400 font-mono-num">Resets in 12h</span>
          </div>

          <div className="flex flex-col gap-3">
            {currentUser.dailyMissions.map((m) => {
              const isDone = m.progress >= m.target;
              return (
                <div
                  key={m.id}
                  className="rounded-xl border border-slate-800 bg-slate-900/60 p-3 flex items-center justify-between gap-3"
                >
                  <div className="flex items-center gap-3">
                    <span className="text-2xl">{m.icon}</span>
                    <div>
                      <div className="text-xs font-bold text-slate-200">{m.title}</div>
                      <div className="text-[11px] text-slate-400">{m.desc}</div>
                      <div className="flex items-center gap-2 text-[10px] text-amber-400 mt-1 font-mono-num font-bold">
                        <span>+{m.rewardXp} XP</span>
                        <span>•</span>
                        <span>+{m.rewardLp} LP</span>
                      </div>
                    </div>
                  </div>

                  <div>
                    {m.claimed ? (
                      <span className="flex items-center gap-1 text-[11px] text-emerald-400 font-bold bg-emerald-950/40 px-2.5 py-1 rounded-lg border border-emerald-800/40">
                        <CheckCircle2 className="h-3.5 w-3.5" /> Claimed
                      </span>
                    ) : isDone ? (
                      <button
                        onClick={() => {
                          sound.playClick();
                          onClaimDailyMission(m.id);
                        }}
                        className="rounded-lg bg-gradient-to-r from-amber-500 to-orange-500 px-3 py-1.5 text-xs font-bold text-slate-950 hover:scale-105 active:scale-95 transition shadow-md shadow-orange-500/20"
                      >
                        Claim!
                      </button>
                    ) : (
                      <span className="text-[11px] font-mono-num text-slate-400 bg-slate-800 px-2 py-1 rounded-md">
                        {m.progress}/{m.target}
                      </span>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Recent Battle History */}
        <div className="lg:col-span-6 rounded-2xl border border-purple-900/40 bg-slate-950/80 p-5 shadow-xl">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-2">
              <Clock className="h-4 w-4 text-cyan-400" />
              <h2 className="text-sm font-bold font-cinzel text-slate-100">Recent Battle Record</h2>
            </div>
            <button
              onClick={() => onNavigateTab('profile')}
              className="text-[11px] text-purple-400 hover:text-purple-300 font-bold flex items-center gap-1"
            >
              Full History <ArrowRight className="h-3 w-3" />
            </button>
          </div>

          <div className="flex flex-col gap-2.5">
            {currentUser.battleHistory.length === 0 ? (
              <p className="text-xs text-slate-500 text-center py-6">No battle history yet. Enter the arena!</p>
            ) : (
              currentUser.battleHistory.slice(0, 4).map((rec) => {
                const isWin = rec.result === 'victory';
                const isLoss = rec.result === 'defeat';
                return (
                  <div
                    key={rec.id}
                    className="rounded-xl border border-slate-800/80 bg-slate-900/60 p-3 flex items-center justify-between text-xs"
                  >
                    <div className="flex items-center gap-3">
                      <div
                        className={`flex h-8 w-8 items-center justify-center rounded-lg font-bold font-cinzel ${
                          isWin
                            ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30'
                            : isLoss
                            ? 'bg-rose-500/20 text-rose-400 border border-rose-500/30'
                            : 'bg-amber-500/20 text-amber-400 border border-amber-500/30'
                        }`}
                      >
                        {isWin ? 'W' : isLoss ? 'L' : 'D'}
                      </div>
                      <div>
                        <div className="font-bold text-slate-200">vs {rec.opponentName}</div>
                        <div className="text-[10px] text-slate-400">
                          {ELEMENTS[rec.playerElement].icon} {rec.playerElement} vs {ELEMENTS[rec.opponentElement].icon} {rec.opponentElement}
                        </div>
                      </div>
                    </div>

                    <div className="text-right font-mono-num">
                      <div className={`font-bold ${rec.lpChange >= 0 ? 'text-amber-400' : 'text-rose-400'}`}>
                        {rec.lpChange >= 0 ? `+${rec.lpChange}` : rec.lpChange} LP
                      </div>
                      <div className="text-[10px] text-cyan-400">+{rec.xpEarned} XP</div>
                    </div>
                  </div>
                );
              })
            )}
          </div>
        </div>
      </div>

      {/* Game Mode Selection Modal */}
      {showModeModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 p-4 backdrop-blur-sm">
          <div className="relative w-full max-w-lg rounded-3xl border border-purple-900/60 bg-slate-950/95 p-6 shadow-2xl text-slate-100">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3 mb-4">
              <h3 className="text-lg font-bold font-cinzel text-purple-300">Choose Battle Mode</h3>
              <button
                onClick={() => setShowModeModal(false)}
                className="h-8 w-8 rounded-lg bg-slate-800 text-slate-400 hover:text-white"
              >
                ✕
              </button>
            </div>

            <div className="flex flex-col gap-2.5 mb-5">
              {modes.map((m) => {
                const isSelected = selectedMode === m.id;
                return (
                  <div
                    key={m.id}
                    onClick={() => setSelectedMode(m.id)}
                    className={`rounded-2xl border p-3.5 transition cursor-pointer flex items-center justify-between ${
                      isSelected
                        ? 'border-purple-400 bg-purple-950/40 shadow-lg shadow-purple-500/20'
                        : 'border-slate-800 bg-slate-900/60 hover:border-slate-700'
                    }`}
                  >
                    <div className="flex items-center gap-3">
                      <span className="text-2xl">{m.icon}</span>
                      <div>
                        <div className="text-xs font-bold text-white flex items-center gap-2">
                          <span>{m.title}</span>
                          {m.badge && (
                            <span className="rounded bg-amber-500/20 text-amber-300 border border-amber-500/30 px-1.5 py-0.2 text-[9px] font-bold">
                              {m.badge}
                            </span>
                          )}
                        </div>
                        <div className="text-[11px] text-slate-400">{m.subtitle}</div>
                      </div>
                    </div>
                    <div
                      className={`h-4 w-4 rounded-full border flex items-center justify-center ${
                        isSelected ? 'border-purple-400 bg-purple-500' : 'border-slate-700'
                      }`}
                    >
                      {isSelected && <div className="h-1.5 w-1.5 rounded-full bg-white" />}
                    </div>
                  </div>
                );
              })}
            </div>

            {/* AI Difficulty Selector */}
            <div className="mb-6">
              <span className="text-xs font-bold text-slate-300 uppercase tracking-wider block mb-2">
                Opponent AI Difficulty:
              </span>
              <div className="grid grid-cols-3 gap-2">
                {(['apprentice', 'adept', 'grandmaster'] as AIDifficulty[]).map((d) => (
                  <button
                    key={d}
                    onClick={() => setSelectedDifficulty(d)}
                    className={`rounded-xl border py-2 text-xs font-bold capitalize transition ${
                      selectedDifficulty === d
                        ? 'border-purple-400 bg-purple-600/30 text-white'
                        : 'border-slate-800 bg-slate-900/60 text-slate-400 hover:text-white'
                    }`}
                  >
                    {d}
                  </button>
                ))}
              </div>
            </div>

            <button
              onClick={() => {
                sound.playClick();
                setShowModeModal(false);
                onStartBattle(selectedMode, selectedDifficulty);
              }}
              className="w-full rounded-2xl bg-gradient-to-r from-amber-500 to-orange-500 py-3.5 font-cinzel font-black text-slate-950 shadow-xl shadow-orange-500/20 hover:scale-102 active:scale-98 transition text-sm"
            >
              LAUNCH ARENA MATCH
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
