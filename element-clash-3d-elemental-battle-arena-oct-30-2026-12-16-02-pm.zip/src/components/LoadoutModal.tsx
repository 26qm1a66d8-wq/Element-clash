/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { PlayerStats } from '../types/game';
import { PERKS, SKINS, getRankTier } from '../game/constants';
import { Shield, Sparkles, Zap, Award, Check } from 'lucide-react';

interface Props {
  isOpen: boolean;
  onClose: () => void;
  stats: PlayerStats;
  onUpdateStats: (newStats: Partial<PlayerStats>) => void;
}

export const LoadoutModal: React.FC<Props> = ({ isOpen, onClose, stats, onUpdateStats }) => {
  if (!isOpen) return null;

  const rank = getRankTier(stats.rankPoints);
  const xpForNextLevel = stats.level * 150;
  const xpPercent = Math.min(100, Math.floor((stats.xp / xpForNextLevel) * 100));

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 p-4 backdrop-blur-sm">
      <div className="relative w-full max-w-2xl rounded-2xl border border-slate-700 bg-slate-900/95 p-6 shadow-2xl text-slate-100 max-h-[90vh] overflow-y-auto">
        {/* Header */}
        <div className="flex items-center justify-between border-b border-slate-800 pb-4">
          <div className="flex items-center gap-3">
            <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-amber-500/20 border border-amber-500/40 text-2xl">
              {rank.badge}
            </div>
            <div>
              <h2 className="text-xl font-bold font-cinzel text-amber-400">Gladiator Profile & Loadout</h2>
              <div className="flex items-center gap-2 text-xs text-slate-400">
                <span className="font-semibold text-slate-200">Level {stats.level}</span>
                <span>•</span>
                <span style={{ color: rank.color }} className="font-bold">{rank.name}</span>
                <span>({stats.rankPoints} LP)</span>
              </div>
            </div>
          </div>
          <button
            onClick={onClose}
            className="flex h-9 w-9 items-center justify-center rounded-lg bg-slate-800 text-slate-400 hover:bg-slate-700 hover:text-white transition"
          >
            ✕
          </button>
        </div>

        {/* Level XP Bar */}
        <div className="my-5 rounded-xl border border-slate-800 bg-slate-950/60 p-4">
          <div className="flex items-center justify-between text-xs text-slate-400 mb-1.5 font-mono-num">
            <span>XP Progress to Level {stats.level + 1}</span>
            <span>{stats.xp} / {xpForNextLevel} XP</span>
          </div>
          <div className="h-2.5 w-full overflow-hidden rounded-full bg-slate-800">
            <div
              className="h-full bg-gradient-to-r from-amber-500 to-yellow-400 transition-all duration-500"
              style={{ width: `${xpPercent}%` }}
            />
          </div>
        </div>

        {/* Passive Perks Section */}
        <div className="mb-6">
          <div className="flex items-center gap-2 mb-3">
            <Shield className="h-4 w-4 text-emerald-400" />
            <h3 className="text-sm font-semibold uppercase tracking-wider text-slate-300">Passive Combat Perks</h3>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
            {PERKS.map((perk) => {
              const isUnlocked = stats.level >= perk.unlockLevel;
              const isSelected = stats.activePerk === perk.id;

              return (
                <div
                  key={perk.id}
                  onClick={() => {
                    if (isUnlocked) onUpdateStats({ activePerk: perk.id });
                  }}
                  className={`rounded-xl border p-3 transition flex flex-col justify-between ${
                    isSelected
                      ? 'border-amber-400 bg-amber-950/30 shadow-md shadow-amber-500/10'
                      : isUnlocked
                      ? 'border-slate-800 bg-slate-950/50 hover:border-slate-700 cursor-pointer'
                      : 'border-slate-800/40 bg-slate-950/20 opacity-50 cursor-not-allowed'
                  }`}
                >
                  <div className="flex items-start justify-between">
                    <div className="flex items-center gap-2">
                      <span className="text-lg">{perk.icon}</span>
                      <span className="font-bold text-slate-200">{perk.name}</span>
                    </div>
                    {isSelected && (
                      <span className="flex items-center gap-0.5 text-[10px] text-amber-400 font-bold bg-amber-500/20 px-1.5 py-0.5 rounded">
                        <Check className="h-3 w-3" /> ACTIVE
                      </span>
                    )}
                    {!isUnlocked && (
                      <span className="text-[10px] text-slate-500 bg-slate-800 px-1.5 py-0.5 rounded">
                        Lvl {perk.unlockLevel}
                      </span>
                    )}
                  </div>
                  <p className="text-slate-400 text-[11px] mt-2">{perk.desc}</p>
                </div>
              );
            })}
          </div>
        </div>

        {/* Champion Skins Section */}
        <div>
          <div className="flex items-center gap-2 mb-3">
            <Sparkles className="h-4 w-4 text-purple-400" />
            <h3 className="text-sm font-semibold uppercase tracking-wider text-slate-300">Champion Visual Skins</h3>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
            {SKINS.map((skin) => {
              const isUnlocked = stats.wins >= skin.unlockWins;
              const isSelected = stats.activeSkin === skin.id;

              return (
                <div
                  key={skin.id}
                  onClick={() => {
                    if (isUnlocked) onUpdateStats({ activeSkin: skin.id });
                  }}
                  className={`rounded-xl border p-3 transition flex flex-col justify-between ${
                    isSelected
                      ? 'border-purple-400 bg-purple-950/30 shadow-md shadow-purple-500/10'
                      : isUnlocked
                      ? 'border-slate-800 bg-slate-950/50 hover:border-slate-700 cursor-pointer'
                      : 'border-slate-800/40 bg-slate-950/20 opacity-50 cursor-not-allowed'
                  }`}
                >
                  <div className="flex items-start justify-between">
                    <div className="flex items-center gap-2">
                      <div
                        className="h-3.5 w-3.5 rounded-full border border-white/20"
                        style={{ backgroundColor: `#${skin.glowColor.toString(16).padStart(6, '0')}` }}
                      />
                      <span className="font-bold text-slate-200">{skin.name}</span>
                    </div>
                    {isSelected && (
                      <span className="flex items-center gap-0.5 text-[10px] text-purple-300 font-bold bg-purple-500/20 px-1.5 py-0.5 rounded">
                        <Check className="h-3 w-3" /> EQUIPPED
                      </span>
                    )}
                    {!isUnlocked && (
                      <span className="text-[10px] text-slate-500 bg-slate-800 px-1.5 py-0.5 rounded">
                        {skin.unlockWins} Wins Req
                      </span>
                    )}
                  </div>
                  <p className="text-slate-400 text-[11px] mt-2">{skin.desc}</p>
                </div>
              );
            })}
          </div>
        </div>

        {/* Footer */}
        <div className="mt-6 pt-4 border-t border-slate-800 flex justify-end">
          <button
            onClick={onClose}
            className="rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 font-bold px-6 py-2.5 text-sm transition"
          >
            Done
          </button>
        </div>
      </div>
    </div>
  );
};
