/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { UserAccount } from '../types/game';
import { StorageService } from '../services/storageService';
import { getRankTier } from '../game/constants';
import {
  Users,
  UserPlus,
  Search,
  Swords,
  Trash2,
  Check,
  X,
  Sparkles,
  Shield,
  Circle,
  MessageSquare,
  AlertCircle,
} from 'lucide-react';
import { sound } from '../audio/soundEngine';

interface Props {
  currentUser: UserAccount;
  allUsers: UserAccount[];
  onRefreshUsers: () => void;
  onChallengeFriend: (friend: UserAccount) => void;
}

export const FriendsView: React.FC<Props> = ({
  currentUser,
  allUsers,
  onRefreshUsers,
  onChallengeFriend,
}) => {
  const [activeTab, setActiveTab] = useState<'my_friends' | 'pending' | 'add_friend'>('my_friends');
  const [searchQuery, setSearchQuery] = useState('');
  const [inviteSuccessMsg, setInviteSuccessMsg] = useState('');

  // Find friends objects
  const friendsList = allUsers.filter((u) => currentUser.friends.includes(u.id));
  const pendingList = allUsers.filter((u) => currentUser.pendingFriendRequests.includes(u.id));

  // Search filtered users (excluding current user and existing friends)
  const nonFriends = allUsers.filter(
    (u) =>
      u.id !== currentUser.id &&
      !currentUser.friends.includes(u.id) &&
      !currentUser.pendingFriendRequests.includes(u.id)
  );

  const filteredSearchUsers = searchQuery.trim()
    ? nonFriends.filter(
        (u) =>
          u.username.toLowerCase().includes(searchQuery.toLowerCase()) ||
          u.playerTag.toLowerCase().includes(searchQuery.toLowerCase())
      )
    : nonFriends;

  const handleSendRequest = (targetId: string) => {
    sound.playClick();
    const ok = StorageService.sendFriendRequest(targetId);
    if (ok) {
      setInviteSuccessMsg('Friend request dispatched successfully!');
      setTimeout(() => setInviteSuccessMsg(''), 3000);
      onRefreshUsers();
    }
  };

  const handleAccept = (requesterId: string) => {
    sound.playClick();
    StorageService.acceptFriendRequest(requesterId);
    onRefreshUsers();
  };

  const handleReject = (requesterId: string) => {
    sound.playClick();
    StorageService.rejectFriendRequest(requesterId);
    onRefreshUsers();
  };

  const handleRemove = (friendId: string) => {
    sound.playClick();
    StorageService.removeFriend(friendId);
    onRefreshUsers();
  };

  return (
    <div className="relative z-10 flex flex-col gap-6 p-4 md:p-8 max-w-5xl mx-auto overflow-y-auto max-h-[calc(100vh-4rem)]">
      {/* Header */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 border-b border-purple-900/40 pb-5">
        <div>
          <h1 className="font-cinzel text-2xl md:text-3xl font-black text-white flex items-center gap-2">
            <Users className="h-6 w-6 text-purple-400" /> Friends &amp; Social Arena
          </h1>
          <p className="text-xs text-slate-400 mt-1">
            Build your elemental clan, challenge friends to 1v1 clashes, and coordinate combos
          </p>
        </div>

        {/* Tab switchers */}
        <div className="flex items-center gap-1 bg-slate-900/80 p-1 rounded-2xl border border-purple-900/40">
          <button
            onClick={() => setActiveTab('my_friends')}
            className={`rounded-xl px-4 py-2 text-xs font-bold transition flex items-center gap-1.5 ${
              activeTab === 'my_friends'
                ? 'bg-purple-600 text-white shadow-md'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <span>My Friends</span>
            <span className="rounded-full bg-slate-800 px-1.5 py-0.2 text-[10px]">
              {friendsList.length}
            </span>
          </button>

          <button
            onClick={() => setActiveTab('pending')}
            className={`rounded-xl px-4 py-2 text-xs font-bold transition flex items-center gap-1.5 ${
              activeTab === 'pending'
                ? 'bg-purple-600 text-white shadow-md'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <span>Requests</span>
            {pendingList.length > 0 && (
              <span className="rounded-full bg-rose-500 text-white px-1.5 py-0.2 text-[10px] animate-pulse">
                {pendingList.length}
              </span>
            )}
          </button>

          <button
            onClick={() => setActiveTab('add_friend')}
            className={`rounded-xl px-4 py-2 text-xs font-bold transition flex items-center gap-1.5 ${
              activeTab === 'add_friend'
                ? 'bg-purple-600 text-white shadow-md'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <UserPlus className="h-3.5 w-3.5" />
            <span>Find Players</span>
          </button>
        </div>
      </div>

      {inviteSuccessMsg && (
        <div className="rounded-xl border border-emerald-500/50 bg-emerald-950/60 p-3 text-xs text-emerald-300 flex items-center gap-2">
          <Check className="h-4 w-4" />
          <span>{inviteSuccessMsg}</span>
        </div>
      )}

      {/* Tab 1: My Friends */}
      {activeTab === 'my_friends' && (
        <div className="flex flex-col gap-3">
          {friendsList.length === 0 ? (
            <div className="rounded-2xl border border-purple-900/30 bg-slate-950/60 p-12 text-center text-slate-400">
              <Users className="mx-auto h-12 w-12 text-purple-400/50 mb-3" />
              <h3 className="font-cinzel text-lg font-bold text-slate-200">No Friends Added Yet</h3>
              <p className="text-xs text-slate-400 max-w-md mx-auto mt-1 mb-4">
                Challenge rivals or search for players using their unique Player Tag to build your elemental alliance!
              </p>
              <button
                onClick={() => setActiveTab('add_friend')}
                className="rounded-xl bg-purple-600 px-5 py-2.5 text-xs font-bold text-white hover:bg-purple-500 transition"
              >
                Find &amp; Add Friends
              </button>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              {friendsList.map((f, idx) => {
                const rank = getRankTier(f.rankPoints);
                const isOnline = idx % 2 === 0; // simulated presence
                return (
                  <div
                    key={f.id}
                    className="rounded-2xl border border-purple-900/40 bg-slate-950/80 p-4 shadow-xl flex items-center justify-between gap-3 hover:border-purple-600/50 transition"
                  >
                    <div className="flex items-center gap-3">
                      <div className="relative">
                        <div className="flex h-12 w-12 items-center justify-center rounded-2xl bg-purple-950/80 text-2xl border border-purple-700/50">
                          {f.avatar}
                        </div>
                        <span
                          className={`absolute -bottom-1 -right-1 h-3.5 w-3.5 rounded-full border-2 border-slate-950 ${
                            isOnline ? 'bg-emerald-500 animate-pulse' : 'bg-slate-500'
                          }`}
                          title={isOnline ? 'Online in Lobby' : 'Offline'}
                        />
                      </div>

                      <div>
                        <div className="flex items-center gap-1.5">
                          <span className="font-bold text-slate-100 text-sm">{f.username}</span>
                          <span className="text-[10px] text-purple-400 font-mono-num font-bold">
                            {f.playerTag}
                          </span>
                        </div>
                        <div className="text-[11px] text-slate-400">{f.title}</div>
                        <div className="flex items-center gap-2 text-[10px] text-slate-400 mt-1">
                          <span className="font-bold text-amber-400 font-mono-num">Lvl {f.level}</span>
                          <span>•</span>
                          <span style={{ color: rank.color }} className="font-bold">
                            {rank.badge} {rank.name}
                          </span>
                          <span>•</span>
                          <span className="text-emerald-400 font-bold">{f.wins}W</span>
                        </div>
                      </div>
                    </div>

                    <div className="flex items-center gap-2">
                      <button
                        onClick={() => {
                          sound.playClick();
                          onChallengeFriend(f);
                        }}
                        className="flex items-center gap-1.5 rounded-xl bg-gradient-to-r from-amber-500 to-orange-500 px-3 py-2 text-xs font-bold text-slate-950 shadow-md shadow-orange-500/20 hover:scale-105 active:scale-95 transition"
                        title="Challenge to Duel"
                      >
                        <Swords className="h-3.5 w-3.5" />
                        <span>Challenge</span>
                      </button>

                      <button
                        onClick={() => handleRemove(f.id)}
                        className="flex h-8 w-8 items-center justify-center rounded-xl border border-slate-800 bg-slate-900/60 text-slate-500 hover:text-rose-400 hover:border-rose-900/60 transition"
                        title="Remove Friend"
                      >
                        <Trash2 className="h-3.5 w-3.5" />
                      </button>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      )}

      {/* Tab 2: Pending Requests */}
      {activeTab === 'pending' && (
        <div className="flex flex-col gap-3">
          {pendingList.length === 0 ? (
            <div className="rounded-2xl border border-purple-900/30 bg-slate-950/60 p-12 text-center text-slate-400">
              <Check className="mx-auto h-12 w-12 text-purple-400/50 mb-3" />
              <h3 className="font-cinzel text-lg font-bold text-slate-200">No Pending Requests</h3>
              <p className="text-xs text-slate-400 mt-1">
                You're all caught up with friend invitations!
              </p>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              {pendingList.map((p) => {
                const rank = getRankTier(p.rankPoints);
                return (
                  <div
                    key={p.id}
                    className="rounded-2xl border border-purple-900/50 bg-slate-950/90 p-4 shadow-xl flex items-center justify-between gap-3"
                  >
                    <div className="flex items-center gap-3">
                      <div className="flex h-12 w-12 items-center justify-center rounded-2xl bg-purple-950/80 text-2xl border border-purple-700/50">
                        {p.avatar}
                      </div>
                      <div>
                        <div className="flex items-center gap-1.5">
                          <span className="font-bold text-slate-100 text-sm">{p.username}</span>
                          <span className="text-[10px] text-purple-400 font-mono-num font-bold">
                            {p.playerTag}
                          </span>
                        </div>
                        <div className="text-[11px] text-slate-400">{p.title}</div>
                        <div className="flex items-center gap-2 text-[10px] text-slate-400 mt-1">
                          <span className="font-bold text-amber-400 font-mono-num">Lvl {p.level}</span>
                          <span>•</span>
                          <span style={{ color: rank.color }} className="font-bold">
                            {rank.badge} {rank.name}
                          </span>
                        </div>
                      </div>
                    </div>

                    <div className="flex items-center gap-2">
                      <button
                        onClick={() => handleAccept(p.id)}
                        className="flex items-center gap-1 rounded-xl bg-emerald-600 px-3 py-1.5 text-xs font-bold text-white hover:bg-emerald-500 shadow-md shadow-emerald-600/20"
                      >
                        <Check className="h-3.5 w-3.5" /> Accept
                      </button>
                      <button
                        onClick={() => handleReject(p.id)}
                        className="flex items-center gap-1 rounded-xl bg-slate-800 px-3 py-1.5 text-xs font-bold text-slate-400 hover:text-white"
                      >
                        <X className="h-3.5 w-3.5" /> Decline
                      </button>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      )}

      {/* Tab 3: Search / Add Players */}
      {activeTab === 'add_friend' && (
        <div className="flex flex-col gap-4">
          <div className="relative">
            <Search className="absolute left-4 top-3.5 h-4 w-4 text-purple-400" />
            <input
              type="text"
              placeholder="Search by username or tag (e.g. ValkyriePrime, #EC-9901)..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full rounded-2xl border border-purple-900/50 bg-slate-900/80 py-3 pl-11 pr-4 text-xs text-white placeholder-slate-500 focus:border-purple-400 focus:outline-none shadow-lg"
            />
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            {filteredSearchUsers.map((u) => {
              const rank = getRankTier(u.rankPoints);
              return (
                <div
                  key={u.id}
                  className="rounded-2xl border border-purple-900/30 bg-slate-950/80 p-4 shadow-xl flex items-center justify-between gap-3 hover:border-purple-600/40 transition"
                >
                  <div className="flex items-center gap-3">
                    <div className="flex h-12 w-12 items-center justify-center rounded-2xl bg-purple-950/80 text-2xl border border-purple-700/50">
                      {u.avatar}
                    </div>
                    <div>
                      <div className="flex items-center gap-1.5">
                        <span className="font-bold text-slate-100 text-sm">{u.username}</span>
                        <span className="text-[10px] text-purple-400 font-mono-num font-bold">
                          {u.playerTag}
                        </span>
                      </div>
                      <div className="text-[11px] text-slate-400">{u.title}</div>
                      <div className="flex items-center gap-2 text-[10px] text-slate-400 mt-1">
                        <span className="font-bold text-amber-400 font-mono-num">Lvl {u.level}</span>
                        <span>•</span>
                        <span style={{ color: rank.color }} className="font-bold">
                          {rank.badge} {rank.name}
                        </span>
                      </div>
                    </div>
                  </div>

                  <button
                    onClick={() => handleSendRequest(u.id)}
                    className="flex items-center gap-1 rounded-xl bg-purple-600 px-3.5 py-2 text-xs font-bold text-white hover:bg-purple-500 transition shadow-md shadow-purple-600/20"
                  >
                    <UserPlus className="h-3.5 w-3.5" />
                    <span>Add</span>
                  </button>
                </div>
              );
            })}
          </div>
        </div>
      )}
    </div>
  );
};
